﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Join_Class : Form
    {
        //global variable
        string globalStudentID;
        public Join_Class(string studentID)
        {
            InitializeComponent();
            //value passed from previous form stored in global variables
            globalStudentID = studentID;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //exits program
            this.Hide(); 
        }

        private void MainScreenButton_Click(object sender, EventArgs e)
        {
            //loads Student Homepage
            Student_Homepage studentHomepage = new Student_Homepage(globalStudentID);
            this.Hide();
            studentHomepage.Show();
        }

        private void JoinClassButton_Click(object sender, EventArgs e)
        {
            //if user has not entered a class to join
            if (ClassCodeTextBox.Text == string.Empty)
            { 
                //outputs error message
                ErrorLabel.Text = "Please enter a code";
            }
            else
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to database

                //Query to select all the ClassID's from the class table
                OleDbCommand checkClassCmd = new OleDbCommand("Select * from Classes where " +
                    "ClassID=" + ClassCodeTextBox.Text, con);
                OleDbDataReader reader = checkClassCmd.ExecuteReader(); //reader executes query
                if (reader.HasRows) //if data has been returned
                {
                    reader.Close(); //close reader
                    checkClassCmd.Dispose(); //dipose command

                    //query to check is user is already in the class
                    OleDbCommand checkStudentClass = new OleDbCommand("Select * from ClassStudent Where " +
                        "StudentID='" + globalStudentID + "'and ClassID=" + ClassCodeTextBox.Text, con);
                    OleDbDataReader studentClassReader = checkStudentClass.ExecuteReader(); //reader executes command
                    if (studentClassReader.HasRows) //if data has been returned
                    {
                        //output error message
                        ErrorLabel.Text = "You are already in this class";
                        studentClassReader.Close(); //close reader
                        checkStudentClass.Dispose(); //dipose command
                        con.Close(); //close connection 
                    }
                    else //if the user us not in the clas
                    {
                        studentClassReader.Close(); //close reader
                        checkStudentClass.Dispose(); //dispose command

                        //query to Insert ClassID and StudentID into ClassStudent table
                        OleDbCommand addStudentClass = new OleDbCommand("Insert Into [ClassStudent]([StudentID], " +
                            "[ClassID]) Values(@studentID, @classID)", con);
                        //query parameters
                        addStudentClass.Parameters.AddRange(new OleDbParameter[]
                        {
                            new OleDbParameter("@studentID", globalStudentID), //StudentID parameter
                            new OleDbParameter("@classID", ClassCodeTextBox.Text) //ClassID parameter
                        });
                        addStudentClass.ExecuteNonQuery(); //executes query
                        //outputs confirmation message
                        ConfirmationLabel.Text = "You have joined class: " + ClassCodeTextBox.Text;
                        addStudentClass.Dispose(); //dipsoses command

                     

                        DataSet ds = new DataSet(); //data returned
                        DataTable dt = new DataTable(); //where data will be stored

                        //command to Select all Classes a student is in
                        string cmd = ("Select NumStudents From Classes Where ClassID =" + ClassCodeTextBox.Text);
                      
                        //declares data adapter
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd, con);
                       
                        da.Fill(ds, "ClassStore"); //data converted into useable format
                        dt = ds.Tables["ClassStore"]; //data table filled with data
                        
                        //The value returned from the database is converted into an integer
                        int numStudents = Convert.ToInt32(dt.Rows[0][0]) +1;
                        //Converts integer to a string so it can be inserted into the database
                        string newNumStudents = numStudents.ToString();
                        
                        //Query to update Classes table to add the new student 
                        OleDbCommand newStudentCmd = new OleDbCommand("Update Classes set [NumStudents] ='" + 
                            newNumStudents + "'Where ClassID=" + ClassCodeTextBox.Text,con);
                        newStudentCmd.ExecuteNonQuery(); //executes query
                        newStudentCmd.Dispose();  //disposes query
                        con.Close(); //closes connection
                   }
                }
                else //if no data is returned, the class doesn't exist
                {
                    reader.Close(); //close reader
                    checkClassCmd.Dispose(); //dispose command
                    //output error message
                    ErrorLabel.Text = "This class does not exist, try again...";
                    con.Close(); //closes connection 
                }





            }

        }
    }
}
