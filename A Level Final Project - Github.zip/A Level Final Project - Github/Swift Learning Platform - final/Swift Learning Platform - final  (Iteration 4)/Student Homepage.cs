﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Student_Homepage : Form
    {
        //global variables 
        string globalStudentID;
        public Student_Homepage(string studentID)
        {
            InitializeComponent(); 
            //value from previous form stored in global variable
            globalStudentID = studentID;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //exits program
            this.Hide();
        }

        private void SignOutButton_Click(object sender, EventArgs e)
        {
            //loads Welcome Screen form
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            this.Hide();
            welcomeScreen.Show();
        }

        private void JoinClassesButton_Click(object sender, EventArgs e)
        {
            //loads Join a Class form
            Join_Class joinClass = new Join_Class(globalStudentID);
            this.Hide(); 
            joinClass.Show();
        }

        private void ViewAssignmentsButton_Click(object sender, EventArgs e)
        {
             //default values for variables needed in the View Assignments form 
            int count = 0;
            string workID = "";
            int questionCount = -1;
            
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalStudentID, count, workID, questionCount);
            this.Hide();
            viewAssignments.Show();
        }

        private void ViewClassesButton_Click(object sender, EventArgs e)
        {
            //loads View Classes form
            ViewClassesSTU viewClasses = new ViewClassesSTU(globalStudentID);
            this.Hide();
            viewClasses.Show();
        }
    }
}
