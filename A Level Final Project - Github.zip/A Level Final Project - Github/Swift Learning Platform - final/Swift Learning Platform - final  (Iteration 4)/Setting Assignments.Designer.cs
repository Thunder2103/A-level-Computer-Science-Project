﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Setting_Assignments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProjectNameLogo = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.SelectQuestionTypeLabel = new System.Windows.Forms.Label();
            this.ClickInfoLabel = new System.Windows.Forms.Label();
            this.QuestTypeComboBox = new System.Windows.Forms.ComboBox();
            this.SelectQuestionButton = new System.Windows.Forms.Button();
            this.TextLabel = new System.Windows.Forms.Label();
            this.QuestionsRichTextBox = new System.Windows.Forms.RichTextBox();
            this.RefreshQuestionsButton = new System.Windows.Forms.Button();
            this.SetWorkButton = new System.Windows.Forms.Button();
            this.ChangeClassButton = new System.Windows.Forms.Button();
            this.MainScreenButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ProjectNameLogo
            // 
            this.ProjectNameLogo.AutoSize = true;
            this.ProjectNameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ProjectNameLogo.Location = new System.Drawing.Point(12, 9);
            this.ProjectNameLogo.Name = "ProjectNameLogo";
            this.ProjectNameLogo.Size = new System.Drawing.Size(58, 30);
            this.ProjectNameLogo.TabIndex = 2;
            this.ProjectNameLogo.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(288, 57);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(217, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Setting Assignments...";
            // 
            // SelectQuestionTypeLabel
            // 
            this.SelectQuestionTypeLabel.AutoSize = true;
            this.SelectQuestionTypeLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectQuestionTypeLabel.Location = new System.Drawing.Point(189, 87);
            this.SelectQuestionTypeLabel.Name = "SelectQuestionTypeLabel";
            this.SelectQuestionTypeLabel.Size = new System.Drawing.Size(409, 30);
            this.SelectQuestionTypeLabel.TabIndex = 5;
            this.SelectQuestionTypeLabel.Text = "Select a question type from the box below.\r\n";
            // 
            // ClickInfoLabel
            // 
            this.ClickInfoLabel.AutoSize = true;
            this.ClickInfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClickInfoLabel.Location = new System.Drawing.Point(288, 117);
            this.ClickInfoLabel.Name = "ClickInfoLabel";
            this.ClickInfoLabel.Size = new System.Drawing.Size(214, 30);
            this.ClickInfoLabel.TabIndex = 8;
            this.ClickInfoLabel.Text = "Then click the button.";
            // 
            // QuestTypeComboBox
            // 
            this.QuestTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.QuestTypeComboBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestTypeComboBox.FormattingEnabled = true;
            this.QuestTypeComboBox.Items.AddRange(new object[] {
            "True or False ",
            "Multiple Choice ",
            "Fill in the blank ",
            "Flashcards",
            "One word answer"});
            this.QuestTypeComboBox.Location = new System.Drawing.Point(189, 150);
            this.QuestTypeComboBox.Name = "QuestTypeComboBox";
            this.QuestTypeComboBox.Size = new System.Drawing.Size(320, 38);
            this.QuestTypeComboBox.TabIndex = 9;
            // 
            // SelectQuestionButton
            // 
            this.SelectQuestionButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectQuestionButton.Location = new System.Drawing.Point(515, 150);
            this.SelectQuestionButton.Name = "SelectQuestionButton";
            this.SelectQuestionButton.Size = new System.Drawing.Size(93, 38);
            this.SelectQuestionButton.TabIndex = 10;
            this.SelectQuestionButton.Text = "Lets go";
            this.SelectQuestionButton.UseVisualStyleBackColor = true;
            this.SelectQuestionButton.Click += new System.EventHandler(this.SelectQuestionButton_Click);
            // 
            // TextLabel
            // 
            this.TextLabel.AutoSize = true;
            this.TextLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TextLabel.Location = new System.Drawing.Point(231, 191);
            this.TextLabel.Name = "TextLabel";
            this.TextLabel.Size = new System.Drawing.Size(314, 60);
            this.TextLabel.TabIndex = 11;
            this.TextLabel.Text = "        When you are finished, \r\npress the button to set the work.\r\n";
            // 
            // QuestionsRichTextBox
            // 
            this.QuestionsRichTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionsRichTextBox.Location = new System.Drawing.Point(231, 254);
            this.QuestionsRichTextBox.Name = "QuestionsRichTextBox";
            this.QuestionsRichTextBox.Size = new System.Drawing.Size(320, 176);
            this.QuestionsRichTextBox.TabIndex = 12;
            this.QuestionsRichTextBox.Text = "";
            // 
            // RefreshQuestionsButton
            // 
            this.RefreshQuestionsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RefreshQuestionsButton.Location = new System.Drawing.Point(567, 254);
            this.RefreshQuestionsButton.Name = "RefreshQuestionsButton";
            this.RefreshQuestionsButton.Size = new System.Drawing.Size(93, 38);
            this.RefreshQuestionsButton.TabIndex = 14;
            this.RefreshQuestionsButton.Text = "Refresh";
            this.RefreshQuestionsButton.UseVisualStyleBackColor = true;
            this.RefreshQuestionsButton.Click += new System.EventHandler(this.RefreshQuestionsButton_Click);
            // 
            // SetWorkButton
            // 
            this.SetWorkButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetWorkButton.Location = new System.Drawing.Point(567, 343);
            this.SetWorkButton.Name = "SetWorkButton";
            this.SetWorkButton.Size = new System.Drawing.Size(93, 38);
            this.SetWorkButton.TabIndex = 15;
            this.SetWorkButton.Text = "Set work";
            this.SetWorkButton.UseVisualStyleBackColor = true;
            this.SetWorkButton.Click += new System.EventHandler(this.SetWorkButton_Click);
            // 
            // ChangeClassButton
            // 
            this.ChangeClassButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ChangeClassButton.Location = new System.Drawing.Point(653, 402);
            this.ChangeClassButton.Name = "ChangeClassButton";
            this.ChangeClassButton.Size = new System.Drawing.Size(135, 36);
            this.ChangeClassButton.TabIndex = 16;
            this.ChangeClassButton.Text = "Change Class ->";
            this.ChangeClassButton.UseVisualStyleBackColor = true;
            this.ChangeClassButton.Click += new System.EventHandler(this.ChangeClassButton_Click);
            // 
            // MainScreenButton
            // 
            this.MainScreenButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainScreenButton.Location = new System.Drawing.Point(12, 402);
            this.MainScreenButton.Name = "MainScreenButton";
            this.MainScreenButton.Size = new System.Drawing.Size(125, 36);
            this.MainScreenButton.TabIndex = 17;
            this.MainScreenButton.Text = "<- Main Screen";
            this.MainScreenButton.UseVisualStyleBackColor = true;
            this.MainScreenButton.Click += new System.EventHandler(this.MainScreenButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // Setting_Assignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.MainScreenButton);
            this.Controls.Add(this.ChangeClassButton);
            this.Controls.Add(this.SetWorkButton);
            this.Controls.Add(this.RefreshQuestionsButton);
            this.Controls.Add(this.QuestionsRichTextBox);
            this.Controls.Add(this.TextLabel);
            this.Controls.Add(this.SelectQuestionButton);
            this.Controls.Add(this.QuestTypeComboBox);
            this.Controls.Add(this.ClickInfoLabel);
            this.Controls.Add(this.SelectQuestionTypeLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.ProjectNameLogo);
            this.Name = "Setting_Assignments";
            this.Text = "Setting_Assignments";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ProjectNameLogo;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label SelectQuestionTypeLabel;
        private System.Windows.Forms.Label ClickInfoLabel;
        private System.Windows.Forms.ComboBox QuestTypeComboBox;
        private System.Windows.Forms.Button SelectQuestionButton;
        private System.Windows.Forms.Label TextLabel;
        private System.Windows.Forms.RichTextBox QuestionsRichTextBox;
        private System.Windows.Forms.Button RefreshQuestionsButton;
        private System.Windows.Forms.Button SetWorkButton;
        private System.Windows.Forms.Button ChangeClassButton;
        private System.Windows.Forms.Button MainScreenButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}