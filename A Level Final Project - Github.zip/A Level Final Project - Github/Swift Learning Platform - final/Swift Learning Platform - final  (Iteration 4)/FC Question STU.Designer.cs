﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class FC_Question_STU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.FlashcardLabel = new System.Windows.Forms.Label();
            this.FlashcardTextBox = new System.Windows.Forms.TextBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ContinueButton = new System.Windows.Forms.Button();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 5;
            this.NameLogo.Text = "Swift";
            // 
            // FlashcardLabel
            // 
            this.FlashcardLabel.AutoSize = true;
            this.FlashcardLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FlashcardLabel.Location = new System.Drawing.Point(334, 50);
            this.FlashcardLabel.Name = "FlashcardLabel";
            this.FlashcardLabel.Size = new System.Drawing.Size(115, 30);
            this.FlashcardLabel.TabIndex = 14;
            this.FlashcardLabel.Text = "Flashcard...";
            // 
            // FlashcardTextBox
            // 
            this.FlashcardTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FlashcardTextBox.Location = new System.Drawing.Point(46, 124);
            this.FlashcardTextBox.Name = "FlashcardTextBox";
            this.FlashcardTextBox.ReadOnly = true;
            this.FlashcardTextBox.Size = new System.Drawing.Size(695, 35);
            this.FlashcardTextBox.TabIndex = 15;
            this.FlashcardTextBox.Text = "Question Here...";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 398);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(160, 40);
            this.BackButton.TabIndex = 16;
            this.BackButton.Text = "<- Stop Assignment";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ContinueButton
            // 
            this.ContinueButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButton.Location = new System.Drawing.Point(593, 398);
            this.ContinueButton.Name = "ContinueButton";
            this.ContinueButton.Size = new System.Drawing.Size(195, 40);
            this.ContinueButton.TabIndex = 17;
            this.ContinueButton.Text = "Reveal the answer ->";
            this.ContinueButton.UseVisualStyleBackColor = true;
            this.ContinueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(279, 80);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(218, 30);
            this.InfoLabel.TabIndex = 18;
            this.InfoLabel.Text = "Here is the Question...";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // FC_Question_STU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.ContinueButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.FlashcardTextBox);
            this.Controls.Add(this.FlashcardLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "FC_Question_STU";
            this.Text = "Flashcard Question";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label FlashcardLabel;
        private System.Windows.Forms.TextBox FlashcardTextBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ContinueButton;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}