﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class AccountCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.StuTeaLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.StudentButton = new System.Windows.Forms.Button();
            this.TeacherButton = new System.Windows.Forms.Button();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.EmailInputTextbox = new System.Windows.Forms.TextBox();
            this.ContinueButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.CreatePassTextBox = new System.Windows.Forms.TextBox();
            this.ConfirmPassLabel = new System.Windows.Forms.Label();
            this.ConfirmPassTextbox = new System.Windows.Forms.TextBox();
            this.PassErrorMessageLabel = new System.Windows.Forms.Label();
            this.CreateAccountButton = new System.Windows.Forms.Button();
            this.PassInfoLabel = new System.Windows.Forms.Label();
            this.SignInButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WelcomeLabel.Location = new System.Drawing.Point(233, 9);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(363, 30);
            this.WelcomeLabel.TabIndex = 4;
            this.WelcomeLabel.Text = "Welcome, time to create an account...";
            // 
            // StuTeaLabel
            // 
            this.StuTeaLabel.AutoSize = true;
            this.StuTeaLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StuTeaLabel.Location = new System.Drawing.Point(269, 39);
            this.StuTeaLabel.Name = "StuTeaLabel";
            this.StuTeaLabel.Size = new System.Drawing.Size(290, 30);
            this.StuTeaLabel.TabIndex = 24;
            this.StuTeaLabel.Text = "Are you a Student or Teacher?";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 25;
            this.NameLabel.Text = "Swift";
            // 
            // StudentButton
            // 
            this.StudentButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StudentButton.Location = new System.Drawing.Point(233, 72);
            this.StudentButton.Name = "StudentButton";
            this.StudentButton.Size = new System.Drawing.Size(108, 44);
            this.StudentButton.TabIndex = 27;
            this.StudentButton.Text = "Student";
            this.StudentButton.UseVisualStyleBackColor = true;
            this.StudentButton.Click += new System.EventHandler(this.StudentButton_Click);
            // 
            // TeacherButton
            // 
            this.TeacherButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TeacherButton.Location = new System.Drawing.Point(488, 73);
            this.TeacherButton.Name = "TeacherButton";
            this.TeacherButton.Size = new System.Drawing.Size(108, 43);
            this.TeacherButton.TabIndex = 28;
            this.TeacherButton.Text = "Teacher";
            this.TeacherButton.UseVisualStyleBackColor = true;
            this.TeacherButton.Click += new System.EventHandler(this.TeacherButton_Click);
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(242, 119);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(354, 30);
            this.InfoLabel.TabIndex = 29;
            this.InfoLabel.Text = "Enter an email address to get started";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailLabel.Location = new System.Drawing.Point(114, 157);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(68, 30);
            this.EmailLabel.TabIndex = 30;
            this.EmailLabel.Text = "Email:";
            // 
            // EmailInputTextbox
            // 
            this.EmailInputTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailInputTextbox.Location = new System.Drawing.Point(188, 157);
            this.EmailInputTextbox.Name = "EmailInputTextbox";
            this.EmailInputTextbox.Size = new System.Drawing.Size(463, 35);
            this.EmailInputTextbox.TabIndex = 31;
            // 
            // ContinueButton
            // 
            this.ContinueButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButton.Location = new System.Drawing.Point(657, 154);
            this.ContinueButton.Name = "ContinueButton";
            this.ContinueButton.Size = new System.Drawing.Size(111, 40);
            this.ContinueButton.TabIndex = 32;
            this.ContinueButton.Text = "Let\'s go ";
            this.ContinueButton.UseVisualStyleBackColor = true;
            this.ContinueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(188, 195);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorLabel.TabIndex = 33;
            this.ErrorLabel.Text = "Filler Text";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLabel.Location = new System.Drawing.Point(78, 231);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(104, 30);
            this.PasswordLabel.TabIndex = 34;
            this.PasswordLabel.Text = "Password:";
            // 
            // CreatePassTextBox
            // 
            this.CreatePassTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreatePassTextBox.Location = new System.Drawing.Point(183, 228);
            this.CreatePassTextBox.Name = "CreatePassTextBox";
            this.CreatePassTextBox.Size = new System.Drawing.Size(468, 35);
            this.CreatePassTextBox.TabIndex = 35;
            // 
            // ConfirmPassLabel
            // 
            this.ConfirmPassLabel.AutoSize = true;
            this.ConfirmPassLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConfirmPassLabel.Location = new System.Drawing.Point(-2, 277);
            this.ConfirmPassLabel.Name = "ConfirmPassLabel";
            this.ConfirmPassLabel.Size = new System.Drawing.Size(184, 30);
            this.ConfirmPassLabel.TabIndex = 36;
            this.ConfirmPassLabel.Text = "Confirm Password:";
            // 
            // ConfirmPassTextbox
            // 
            this.ConfirmPassTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConfirmPassTextbox.Location = new System.Drawing.Point(183, 274);
            this.ConfirmPassTextbox.Name = "ConfirmPassTextbox";
            this.ConfirmPassTextbox.Size = new System.Drawing.Size(468, 35);
            this.ConfirmPassTextbox.TabIndex = 37;
            // 
            // PassErrorMessageLabel
            // 
            this.PassErrorMessageLabel.AutoSize = true;
            this.PassErrorMessageLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PassErrorMessageLabel.ForeColor = System.Drawing.Color.Red;
            this.PassErrorMessageLabel.Location = new System.Drawing.Point(183, 312);
            this.PassErrorMessageLabel.Name = "PassErrorMessageLabel";
            this.PassErrorMessageLabel.Size = new System.Drawing.Size(99, 30);
            this.PassErrorMessageLabel.TabIndex = 38;
            this.PassErrorMessageLabel.Text = "Filler Text";
            // 
            // CreateAccountButton
            // 
            this.CreateAccountButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateAccountButton.Location = new System.Drawing.Point(657, 274);
            this.CreateAccountButton.Name = "CreateAccountButton";
            this.CreateAccountButton.Size = new System.Drawing.Size(111, 39);
            this.CreateAccountButton.TabIndex = 39;
            this.CreateAccountButton.Text = "Let\'s go";
            this.CreateAccountButton.UseVisualStyleBackColor = true;
            this.CreateAccountButton.Click += new System.EventHandler(this.CreateAccountButton_Click);
            // 
            // PassInfoLabel
            // 
            this.PassInfoLabel.AutoSize = true;
            this.PassInfoLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PassInfoLabel.Location = new System.Drawing.Point(269, 342);
            this.PassInfoLabel.Name = "PassInfoLabel";
            this.PassInfoLabel.Size = new System.Drawing.Size(307, 105);
            this.PassInfoLabel.TabIndex = 40;
            this.PassInfoLabel.Text = "Passwords must contain:\r\n-at least one capital and lowercase letter\r\n-be at least" +
    " 10 characters long\r\n-at least one number \r\n-at least one special character - !," +
    "@,*,£, ect. \r\n";
            // 
            // SignInButton
            // 
            this.SignInButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SignInButton.Location = new System.Drawing.Point(12, 402);
            this.SignInButton.Name = "SignInButton";
            this.SignInButton.Size = new System.Drawing.Size(120, 36);
            this.SignInButton.TabIndex = 42;
            this.SignInButton.Text = "<- Sign In";
            this.SignInButton.UseVisualStyleBackColor = true;
            this.SignInButton.Click += new System.EventHandler(this.SignInButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 43;
            this.LogoPictureBox.TabStop = false;
            // 
            // AccountCreate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.SignInButton);
            this.Controls.Add(this.PassInfoLabel);
            this.Controls.Add(this.CreateAccountButton);
            this.Controls.Add(this.PassErrorMessageLabel);
            this.Controls.Add(this.ConfirmPassTextbox);
            this.Controls.Add(this.ConfirmPassLabel);
            this.Controls.Add(this.CreatePassTextBox);
            this.Controls.Add(this.PasswordLabel);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.ContinueButton);
            this.Controls.Add(this.EmailInputTextbox);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.TeacherButton);
            this.Controls.Add(this.StudentButton);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.StuTeaLabel);
            this.Controls.Add(this.WelcomeLabel);
            this.Name = "AccountCreate";
            this.Text = "AccountCreate";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Label StuTeaLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button StudentButton;
        private System.Windows.Forms.Button TeacherButton;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox EmailInputTextbox;
        private System.Windows.Forms.Button ContinueButton;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox CreatePassTextBox;
        private System.Windows.Forms.Label ConfirmPassLabel;
        private System.Windows.Forms.TextBox ConfirmPassTextbox;
        private System.Windows.Forms.Label PassErrorMessageLabel;
        private System.Windows.Forms.Button CreateAccountButton;
        private System.Windows.Forms.Label PassInfoLabel;
        private System.Windows.Forms.Button SignInButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}