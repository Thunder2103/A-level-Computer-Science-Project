﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class FB_TEA : Form
    {
        //global variables
        string globalTeacherId;
        string globalClasses;
        string globalWorkID;
        public FB_TEA(string teacherId, string classes, string workId)
        {
            InitializeComponent(); 
            //values passed from previous form stored in global variables 
            globalTeacherId = teacherId;
            globalClasses = classes;
            globalWorkID = workId;
        }

        private void SetQuestionButton_Click(object sender, EventArgs e)
        {
            
            string question = QuestionTextbox.Text; //value in Question textbox stored in a variable called question
            string word = AnswerTextBox.Text; //value in Answer textbox stored in variable called word
            int ansLenth = AnswerTextBox.Text.Length; //get number of characters in the word variable
            

            //counts the amount of underscores in the question variable 
            int underscoreCount = question.Count(x => x == '_');
            

            //if either textboxes are empty
            if (QuestionTextbox.Text == string.Empty || AnswerTextBox.Text == string.Empty)
            {
                ErrorLabel.Text = "Please fill in all the boxes"; //output error message 
            }
            else if (underscoreCount == 0) //if there are no underscored in the question variable
            {
                ErrorLabel.Text = "replace the answer word with: _"; //output error message
            }
            else if (underscoreCount != ansLenth) //if the number of underscores and the amount of characters in the answer don't match
            {
                ErrorLabel.Text = "Amount of underscores don't match amount of letters in word."; //output error message 
            }
            else
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                string answer = AnswerTextBox.Text.ToString().ToLower(); 
                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to database
                //query to insert question and answer into the databases's question table
                OleDbCommand insertQuestionOneWord = new OleDbCommand("Insert Into Questions([WorkID],[Question Type],[Question]," +
                    "[Correct Answer]) Values(@workID,'FB',@question,@correctAns)", con);
                insertQuestionOneWord.Parameters.AddRange(new OleDbParameter[]
                {
                        new OleDbParameter("@workID", globalWorkID), //WorkID paramter
                        new OleDbParameter("@question", QuestionTextbox.Text), //Question parameter
                        new OleDbParameter("@correctAns", answer), //Correct answer paramter
                });
                insertQuestionOneWord.ExecuteNonQuery(); //execute query
                insertQuestionOneWord.Dispose(); //dispose query
                con.Close(); //close connection

                //load Setting Assignment form
                Setting_Assignments chooseAssignement = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
                this.Hide();
                chooseAssignement.Show();
            }


        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //load Setting Assignment form
            Setting_Assignments chooseAssignement = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
            this.Hide();
            chooseAssignement.Show();

        }
    }
}
