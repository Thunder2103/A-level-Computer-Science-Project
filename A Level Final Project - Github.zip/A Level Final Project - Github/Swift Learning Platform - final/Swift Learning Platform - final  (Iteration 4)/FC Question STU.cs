﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class FC_Question_STU : Form
    {
        //global variables
        string globalStudentID = "";
        int globalCount;
        string globalWorkID = "";
        int globalQuestionCount;
        public FC_Question_STU(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            //values passed from previous forms stored in global variables
            globalStudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database
            //Query to get question from Questions table
            string getQuestion = ("Select [Question] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(getQuestion, con); //data adapter
            DataSet ds = new DataSet(); //returned data
            DataTable dt = new DataTable(); //where data will be stored

            da.Fill(ds, "QuestionAnswer"); //data adapter converts data set into useable format
            dt = ds.Tables["QuestionAnswer"]; //fill data table with data

            //Text as row 0 at index corresponding to the value of questionCount is stored in variable
            FlashcardTextBox.Text = dt.Rows[questionCount][0].ToString();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide();
            viewAssignments.Show();
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        { 
            //Loads Flashcard answer form
            FC_Answer_STU fcANswer = new FC_Answer_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide();
            fcANswer.Show();

        }
    }
}
