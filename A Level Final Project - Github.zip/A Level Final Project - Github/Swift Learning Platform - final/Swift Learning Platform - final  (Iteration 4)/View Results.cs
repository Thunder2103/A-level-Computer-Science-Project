﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class View_Results : Form
    {
        //global variables
        string globalTeacherID;
        string globalWorkID;
        public View_Results(string teacherID, string workID)
        {
            InitializeComponent();
            //values passed from previous form stored in global variable
            globalTeacherID = teacherID;
            globalWorkID = workID;

            //ActiveAssignmentsRichTB made read only (uneditable). 
            ActiveAssignmentsRichTB.ReadOnly = true;
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database


            DataSet ds = new DataSet(); //data that will be returned
            DataTable dt = new DataTable(); //where data will be stored

            //query to select the StudentID and Score linked to the WorkID from the
            //Results table and return them in descending order
            string getStudentScores = ("Select StudentID, Score from Results where WorkID='" + globalWorkID + 
                "' Order by Score DESC");

            //puts data in a format that can be used
            OleDbDataAdapter da = new OleDbDataAdapter(getStudentScores, con);


            da.Fill(ds, "Scores");
            dt = ds.Tables["Scores"]; //fills datatable with returned data 
            int rowCount = (dt.Rows.Count) - 1; //stores number of rows in the datatab;e

            //for loop iterates through rows of the datatable
            for (int i = 0; i <= rowCount; i++)
            { 
                //adds data at each index from the datatable into ActiveAssignmentsRichTB 
                ActiveAssignmentsRichTB.Text += Environment.NewLine + "Student: " + dt.Rows[i][0].ToString() + "  " +
                    "Score: " + dt.Rows[i][1].ToString();
            }
            da.Dispose(); //diposes data adapter
            ds.Dispose(); //diposes data set
            dt.Dispose(); //diposes data table
            con.Close(); //closes connection.

        }

        private void WorkResultsButton_Click(object sender, EventArgs e)
        {
            //Loads choose assignments
            Choose_Result chooseResults = new Choose_Result(globalTeacherID);
            this.Hide(); 
            chooseResults.Show();
        }

        private void MainPageButton_Click(object sender, EventArgs e)
        { 
            //loads teachers homepage form
            Teacher_Homepage teacherHomepage = new Teacher_Homepage(globalTeacherID);
            this.Hide();
            teacherHomepage.Show();
        }

        private void View_Results_Load(object sender, EventArgs e)
        {

        }
    }
}
