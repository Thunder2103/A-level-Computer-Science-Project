﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class ViewClassesSTU : Form
    {
        string globalstudentID = "";
        public ViewClassesSTU(string studentID)
        {
            InitializeComponent();
            //value passed from previous form stored in global variables
            globalstudentID = studentID;

            ViewingClassesRichTextbox.Text = "Your classes:";
            ViewingClassesRichTextbox.ReadOnly = true;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine to query database
            string dbSource = "Data Source=[Database path]"; //where database is stored

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //estbalish connection to database

            DataSet ds = new DataSet(); //data returned
            DataTable dt = new DataTable(); //where data will be stored

            //command to Select all Classes a student is in and put them in ascending order
            string cmd = ("Select ClassID From ClassStudent Where StudentID='" + globalstudentID + "' " +
                "Order by ClassID ASC");
            //declares data adapter
            OleDbDataAdapter da = new OleDbDataAdapter(cmd, con);

            da.Fill(ds, "ClassStore"); //data converted into useable format
            dt = ds.Tables["ClassStore"]; //data table filled with data
            int rowCount = (dt.Rows.Count) - 1; //varaible to store the number of rows the datatable has

            for (int i = 0; i <= rowCount; i++) //for loop iterates throught the datatable
            {
                //Data at row corresponding to value of i and index 0 is displayed in the richtextbox
                ViewingClassesRichTextbox.Text += Environment.NewLine + "Class Number: " + dt.Rows[i][0].ToString() + ".";

            }
            da.Dispose(); //diposes adapter
            ds.Dispose(); //disposes data set
            dt.Dispose(); //diposes data table
            con.Close(); //closes connection



        }

        private void MainPageButton_Click(object sender, EventArgs e)
        {
            //Loads Students homepage
            Student_Homepage studentHomepage = new Student_Homepage(globalstudentID);
            this.Hide();
            studentHomepage.Show();
        }

        private void JoinClassButton_Click(object sender, EventArgs e)
        {
            //Loads Join a class form
            Join_Class joinClass = new Join_Class(globalstudentID);
            this.Hide();
            joinClass.Show();
        }
    }
}
