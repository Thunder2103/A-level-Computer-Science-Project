﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class MC_TEA : Form
    {
        //global variables
        string globalTeacherId;
        string globalClasses;
        string globalWorkID;

      
        public MC_TEA(string teacherId, string classes, string workID)
        {
            InitializeComponent(); 
            //parameters passed from previous form are stored in global variables
            globalTeacherId = teacherId;
            globalClasses = classes;
            globalWorkID = workID;
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads the Setting Assignments form
            Setting_Assignments setAssignements = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
            this.Hide();
            setAssignements.Show();
        }

        private void SetQuestionButton_Click(object sender, EventArgs e)
        {
            //if any of the textboxes are empty
            if (QuestionTextBox.Text == string.Empty || CorrectAnsTextbox.Text == string.Empty || AnsTwoTextBox.Text == string.Empty || AnsThreeTextBox.Text == string.Empty || AnsFourTextBox.Text == string.Empty)
            { 
                //error message outputted
                ErrorLabel.Text = "Please fill in all the boxes";
            } 
            else
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to the database

                //Query to add Questions and answers to the database
                OleDbCommand insertMCQuestion = new OleDbCommand("Insert Into Questions([WorkID],[Question Type],[Question],[Correct Answer]," +
                    "[Answer 2],[Answer 3],[Answer 4]) Values(@workID, 'MC', @question, @correctAns, @ans2, @ans3, @ans4)", con);
                //Query parameters
                insertMCQuestion.Parameters.AddRange(new OleDbParameter[]
                { 
                        new OleDbParameter("@workID", globalWorkID), //WorkID paramter
                        new OleDbParameter("@question", QuestionTextBox.Text), //Question paramater
                        new OleDbParameter("@correctAns", CorrectAnsTextbox.Text), //Correct Answer parameter
                        new OleDbParameter("@ans2", AnsTwoTextBox.Text), //Second answer parameter
                        new OleDbParameter("@ans3", AnsThreeTextBox.Text), //Third answer parameter
                        new OleDbParameter("@ans4", AnsFourTextBox.Text), //Fourth answer parameter

                });
                insertMCQuestion.ExecuteNonQuery(); //Executes Query
                insertMCQuestion.Dispose(); //diposes command
                con.Close(); //closes connection
               

                //loads Setting Assignments form
                Setting_Assignments chooseAssignement = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
                this.Hide();
                chooseAssignement.Show();

            }

        }
    }
}
