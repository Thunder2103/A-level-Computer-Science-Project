﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class CreateAssignment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.SelectClassLabel = new System.Windows.Forms.Label();
            this.ClassesLabel = new System.Windows.Forms.Label();
            this.SelectClassComboBox = new System.Windows.Forms.ComboBox();
            this.CreateWorkButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.MainPageButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(254, 65);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(292, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Hello, time to set some work...";
            // 
            // SelectClassLabel
            // 
            this.SelectClassLabel.AutoSize = true;
            this.SelectClassLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectClassLabel.Location = new System.Drawing.Point(284, 106);
            this.SelectClassLabel.Name = "SelectClassLabel";
            this.SelectClassLabel.Size = new System.Drawing.Size(213, 30);
            this.SelectClassLabel.TabIndex = 5;
            this.SelectClassLabel.Text = "Please select a class...";
            // 
            // ClassesLabel
            // 
            this.ClassesLabel.AutoSize = true;
            this.ClassesLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClassesLabel.Location = new System.Drawing.Point(254, 156);
            this.ClassesLabel.Name = "ClassesLabel";
            this.ClassesLabel.Size = new System.Drawing.Size(85, 30);
            this.ClassesLabel.TabIndex = 7;
            this.ClassesLabel.Text = "Classes:";
            // 
            // SelectClassComboBox
            // 
            this.SelectClassComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectClassComboBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectClassComboBox.FormattingEnabled = true;
            this.SelectClassComboBox.Location = new System.Drawing.Point(345, 157);
            this.SelectClassComboBox.Name = "SelectClassComboBox";
            this.SelectClassComboBox.Size = new System.Drawing.Size(201, 33);
            this.SelectClassComboBox.TabIndex = 8;
            // 
            // CreateWorkButton
            // 
            this.CreateWorkButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateWorkButton.Location = new System.Drawing.Point(254, 225);
            this.CreateWorkButton.Name = "CreateWorkButton";
            this.CreateWorkButton.Size = new System.Drawing.Size(292, 40);
            this.CreateWorkButton.TabIndex = 9;
            this.CreateWorkButton.Text = "Click here to create work...";
            this.CreateWorkButton.UseVisualStyleBackColor = true;
            this.CreateWorkButton.Click += new System.EventHandler(this.CreateWorkButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(12, 401);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(90, 37);
            this.ExitButton.TabIndex = 10;
            this.ExitButton.Text = "<- Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MainPageButton
            // 
            this.MainPageButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainPageButton.Location = new System.Drawing.Point(629, 399);
            this.MainPageButton.Name = "MainPageButton";
            this.MainPageButton.Size = new System.Drawing.Size(159, 39);
            this.MainPageButton.TabIndex = 11;
            this.MainPageButton.Text = "Main Page ->";
            this.MainPageButton.UseVisualStyleBackColor = true;
            this.MainPageButton.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(254, 280);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(56, 30);
            this.ErrorLabel.TabIndex = 12;
            this.ErrorLabel.Text = "Filler";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 44;
            this.LogoPictureBox.TabStop = false;
            // 
            // CreateAssignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.MainPageButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CreateWorkButton);
            this.Controls.Add(this.SelectClassComboBox);
            this.Controls.Add(this.ClassesLabel);
            this.Controls.Add(this.SelectClassLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "CreateAssignment";
            this.Text = "CreateAssignment";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label SelectClassLabel;
        private System.Windows.Forms.Label ClassesLabel;
        private System.Windows.Forms.ComboBox SelectClassComboBox;
        private System.Windows.Forms.Button CreateWorkButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button MainPageButton;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}