﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class TeacherLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwiftLabel = new System.Windows.Forms.Label();
            this.TeacherWelcome = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.Label();
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.TeaUsernameTextBox = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordText = new System.Windows.Forms.TextBox();
            this.ErrorMessageLabel = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.Button();
            this.AccountRecoverButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.InformationLabel = new System.Windows.Forms.Label();
            this.AccountCreateButton = new System.Windows.Forms.Button();
            this.HomepageButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwiftLabel
            // 
            this.SwiftLabel.AutoSize = true;
            this.SwiftLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwiftLabel.Location = new System.Drawing.Point(12, 9);
            this.SwiftLabel.Name = "SwiftLabel";
            this.SwiftLabel.Size = new System.Drawing.Size(58, 30);
            this.SwiftLabel.TabIndex = 2;
            this.SwiftLabel.Text = "Swift";
            // 
            // TeacherWelcome
            // 
            this.TeacherWelcome.AutoSize = true;
            this.TeacherWelcome.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TeacherWelcome.Location = new System.Drawing.Point(287, 50);
            this.TeacherWelcome.Name = "TeacherWelcome";
            this.TeacherWelcome.Size = new System.Drawing.Size(191, 30);
            this.TeacherWelcome.TabIndex = 4;
            this.TeacherWelcome.Text = "Welcome Teacher...";
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Info.Location = new System.Drawing.Point(153, 80);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(473, 30);
            this.Info.TabIndex = 5;
            this.Info.Text = "To sign in, please enter a Username or Password...";
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameLabel.Location = new System.Drawing.Point(153, 156);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(111, 30);
            this.UsernameLabel.TabIndex = 6;
            this.UsernameLabel.Text = "Username:";
            // 
            // TeaUsernameTextBox
            // 
            this.TeaUsernameTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TeaUsernameTextBox.Location = new System.Drawing.Point(259, 153);
            this.TeaUsernameTextBox.Name = "TeaUsernameTextBox";
            this.TeaUsernameTextBox.Size = new System.Drawing.Size(367, 35);
            this.TeaUsernameTextBox.TabIndex = 7;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLabel.Location = new System.Drawing.Point(153, 215);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(104, 30);
            this.PasswordLabel.TabIndex = 8;
            this.PasswordLabel.Text = "Password:";
            // 
            // PasswordText
            // 
            this.PasswordText.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordText.Location = new System.Drawing.Point(259, 215);
            this.PasswordText.Name = "PasswordText";
            this.PasswordText.Size = new System.Drawing.Size(367, 35);
            this.PasswordText.TabIndex = 9;
            // 
            // ErrorMessageLabel
            // 
            this.ErrorMessageLabel.AutoSize = true;
            this.ErrorMessageLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorMessageLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorMessageLabel.Location = new System.Drawing.Point(259, 253);
            this.ErrorMessageLabel.Name = "ErrorMessageLabel";
            this.ErrorMessageLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorMessageLabel.TabIndex = 11;
            this.ErrorMessageLabel.Text = "Filler Text";
            // 
            // Login
            // 
            this.Login.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Login.Location = new System.Drawing.Point(259, 286);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(140, 46);
            this.Login.TabIndex = 12;
            this.Login.Text = "Login";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // AccountRecoverButton
            // 
            this.AccountRecoverButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountRecoverButton.Location = new System.Drawing.Point(486, 286);
            this.AccountRecoverButton.Name = "AccountRecoverButton";
            this.AccountRecoverButton.Size = new System.Drawing.Size(140, 46);
            this.AccountRecoverButton.TabIndex = 13;
            this.AccountRecoverButton.Text = "Can\'t sign in?";
            this.AccountRecoverButton.UseVisualStyleBackColor = true;
            this.AccountRecoverButton.Click += new System.EventHandler(this.AccountRecoverButton_Click);
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit.Location = new System.Drawing.Point(12, 392);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(88, 46);
            this.Exit.TabIndex = 14;
            this.Exit.Text = "<- Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // InformationLabel
            // 
            this.InformationLabel.AutoSize = true;
            this.InformationLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InformationLabel.Location = new System.Drawing.Point(217, 392);
            this.InformationLabel.Name = "InformationLabel";
            this.InformationLabel.Size = new System.Drawing.Size(237, 30);
            this.InformationLabel.TabIndex = 15;
            this.InformationLabel.Text = "Don\'t have an account?:";
            // 
            // AccountCreateButton
            // 
            this.AccountCreateButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountCreateButton.Location = new System.Drawing.Point(449, 394);
            this.AccountCreateButton.Name = "AccountCreateButton";
            this.AccountCreateButton.Size = new System.Drawing.Size(120, 31);
            this.AccountCreateButton.TabIndex = 16;
            this.AccountCreateButton.Text = "Create one";
            this.AccountCreateButton.UseVisualStyleBackColor = true;
            this.AccountCreateButton.Click += new System.EventHandler(this.AccountCreateButton_Click);
            // 
            // HomepageButton
            // 
            this.HomepageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HomepageButton.Location = new System.Drawing.Point(660, 394);
            this.HomepageButton.Name = "HomepageButton";
            this.HomepageButton.Size = new System.Drawing.Size(128, 46);
            this.HomepageButton.TabIndex = 17;
            this.HomepageButton.Text = "Homepage ->";
            this.HomepageButton.UseVisualStyleBackColor = true;
            this.HomepageButton.Click += new System.EventHandler(this.HomepageButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // TeacherLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.HomepageButton);
            this.Controls.Add(this.AccountCreateButton);
            this.Controls.Add(this.InformationLabel);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.AccountRecoverButton);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.ErrorMessageLabel);
            this.Controls.Add(this.PasswordText);
            this.Controls.Add(this.PasswordLabel);
            this.Controls.Add(this.TeaUsernameTextBox);
            this.Controls.Add(this.UsernameLabel);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.TeacherWelcome);
            this.Controls.Add(this.SwiftLabel);
            this.Name = "TeacherLogin";
            this.Text = "TeacherLogin";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwiftLabel;
        private System.Windows.Forms.Label TeacherWelcome;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.TextBox TeaUsernameTextBox;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox PasswordText;
        private System.Windows.Forms.Label ErrorMessageLabel;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button AccountRecoverButton;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label InformationLabel;
        private System.Windows.Forms.Button AccountCreateButton;
        private System.Windows.Forms.Button HomepageButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}