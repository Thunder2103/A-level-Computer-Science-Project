﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Setting_Assignments : Form
    {
        //global variables
        string globalTeacherID;
        string globalClasses;
        string globalWorkID;
        public Setting_Assignments(string teacherID, string classes, string workID)
        {
            InitializeComponent();
            globalTeacherID = teacherID; //values of paramters passed from previous forms are placed in global variables
            globalClasses = classes; 
            globalWorkID = workID;

        
            QuestionsRichTextBox.ReadOnly = true; //makes the richtextbox not editable. 
            QuestionsRichTextBox.Text += "Your Questions:"; //adds text to richtextbox

        }

        private void MainScreenButton_Click(object sender, EventArgs e)
        { 
            
            OleDbConnection con = new OleDbConnection();
            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database

            //Query to delete any questions a user may have made
            OleDbCommand deleteQuestions = new OleDbCommand ("Delete from [Questions] where WorkID='" + globalWorkID + "'",con);
            deleteQuestions.ExecuteNonQuery(); //executes command
            deleteQuestions.Dispose(); //diposes command

            //Query to delete WorkID and TeacherID from Results table
            OleDbCommand deleteWorkID = new OleDbCommand("Delete from [Work] where WorkID='" + globalWorkID + "'", con); 
            deleteWorkID.ExecuteNonQuery(); //executes command
            deleteWorkID.Dispose(); //diposes command

            con.Close(); //closes connection
            
            //loads teacher homepage
            Teacher_Homepage teacherHomepage = new Teacher_Homepage(globalTeacherID);
            this.Hide(); 
            teacherHomepage.Show();
        }

        private void ChangeClassButton_Click(object sender, EventArgs e)
        { 
            //loads create assignment form 
            CreateAssignment createAssignment = new CreateAssignment(globalTeacherID, globalWorkID);
            this.Hide(); 
            createAssignment.Show(); 
        }

        private void SelectQuestionButton_Click(object sender, EventArgs e)
        { 
            //case and switch statement to load the right form depending on option selected from combo box
            switch (QuestTypeComboBox.SelectedIndex)
            {
                case 0: 
                    //loads True or False form
                    TF_TEA trueFalseTemplate = new TF_TEA(globalTeacherID, globalClasses, globalWorkID);
                    this.Hide();
                    trueFalseTemplate.Show();
                    break;
                case 1: 
                    //loads Multiple choice form
                    MC_TEA multChoiceTemplate = new MC_TEA(globalTeacherID, globalClasses, globalWorkID);
                    this.Hide();
                    multChoiceTemplate.Show();
                    break;
                case 2: 
                    //loads fill in the blank form
                    FB_TEA fillInTheBlankTemplate = new FB_TEA(globalTeacherID, globalClasses, globalWorkID);
                    this.Hide();
                    fillInTheBlankTemplate.Show();
                    break;
                case 3: 
                    //loads flashcard form
                    FC_TEA flashcardTemplate = new FC_TEA(globalTeacherID, globalClasses, globalWorkID);
                    this.Hide();
                    flashcardTemplate.Show();
                    break;
                case 4:
                    //loads one word form
                    OW_TEA oneWordAnswerTemplate = new OW_TEA(globalTeacherID, globalClasses, globalWorkID);
                    this.Hide();
                    oneWordAnswerTemplate.Show();
                    break;

            }

        }

        private void RefreshQuestionsButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database
            DataSet ds = new DataSet(); //where data returned is stored
            DataTable dt = new DataTable(); //where we will store data so it can be accessed by the program

            //query to select all the Question Types that are linked to the WorkID
            string questionTypeCmd = ("Select [Question Type] From Questions Where [WorkID] ='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(questionTypeCmd, con); //data adapater executes query
                                                                              //and puts data into a format we can use
            da.Fill(ds, "QuestionTypes"); //fills datatable with data returned                                    
            dt = ds.Tables["QuestionTypes"];
            int rowCount = (dt.Rows.Count - 1); //variable stores number of rows in the datatable
            int questionCount = 1; //questionCount is set to 1 by defauly

            for (int i = 0; i <= rowCount; i++) //for loop iterates through datatable
            {
                int j = 0; 
                //places data at each index of the datatable and question number into richtextbox
                QuestionsRichTextBox.Text += Environment.NewLine + questionCount + ". " + dt.Rows[i][j].ToString();
                questionCount++; //increments questionCount by 1
            }

            ds.Dispose(); //disposes dataset
            dt.Dispose(); //disposes datatable
            da.Dispose(); //diposes data adpater
            con.Close(); //closes connection

        }

        private void SetWorkButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=E:/Iteration 4 db.accdb"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database

            int classNumber = Convert.ToInt32(globalClasses); //stores ClassID 
            //Query to check if a Class already has work set
            OleDbCommand checkWorkCmd = new OleDbCommand("Select * from Classwork Where ClassID=" + classNumber, con);
            OleDbDataReader classCodeChecker = checkWorkCmd.ExecuteReader(); //executes command
            if (classCodeChecker.HasRows) //if reader has returned data
            {
                MessageBox.Show("This class already has work set", "Work already set"); //output error message
                classCodeChecker.Close(); //close reader
                checkWorkCmd.Dispose(); //dispose command

            }
            else
            {
                //query to insert 'Stop' Question Type into Questions table
                OleDbCommand addStopCheck = new OleDbCommand("Insert Into [Questions]([WorkID],[Question Type]) " +
                    "Values(@workID, 'Stop')", con);
                //query parameter
                addStopCheck.Parameters.Add("@workID", globalWorkID); //WorkID parameter
                OleDbDataReader stopReader = addStopCheck.ExecuteReader(); //execute query
                stopReader.Close(); //close reader
                addStopCheck.Dispose(); //dispose command

                //query to insert ClassID, WorkID and TeacherID into Classwors table
                OleDbCommand addWorkToClass = new OleDbCommand("Insert Into [Classwork]([ClassID], [WorkID],[TeacherID]) Values(@classID, @workID, @teacherId)", con);
                //query parameters
                addWorkToClass.Parameters.AddRange(new OleDbParameter[]
                {
                    new OleDbParameter("@classID", classNumber), //ClassID parameter
                    new OleDbParameter("@workID", globalWorkID), //WorkID parameter
                    new OleDbParameter("@teacherId", globalTeacherID), //TeacherID parameter



                });
                OleDbDataReader reader = addWorkToClass.ExecuteReader(); //executes command
                addWorkToClass.Dispose(); //disposes command
                con.Close(); //closes connection
                
                MessageBox.Show("The work has been set", "Work set"); //confirmation message
                //loads teacher homepage form
                Teacher_Homepage mainScreen = new Teacher_Homepage(globalTeacherID);
                this.Hide();
                mainScreen.Show();

            }

        }
    }
}
