﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class TF_STU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.TrueFalseLabel = new System.Windows.Forms.Label();
            this.PressInfoLabel = new System.Windows.Forms.Label();
            this.QuestionTextBox = new System.Windows.Forms.TextBox();
            this.TrueButton = new System.Windows.Forms.Button();
            this.FalseButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.ContinueButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 3;
            this.NameLogo.Text = "Swift";
            // 
            // TrueFalseLabel
            // 
            this.TrueFalseLabel.AutoSize = true;
            this.TrueFalseLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TrueFalseLabel.Location = new System.Drawing.Point(327, 46);
            this.TrueFalseLabel.Name = "TrueFalseLabel";
            this.TrueFalseLabel.Size = new System.Drawing.Size(143, 30);
            this.TrueFalseLabel.TabIndex = 5;
            this.TrueFalseLabel.Text = "True or False...";
            // 
            // PressInfoLabel
            // 
            this.PressInfoLabel.AutoSize = true;
            this.PressInfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PressInfoLabel.Location = new System.Drawing.Point(298, 76);
            this.PressInfoLabel.Name = "PressInfoLabel";
            this.PressInfoLabel.Size = new System.Drawing.Size(197, 30);
            this.PressInfoLabel.TabIndex = 6;
            this.PressInfoLabel.Text = "Press True or False...";
            // 
            // QuestionTextBox
            // 
            this.QuestionTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextBox.Location = new System.Drawing.Point(131, 128);
            this.QuestionTextBox.Name = "QuestionTextBox";
            this.QuestionTextBox.ReadOnly = true;
            this.QuestionTextBox.Size = new System.Drawing.Size(569, 35);
            this.QuestionTextBox.TabIndex = 7;
            this.QuestionTextBox.Text = "Question Will Be Here...";
            // 
            // TrueButton
            // 
            this.TrueButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TrueButton.Location = new System.Drawing.Point(230, 203);
            this.TrueButton.Name = "TrueButton";
            this.TrueButton.Size = new System.Drawing.Size(161, 75);
            this.TrueButton.TabIndex = 8;
            this.TrueButton.Text = "True";
            this.TrueButton.UseVisualStyleBackColor = true;
            this.TrueButton.Click += new System.EventHandler(this.TrueButton_Click);
            // 
            // FalseButton
            // 
            this.FalseButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FalseButton.Location = new System.Drawing.Point(441, 203);
            this.FalseButton.Name = "FalseButton";
            this.FalseButton.Size = new System.Drawing.Size(161, 75);
            this.FalseButton.TabIndex = 9;
            this.FalseButton.Text = "False";
            this.FalseButton.UseVisualStyleBackColor = true;
            this.FalseButton.Click += new System.EventHandler(this.FalseButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(131, 302);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorLabel.TabIndex = 13;
            this.ErrorLabel.Text = "Filler Text";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 398);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(160, 40);
            this.BackButton.TabIndex = 14;
            this.BackButton.Text = "<- Stop Assignment";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ContinueButton
            // 
            this.ContinueButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButton.Location = new System.Drawing.Point(628, 398);
            this.ContinueButton.Name = "ContinueButton";
            this.ContinueButton.Size = new System.Drawing.Size(160, 40);
            this.ContinueButton.TabIndex = 15;
            this.ContinueButton.Text = "Continue ->";
            this.ContinueButton.UseVisualStyleBackColor = true;
            this.ContinueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // TF_STU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ContinueButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.FalseButton);
            this.Controls.Add(this.TrueButton);
            this.Controls.Add(this.QuestionTextBox);
            this.Controls.Add(this.PressInfoLabel);
            this.Controls.Add(this.TrueFalseLabel);
            this.Controls.Add(this.NameLogo);
            this.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "TF_STU";
            this.Text = "True or False";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label TrueFalseLabel;
        private System.Windows.Forms.Label PressInfoLabel;
        private System.Windows.Forms.TextBox QuestionTextBox;
        private System.Windows.Forms.Button TrueButton;
        private System.Windows.Forms.Button FalseButton;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ContinueButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}