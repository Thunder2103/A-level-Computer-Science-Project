﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class FB_TEA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.FillBlankTemplate = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.QuestionLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.QuestionTextbox = new System.Windows.Forms.TextBox();
            this.AnswerTextBox = new System.Windows.Forms.TextBox();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.SetQuestionButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 6;
            this.NameLabel.Text = "Swift";
            // 
            // FillBlankTemplate
            // 
            this.FillBlankTemplate.AutoSize = true;
            this.FillBlankTemplate.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FillBlankTemplate.Location = new System.Drawing.Point(269, 47);
            this.FillBlankTemplate.Name = "FillBlankTemplate";
            this.FillBlankTemplate.Size = new System.Drawing.Size(241, 30);
            this.FillBlankTemplate.TabIndex = 8;
            this.FillBlankTemplate.Text = "Fill in the blank template";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(307, 77);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(157, 30);
            this.InfoLabel.TabIndex = 9;
            this.InfoLabel.Text = "Fill in the boxes";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(218, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 60);
            this.label1.TabIndex = 10;
            this.label1.Text = "Type out the question, replace each \r\nletter of the answer word with \"_\"";
            // 
            // QuestionLabel
            // 
            this.QuestionLabel.AutoSize = true;
            this.QuestionLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionLabel.Location = new System.Drawing.Point(40, 208);
            this.QuestionLabel.Name = "QuestionLabel";
            this.QuestionLabel.Size = new System.Drawing.Size(102, 30);
            this.QuestionLabel.TabIndex = 11;
            this.QuestionLabel.Text = "Question:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(0, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 30);
            this.label2.TabIndex = 12;
            this.label2.Text = "Answer Word:";
            // 
            // QuestionTextbox
            // 
            this.QuestionTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextbox.Location = new System.Drawing.Point(137, 208);
            this.QuestionTextbox.Name = "QuestionTextbox";
            this.QuestionTextbox.Size = new System.Drawing.Size(661, 35);
            this.QuestionTextbox.TabIndex = 13;
            // 
            // AnswerTextBox
            // 
            this.AnswerTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AnswerTextBox.Location = new System.Drawing.Point(136, 249);
            this.AnswerTextBox.Name = "AnswerTextBox";
            this.AnswerTextBox.Size = new System.Drawing.Size(662, 35);
            this.AnswerTextBox.TabIndex = 14;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(136, 287);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(101, 32);
            this.ErrorLabel.TabIndex = 16;
            this.ErrorLabel.Text = "Filler Text";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 394);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(233, 44);
            this.BackButton.TabIndex = 17;
            this.BackButton.Text = "<- Choose a different template";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SetQuestionButton
            // 
            this.SetQuestionButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetQuestionButton.Location = new System.Drawing.Point(657, 394);
            this.SetQuestionButton.Name = "SetQuestionButton";
            this.SetQuestionButton.Size = new System.Drawing.Size(131, 44);
            this.SetQuestionButton.TabIndex = 18;
            this.SetQuestionButton.Text = "Set Question ->\r\n";
            this.SetQuestionButton.UseVisualStyleBackColor = true;
            this.SetQuestionButton.Click += new System.EventHandler(this.SetQuestionButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 44;
            this.LogoPictureBox.TabStop = false;
            // 
            // FB_TEA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.SetQuestionButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.AnswerTextBox);
            this.Controls.Add(this.QuestionTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.QuestionLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.FillBlankTemplate);
            this.Controls.Add(this.NameLabel);
            this.Name = "FB_TEA";
            this.Text = "Fill in the blank";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label FillBlankTemplate;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label QuestionLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox QuestionTextbox;
        private System.Windows.Forms.TextBox AnswerTextBox;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button SetQuestionButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}