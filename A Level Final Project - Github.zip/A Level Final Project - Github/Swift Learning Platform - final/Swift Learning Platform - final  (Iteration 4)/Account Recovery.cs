﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net.Mail;
using System.Net;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Account_Recovery : Form
    {
        //global variables
        string globalStuTeaIndicator; 
        public Account_Recovery(string stuTeaIndicator)
        {
            InitializeComponent(); 
            //values passed from previous form is stored in global variable
            globalStuTeaIndicator = stuTeaIndicator;


            //email and password buttons and textboxes are
            //hidden until user indicated of they want to recover their username or password
            Email.Visible = false;
            Username.Visible = false;
            EmailTextbox.Visible = false;
            UsernameTextbox.Visible = false;
            UserRecoverButton.Enabled = false;
            UserRecoverButton.Visible = false;
            PassRecoverButton.Enabled = false;
            PassRecoverButton.Visible = false;
        }

        private void UserRevoverButton_Click(object sender, EventArgs e)
        {
            //We disable and hide all the buttons and textboxes for recovering the users password
            Username.Visible = false;
            UsernameTextbox.Visible = false;
            PassRecoverButton.Enabled = false;
            PassRecoverButton.Visible = false;

            //we enable and show all the buttons for recovering the users username
            Email.Visible = true;
            EmailTextbox.Visible = true;
            UserRecoverButton.Enabled = true;
            UserRecoverButton.Visible = true;
        }

        private void PassRecover_Click(object sender, EventArgs e)
        {
            //We disable and hide all the buttons and textboxes for recovering the users username
            UserRecoverButton.Enabled = false;
            UserRecoverButton.Visible = false;
            
            //we enable and show all the buttons for recovering the users password 
            Email.Visible = true;
            Username.Visible = true;
            EmailTextbox.Visible = true;
            UsernameTextbox.Visible = true;
            PassRecoverButton.Enabled = true;
            PassRecoverButton.Visible = true;
        }

        private void UserRecoverButton_Click(object sender, EventArgs e)
        {
            //if the user hasn't typed anything, an error message is displayed
            if (EmailTextbox.Text == String.Empty)
            {
                ErrorLabel.Text = "Please enter an email";


            }
            else
            {
                if (globalStuTeaIndicator == "STU") //if the user recovering the account is a student
                {
                    OleDbConnection con = new OleDbConnection();
                    string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                    string dbSource = "[Database path]"; //this is where the database is stored. 

                    con.ConnectionString = dbProvider + dbSource;
                    con.Open();  //connects to the database

                    //query to select user name matching the inputted email address
                    OleDbCommand cmd = new OleDbCommand("Select StudentID from Students where Email = '" + EmailTextbox.Text + "'", con);
                    OleDbDataReader reader = cmd.ExecuteReader();


                    if (reader.HasRows) //if there is username connected with the inputted email 
                    {
                        reader.Close();
                        string username = cmd.ExecuteScalar().ToString(); //username is stored in variable called username. 
                       
                        string email = EmailTextbox.Text; //store email user has entered as variable 
                        UsernameEmail(email, username, ErrorLabel); //call UsernameEmail function. The users username,
                                                                    //email and the ErrorLabel are passed as values


                    }
                    else
                    {
                        //if there is no username matching the inputted email we return an error message
                        ErrorLabel.Text = "No Email found matching a student";
                        EmailTextbox.Text = String.Empty; //clears textbox


                    }
                    con.Close();
                    reader.Close();
                    cmd.Dispose();
                }
                else //if the user recovering the account is teacher
                {
                    OleDbConnection con = new OleDbConnection();
                    string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                    string dbSource = "[Database path]"; //this is where the database is stored. 
                    con.ConnectionString = dbProvider + dbSource;
                    con.Open();  //connects to the database

                    //query to select user name matching the inputted email address
                    OleDbCommand cmd = new OleDbCommand("Select TeacherID from Teachers where Email = '" + EmailTextbox.Text + "'", con);
                    OleDbDataReader reader = cmd.ExecuteReader();


                    if (reader.HasRows) //if there is username connected with the inputted email 
                    {
                        reader.Close();
                        string username = cmd.ExecuteScalar().ToString(); //username is stored in variable called username. 
                        string email = EmailTextbox.Text;
                        //string email = EmailTextbox.Text; //store email user has entered as variable 
                        UsernameEmail(email, username, ErrorLabel); //call UsernameEmail function. The users username,
                                                                    //email and the ErrorLabel are passed as values


                    }
                    else
                    {
                        //if there is no username matching the inputted email we return an error message
                        ErrorLabel.Text = "No Email found matching a teacher";
                        EmailTextbox.Text = String.Empty; //clears textbox


                    }
                    con.Close(); //close connection
                    reader.Close(); //diposes reader
                    cmd.Dispose(); //diposes command

                }
                




            }
        }

        private void AccountCreateButton_Click(object sender, EventArgs e)
        {
            AccountCreate accountCreate = new AccountCreate();
            this.Hide();
            accountCreate.Show();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void HomePageButton_Click(object sender, EventArgs e)
        {
            //loads welcome screen form 
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            this.Hide();
            welcomeScreen.Show(); 
        }


        //function that sends email with recovered username. 
        static void UsernameEmail(string email, string username, Label ErrorLabel) //parameters. 
        {

            SmtpClient client = new SmtpClient()
            {
                Host = "smtp.gmail.com", //provider we are using to send the email
                Port = 587,  //port the email is sent from 
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network, //how we are going to deliver the email
                UseDefaultCredentials = false, //credentials is the email and it's password 
                Credentials = new NetworkCredential()
                {
                    UserName = "SwiftLearningPlatform@gmail.com", //email of the senders account
                    Password = "SyntaxOptimisation06!" //password of the senders account
                }
            };
            MailAddress sender = new MailAddress("SwiftLearningPlatform@gmail.com"); //senders email address
            MailAddress recipient = new MailAddress(email); //recipients email address
            MailMessage message = new MailMessage() //email contents
            {
                From = sender, //from is who is sending the email 
                Subject = "Recovering your username", //subject of the email 
                Body = "Hello " + username + "," + Environment.NewLine + //body of the email is what text the email contains
                "You have requested to recover your username" + Environment.NewLine +
                "Here is your username: " + username   //the users username is placed in the email text. 

            };
            message.To.Add(recipient); //adds who the email is being sent to 
            try
            {
                client.Send(message); //trys to send the message 
            }
            catch (Exception ex) //catched error of one occurs
            {
                MessageBox.Show("The email could not be sent. Please try again"); //outputs error message. 
                ErrorLabel.Text = "The email could not be sent. Please try again later";

            }


        }

        //function to send email with instructions to recover email
        static void PasswordEmail(string username, string email, Label ErrorLabel,Form accountRecovery) //parameters 
        {
            Random rnd = new Random();
            //generates six figure reset code - D6 just fills the string with 0's until it is 6 figures long
            String resetCode = rnd.Next(0, 999999).ToString("D6"); 
      
            SmtpClient client = new SmtpClient()
            {
                Host = "smtp.gmail.com", //provider we are using to send email
                Port = 587, //port email is begin sent ferom
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network, //how we are going to deliver the email
                UseDefaultCredentials = false, //credentials is the email and it's password 
                Credentials = new NetworkCredential()
                {
                    UserName = "SwiftLearningPlatform@gmail.com", //email of the senders account
                    Password = "SyntaxOptimisation06!"  //password of the senders account
                
                }



            };
            MailAddress sender = new MailAddress("SwiftLearningPlatform@gmail.com"); //who is sending email
            MailAddress recipient = new MailAddress(email); //who is getting email 
            MailMessage message = new MailMessage() //the emails contents
            {
                From = sender, //who's sending the email 
                Subject = "Recovering your password", //subject of the email
                Body = "Hello " + username + "," + Environment.NewLine +   //actual text of the email
                "You have requested to recover your password and change it" + Environment.NewLine +
                "Here is your reset code: " + resetCode //reset code is placed in the email 

            };
            message.To.Add(recipient); //adds who is getting thr email
            try
            {
                //trys to send email
                client.Send(message);
            }
            catch (Exception ex) //catches error 
            { 
                //displays error message if email isn't sent. 
                MessageBox.Show("The email could not be sent. Please try again");
                ErrorLabel.Text = "The email could not be sent. Please try again later";

            } 
            
            PasswordRecovery passRecover = new PasswordRecovery(resetCode, username); //reset code and username passed as variables. 
            accountRecovery.Hide(); //hides this form.
            passRecover.Show(); //loads Password recovery form


        }

        private void PassRecoverButton_Click(object sender, EventArgs e)
        {
            if (EmailTextbox.Text == String.Empty && UsernameTextbox.Text == String.Empty) //if one of the textboxes is empty...
            {
                ErrorLabel.Text = "Please enter your username and email address"; //error message is displayed

            }
            else
            {
                if (globalStuTeaIndicator == "STU") //if user is a student
                {
                    OleDbConnection con = new OleDbConnection();
                    string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                    string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                    con.ConnectionString = dbProvider + dbSource;
                    con.Open(); //connects to the database

                    //query to select records matching the inputted username and email 
                    OleDbCommand cmd = new OleDbCommand("Select * from Students where Email = '" + EmailTextbox.Text + "'and StudentID = '" + UsernameTextbox.Text + "'", con);
                    OleDbDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows) //if a record contains both the username and password
                    {
                        string username = UsernameTextbox.Text; //the inputted username is stored in the username variable 
                        string email = EmailTextbox.Text; //the inputted email is stored in the email variable. 
                        PasswordEmail(username, email, ErrorLabel, this); //PasswordEmail() is called, the varaibles username and password are passed as variables. So is the ErrorLabel
                       
                    }
                    else //if no reocrds match the username and email
                    {
                        //error message displayed
                        ErrorLabel.Text = "No Student Email or Username found";
                        EmailTextbox.Text = String.Empty;
                        UsernameTextbox.Text = String.Empty;

                    }

                }
                else //if user is a teacher
                {
                    OleDbConnection con = new OleDbConnection();
                    string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                    string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                    con.ConnectionString = dbProvider + dbSource;
                    con.Open(); //connects to the database

                    //query to select records matching the inputted username and email 
                    OleDbCommand cmd = new OleDbCommand("Select * from Teachers where Email = '" + EmailTextbox.Text + "'and TeacherID = '" + UsernameTextbox.Text + "'", con);
                    OleDbDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows) //if a record contains both the username and password
                    {
                        string username = UsernameTextbox.Text; //the inputted username is stored in the username variable 
                        string email = EmailTextbox.Text; //the inputted email is stored in the email variable. 
                        PasswordEmail(username, email, ErrorLabel, this); //PasswordEmail() is called, the varaibles username and password are passed as variables. So is the ErrorLabel
                        this.Hide(); //hides this form. 

                    }
                    else //if no reocrds match the username and email
                    {
                        //error message displayed
                        ErrorLabel.Text = "No Teacher Email or Username found";
                        EmailTextbox.Text = String.Empty;
                        UsernameTextbox.Text = String.Empty;

                    }

                }
               



            }
        }
    }
}
