﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Choose_Result : Form
    {
        //global variables
        string globalTeacherID;
        string globalWorkID;
        public Choose_Result(string teacherID)
        {
            InitializeComponent();
            //value passed from previous form stored in global variable
            globalTeacherID = teacherID;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database


            DataSet ds = new DataSet(); //actual data returned
            DataTable dt = new DataTable(); //where data will be stored

            //query to Select WorkID's connected to users TeacherID and return them in ascending order
            string getClassescmd = ("Select * from [Work] where TeacherID='" + globalTeacherID + "' Order by WorkID ASC");

            //data adapater puts data in format we can use
            OleDbDataAdapter da = new OleDbDataAdapter(getClassescmd, con);


            da.Fill(ds, "Assignments");
            dt = ds.Tables["Assignments"]; //fills data table with data
            int rowCount = (dt.Rows.Count) - 1; //counts number of rows in the datatable
            //for loop iterates through datatable
            for (int i = 0; i <= rowCount; i++)
            {
                //Places data in each index from datatable into combo box
                AssigmentsComboBox.Items.Add("Assignments: " + dt.Rows[i][0].ToString());
            }
            da.Dispose(); //disposes data adapter
            ds.Dispose(); //disposes data set
            dt.Dispose(); //disposes data table
            con.Close(); //closes connection 
        }

        private void ResultsButton_Click(object sender, EventArgs e)
        {
            //stores value selected from combo box in globalWorkID variable
            globalWorkID = AssigmentsComboBox.Text;
            //slices globalWorkID string to remove excess text
            globalWorkID = globalWorkID.Remove(0, 13);
            
            //loads View Assignment Results form
            View_Results assigmentScores = new View_Results(globalTeacherID, globalWorkID);
            this.Hide();
            assigmentScores.Show();

        }

        private void MainPageButton_Click(object sender, EventArgs e)
        {
            //loads Teachers homepage form
            Teacher_Homepage homepage = new Teacher_Homepage(globalTeacherID);
            this.Hide(); 
            homepage.Show();
        }
    }
}
