﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Teacher_Homepage : Form
    { 
        //global variables
        string globalTeacherID = ""; 
        public Teacher_Homepage(string teacherID)
        {
            InitializeComponent();
    
            //stores teacherID passed from login screen in global variable. 
            globalTeacherID = teacherID; 
        
        }

        private void SignOutBUtton_Click(object sender, EventArgs e)
        { 
            //loads welcome screen form
            WelcomeScreen welcomeScreen = new WelcomeScreen(); 
            this.Hide();
            welcomeScreen.Show(); 
        }

        private void ExitButton_Click(object sender, EventArgs e)
        { 
            //exits program
            this.Hide(); 
        }

        private void ViewClassesButton_Click(object sender, EventArgs e)
        { 
            //loads ViewingClasses form
            ViewingClasses viewClasses = new ViewingClasses(globalTeacherID);
            this.Hide();
            viewClasses.Show(); 
        }

        private void CreateClassButton_Click(object sender, EventArgs e)
        {
            // loads Create a class form  
            Create_a_Class createClass = new Create_a_Class(globalTeacherID);
            this.Hide();
            createClass.Show(); 
        }

        private void SetAssignButton_Click(object sender, EventArgs e)
        {
            //loads create Assignment form 
            string workID = "";
            CreateAssignment createAssignment = new CreateAssignment(globalTeacherID, workID); 
            this.Hide();    
            createAssignment.Show();    
        }

        private void ResultsButton_Click(object sender, EventArgs e)
        {
            //Load choose assignment result form
            Choose_Result workResults = new Choose_Result(globalTeacherID);
            this.Hide();
            workResults.Show();

        }
    }
}
