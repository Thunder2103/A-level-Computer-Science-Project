﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Create_a_Class
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.CreateClassButton = new System.Windows.Forms.Button();
            this.ClassCreatedLabel = new System.Windows.Forms.Label();
            this.ClassCodeLabel = new System.Windows.Forms.Label();
            this.MainPageButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ViewClassesButton = new System.Windows.Forms.Button();
            this.CreateAssignmentButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(285, 67);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(217, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Creating a new class...";
            // 
            // CreateClassButton
            // 
            this.CreateClassButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateClassButton.Location = new System.Drawing.Point(285, 100);
            this.CreateClassButton.Name = "CreateClassButton";
            this.CreateClassButton.Size = new System.Drawing.Size(217, 51);
            this.CreateClassButton.TabIndex = 5;
            this.CreateClassButton.Text = "Click here to create a class";
            this.CreateClassButton.UseVisualStyleBackColor = true;
            this.CreateClassButton.Click += new System.EventHandler(this.CreateClassButton_Click);
            // 
            // ClassCreatedLabel
            // 
            this.ClassCreatedLabel.AutoSize = true;
            this.ClassCreatedLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClassCreatedLabel.Location = new System.Drawing.Point(285, 163);
            this.ClassCreatedLabel.Name = "ClassCreatedLabel";
            this.ClassCreatedLabel.Size = new System.Drawing.Size(56, 30);
            this.ClassCreatedLabel.TabIndex = 7;
            this.ClassCreatedLabel.Text = "Filler";
            // 
            // ClassCodeLabel
            // 
            this.ClassCodeLabel.AutoSize = true;
            this.ClassCodeLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClassCodeLabel.Location = new System.Drawing.Point(285, 202);
            this.ClassCodeLabel.Name = "ClassCodeLabel";
            this.ClassCodeLabel.Size = new System.Drawing.Size(56, 30);
            this.ClassCodeLabel.TabIndex = 8;
            this.ClassCodeLabel.Text = "Filler";
            // 
            // MainPageButton
            // 
            this.MainPageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainPageButton.Location = new System.Drawing.Point(12, 403);
            this.MainPageButton.Name = "MainPageButton";
            this.MainPageButton.Size = new System.Drawing.Size(129, 35);
            this.MainPageButton.TabIndex = 9;
            this.MainPageButton.Text = "<- Main Page";
            this.MainPageButton.UseVisualStyleBackColor = true;
            this.MainPageButton.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(659, 403);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(129, 35);
            this.ExitButton.TabIndex = 10;
            this.ExitButton.Text = "Exit ->";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ViewClassesButton
            // 
            this.ViewClassesButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ViewClassesButton.Location = new System.Drawing.Point(167, 271);
            this.ViewClassesButton.Name = "ViewClassesButton";
            this.ViewClassesButton.Size = new System.Drawing.Size(193, 46);
            this.ViewClassesButton.TabIndex = 11;
            this.ViewClassesButton.Text = "View Classes";
            this.ViewClassesButton.UseVisualStyleBackColor = true;
            this.ViewClassesButton.Click += new System.EventHandler(this.ViewClassesButton_Click);
            // 
            // CreateAssignmentButton
            // 
            this.CreateAssignmentButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateAssignmentButton.Location = new System.Drawing.Point(440, 271);
            this.CreateAssignmentButton.Name = "CreateAssignmentButton";
            this.CreateAssignmentButton.Size = new System.Drawing.Size(193, 46);
            this.CreateAssignmentButton.TabIndex = 12;
            this.CreateAssignmentButton.Text = "Create An Assignment";
            this.CreateAssignmentButton.UseVisualStyleBackColor = true;
            this.CreateAssignmentButton.Click += new System.EventHandler(this.CreateAssignmentButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 44;
            this.LogoPictureBox.TabStop = false;
            // 
            // Create_a_Class
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.CreateAssignmentButton);
            this.Controls.Add(this.ViewClassesButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.MainPageButton);
            this.Controls.Add(this.ClassCodeLabel);
            this.Controls.Add(this.ClassCreatedLabel);
            this.Controls.Add(this.CreateClassButton);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "Create_a_Class";
            this.Text = "Create_a_Class";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Button CreateClassButton;
        private System.Windows.Forms.Label ClassCreatedLabel;
        private System.Windows.Forms.Label ClassCodeLabel;
        private System.Windows.Forms.Button MainPageButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ViewClassesButton;
        private System.Windows.Forms.Button CreateAssignmentButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}