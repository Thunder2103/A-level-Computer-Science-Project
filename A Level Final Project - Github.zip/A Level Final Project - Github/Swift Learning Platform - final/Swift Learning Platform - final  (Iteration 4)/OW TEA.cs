﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class OW_TEA : Form
    {
        //global variables
        string globalTeacherId;
        string globalClasses;
        string globalWorkID;
        public OW_TEA(string teacherId, string classes, string workId)
        {
            InitializeComponent(); 
            //values passed from previous formed stored in global variables
            globalTeacherId = teacherId;
            globalClasses = classes;
            globalWorkID = workId;
        }

        private void BackButton_Click(object sender, EventArgs e)
        { 
            //Loads Setting Assignment forms
            OW_TEA setAssignemnts = new OW_TEA(globalTeacherId, globalClasses, globalWorkID);
            this.Hide();
            setAssignemnts.Show();
        }

        private void SetQuestionButton_Click(object sender, EventArgs e)
        {
            //boolean variable to check for whote spaces in the answer
            bool isWhiteSpace = AnswerTextBox.Text.Any(x => Char.IsWhiteSpace(x)); 
            //if either textbox is empty
            if (QuestionTextBox.Text == string.Empty || AnswerTextBox.Text == string.Empty)
            {
                ErrorLabel.Text = "Please fill in all the boxes"; //output error message
            }
            else if (isWhiteSpace == true) //if there are whitespaces in the answer
            {
                ErrorLabel.Text = "Please remove the spaces or extra words"; //output error message
            }
            else
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to the database 
                //query to insert question and answer into the database's question table
                OleDbCommand insertQuestionOneWord = new OleDbCommand("Insert Into Questions([WorkID],[Question Type]," +
                    "[Question],[Correct Answer]) Values(@workID, 'OW',@question, @correctAns)", con);
                //query parameters
                insertQuestionOneWord.Parameters.AddRange(new OleDbParameter[]
                {
                        new OleDbParameter("@workID", globalWorkID), //WorkID parameter
                        new OleDbParameter("@question", QuestionTextBox.Text), //Question Parameter
                        new OleDbParameter("@correctAns", AnswerTextBox.Text.ToLower()), //Correct answer parameter

                });
                insertQuestionOneWord.ExecuteNonQuery(); //execute query
                insertQuestionOneWord.Dispose(); //dispose query
                con.Close(); //close connection 

                //loads Setting Assignment form
                Setting_Assignments chooseAssignement = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
                this.Hide();
                chooseAssignement.Show();
            }
        }
    }
}
