﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class TF_TEA : Form
    {
        //global varaibles
        string globalTeacherId;
        string globalClasses;
        string globalWorkID;
        int correctanswerIndicator = 0;
        public TF_TEA(string teacherId, string classes, string workID)
        {
            InitializeComponent(); 
            //values passed from previous forms stored in global varaibles
            globalTeacherId = teacherId;
            globalClasses = classes;
            globalWorkID = workID;
        }

        private void TruthCorrectButton_Click(object sender, EventArgs e)
        { 
            //the value of correctanserIndicator is set to one, marking it as true
            correctanswerIndicator = 1;
            //disables the true button and enables the false button
            TruthCorrectButton.Enabled = false;
            FalseCorrectButton.Enabled = true;

        }

        private void FalseCorrectButton_Click(object sender, EventArgs e)
        {
            //the value of correctanserIndicator is set to two, marking it as false
            correctanswerIndicator = 2;
            //disables false button and enables true button
            TruthCorrectButton.Enabled = true;
            FalseCorrectButton.Enabled = false;
        }

        private void SetQuestionButton_Click(object sender, EventArgs e)
        {
            if (QuestionTextbox.Text == string.Empty) //check to make sure user has inputted a question
            { 
                //if no question has been made, error message is outputted
                ErrorMessageLabel.Text = "Please fill in all the boxes";
            }
            else if (correctanswerIndicator == 0) //if the user has not selected a correct answer
            {
                CorrectAnsErrorLabel.Text = "Correct answer not selected"; //error message outputted
            }
            else
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to the database

                if (correctanswerIndicator == 1) //if true is the correct answer
                { 
                    //query to insert the quesiton and true as the correct answer into the database's question table 
                    OleDbCommand insertQuestion = new OleDbCommand("Insert Into Questions([WorkID],[Question Type],[Question],[Correct Answer]) Values(@workID, 'TF',@question, @correctAns)", con);
                    //parameters needed for query to run
                    insertQuestion.Parameters.AddRange(new OleDbParameter[]
                    {
                        new OleDbParameter("@workID", globalWorkID), //parameter for WorkID
                        new OleDbParameter("@question", QuestionTextbox.Text), //parameter for questions
                        new OleDbParameter("@correctAns", "True"), //paramteter for the correct answer

                    });

                    insertQuestion.ExecuteNonQuery(); //executes query
                    insertQuestion.Dispose(); //disposes query

                }
                else //if the correct answer is false
                {
                    //query to insert question and false as the correct answer into the database's question table 
                    OleDbCommand insertQuestion = new OleDbCommand("Insert Into Questions([WorkID],[Question Type],[Question],[Correct Answer]) Values(@workID, 'TF',@question, @correctAns)", con);
                    //parameters for query
                    insertQuestion.Parameters.AddRange(new OleDbParameter[]
                    {
                        new OleDbParameter("@workID", globalWorkID), //WorkID parameter
                        new OleDbParameter("@question", QuestionTextbox.Text), //Question parameter
                        new OleDbParameter("@correctAns", "False"), //correct answer parameter

                    });

                    insertQuestion.ExecuteNonQuery(); //executes query
                    insertQuestion.Dispose(); //disposes query


                }
                con.Close(); //closes connection
                //loads the Setting Assignments form
                Setting_Assignments setAssignements = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
                this.Hide();
                setAssignements.Show();
            }
        }

        private void DifferentTemplateButton_Click(object sender, EventArgs e)
        {
            //loads the Setting Assignments form
            Setting_Assignments setAssignements = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
            this.Hide();
            setAssignements.Show();

        }
    }
}
