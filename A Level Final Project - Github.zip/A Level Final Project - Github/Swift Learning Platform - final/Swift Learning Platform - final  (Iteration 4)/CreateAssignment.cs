﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class CreateAssignment : Form
    {
        //global variables
        string globalTeacherid;
        string globalWorkID; 
        public CreateAssignment(string teacherID, string workID)
        {
            InitializeComponent(); 
            //values of passed variables from previous forms stored as global variables
            globalTeacherid = teacherID;
            globalWorkID = workID;

            OleDbConnection con = new OleDbConnection();
            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //established connection to the database


            DataSet ds = new DataSet(); //data to be returned
            DataTable dt = new DataTable(); //where data returned will be stored 

            //query to select all ClassID, number of students records that have the users TeacherID
            string getClassescmd = ("Select ClassID, NumStudents from Classes where TeacherID =  '" + teacherID + "'");


            OleDbDataAdapter da = new OleDbDataAdapter(getClassescmd, con); //return data in format we can use


            da.Fill(ds, "Classes"); //converts returned data in format we can use
            dt = ds.Tables["Classes"]; //fills datatable with data
            int rowCount = (dt.Rows.Count) - 1; //varaible that stores number of rows in datatable
            for (int i = 0; i <= rowCount; i++) //for loop iterates through datatable
            {
                //places value at each index into the combo box. 
                SelectClassComboBox.Items.Add("Class: " + dt.Rows[i][0].ToString());
            }
            da.Dispose(); //disposes data adapter
            ds.Dispose(); //disposes data set
            dt.Dispose(); //disposes data table
            con.Close(); //closes connection 


        }

        private void CreateWorkButton_Click(object sender, EventArgs e)
        {

            string classes = SelectClassComboBox.Text; //alaue of classes is equal to the text selected from the combo box

            if (classes == "") //if the classes variable contains nothing
            {
                ErrorLabel.Text = "Please select a class..."; //outputs error message
            }
            else //if the text has been selected from the combo box
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine to query database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //established connection to database
                
                string workID; //declares local workID variable
                workID = GenerateWorkCode(); //calls function to generate the workID
                MessageBox.Show(workID); //outputs generated workID
                CheckWorkCodes(con, workID); //calls function to check if generated workID exists

                //code to WorkID and TeacherID into Work table
                OleDbCommand insertCodeCmd = new OleDbCommand("Insert Into [Work]([WorkID],[TeacherID]) Values(@code, @teacherID)", con);
                //parameters needes to execute query
                insertCodeCmd.Parameters.AddRange(new OleDbParameter[]
                {
                    new OleDbParameter("@code", workID), //parameter to store workID
                    new OleDbParameter("@teacherID", globalTeacherid), //paramters to store teacherID
                });

                insertCodeCmd.ExecuteNonQuery(); //executes query 
                insertCodeCmd.Dispose(); //Diposes command

                //removes excess text from combo box to get only the ClassID
                classes = classes.Remove(0, 7); 

                //loads Creating Questions form. 
                Setting_Assignments creatingQuestions = new Setting_Assignments(globalTeacherid, classes, workID);
                this.Hide();
                creatingQuestions.Show();
            }


        }

        private void MainPageButton_Click(object sender, EventArgs e)
        {
            //loads teachers homepage 
            Teacher_Homepage homepage = new Teacher_Homepage(globalTeacherid);
            this.Hide(); 
            homepage.Show();
        }

        //GenerateWorkCode() function, returns a string
        private String GenerateWorkCode() 
        {
            Random rnd = new Random(); //generates 6 digit number
            String number = rnd.Next(1, 999999).ToString("D6"); //fills number with zeros until it's 6 digits long
            return number; //returns number generated as a string 
        }

        //CheckWorkCode() function, makes sure WorkID doesn't already exist
        private void CheckWorkCodes(OleDbConnection con, string workID) //parameters needed for function to run
        {
            //query to check if any WorkID's in Work table macth generated WorkID
            OleDbCommand checkCodesCmd = new OleDbCommand("Select * from [Work] where WorkID='" + workID + "'", con);
            OleDbDataReader reader = checkCodesCmd.ExecuteReader(); //declares reader and executes query
            if (reader.HasRows) //if reader has rows - WorkID already exists in table
            {
                reader.Close(); //closes reader
                checkCodesCmd.Dispose(); //disposes command 
                workID = GenerateWorkCode(); //reruns GenerateWorkCode() to make new WorkID
                CheckWorkCodes(con, workID); //reruns CheckWorkCode() function

            }
            else //if the WorkID is already not in the table. 
            {
                reader.Close(); //closes reader
                checkCodesCmd.Dispose(); //closes command
                return; //ends function
            }

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //exits program
            this.Hide();
        }
    }
}
