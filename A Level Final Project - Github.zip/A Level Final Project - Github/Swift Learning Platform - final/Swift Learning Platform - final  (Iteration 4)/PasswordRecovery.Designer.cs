﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class PasswordRecovery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NewPassLabel = new System.Windows.Forms.Label();
            this.PassConfirmLabel = new System.Windows.Forms.Label();
            this.ResetCodeTextbox = new System.Windows.Forms.TextBox();
            this.NewPassTextbox = new System.Windows.Forms.TextBox();
            this.ConfirmPassTextbox = new System.Windows.Forms.TextBox();
            this.ConditionsLabel = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SignInButton = new System.Windows.Forms.Button();
            this.NoEmailButton = new System.Windows.Forms.Button();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.ErrorMessageLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 4;
            this.NameLabel.Text = "Swift";
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TitleLabel.Location = new System.Drawing.Point(306, 28);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(198, 30);
            this.TitleLabel.TabIndex = 6;
            this.TitleLabel.Text = "Password recovery...";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(203, 58);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(419, 30);
            this.InfoLabel.TabIndex = 7;
            this.InfoLabel.Text = "Type the reset code and your new password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(65, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 30);
            this.label2.TabIndex = 8;
            this.label2.Text = "Reset Code:";
            // 
            // NewPassLabel
            // 
            this.NewPassLabel.AutoSize = true;
            this.NewPassLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NewPassLabel.Location = new System.Drawing.Point(35, 159);
            this.NewPassLabel.Name = "NewPassLabel";
            this.NewPassLabel.Size = new System.Drawing.Size(152, 30);
            this.NewPassLabel.TabIndex = 9;
            this.NewPassLabel.Text = "New Password:";
            // 
            // PassConfirmLabel
            // 
            this.PassConfirmLabel.AutoSize = true;
            this.PassConfirmLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PassConfirmLabel.Location = new System.Drawing.Point(3, 198);
            this.PassConfirmLabel.Name = "PassConfirmLabel";
            this.PassConfirmLabel.Size = new System.Drawing.Size(184, 30);
            this.PassConfirmLabel.TabIndex = 10;
            this.PassConfirmLabel.Text = "Confirm Password:";
            // 
            // ResetCodeTextbox
            // 
            this.ResetCodeTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ResetCodeTextbox.Location = new System.Drawing.Point(193, 111);
            this.ResetCodeTextbox.Name = "ResetCodeTextbox";
            this.ResetCodeTextbox.Size = new System.Drawing.Size(527, 35);
            this.ResetCodeTextbox.TabIndex = 11;
            // 
            // NewPassTextbox
            // 
            this.NewPassTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NewPassTextbox.Location = new System.Drawing.Point(193, 154);
            this.NewPassTextbox.Name = "NewPassTextbox";
            this.NewPassTextbox.Size = new System.Drawing.Size(527, 35);
            this.NewPassTextbox.TabIndex = 12;
            // 
            // ConfirmPassTextbox
            // 
            this.ConfirmPassTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConfirmPassTextbox.Location = new System.Drawing.Point(193, 198);
            this.ConfirmPassTextbox.Name = "ConfirmPassTextbox";
            this.ConfirmPassTextbox.Size = new System.Drawing.Size(527, 35);
            this.ConfirmPassTextbox.TabIndex = 13;
            // 
            // ConditionsLabel
            // 
            this.ConditionsLabel.AutoSize = true;
            this.ConditionsLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConditionsLabel.Location = new System.Drawing.Point(286, 275);
            this.ConditionsLabel.Name = "ConditionsLabel";
            this.ConditionsLabel.Size = new System.Drawing.Size(307, 126);
            this.ConditionsLabel.TabIndex = 14;
            this.ConditionsLabel.Text = "Passwords must contain:\r\n-at least one capital and lowercase letter\r\n-be more tha" +
    "n 10 characters\r\n-at least one number \r\n-at least one special character - !,@,*," +
    "£, ect. \r\n\r\n";
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(13, 404);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(74, 34);
            this.ExitButton.TabIndex = 16;
            this.ExitButton.Text = "<- Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            // 
            // SignInButton
            // 
            this.SignInButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SignInButton.Location = new System.Drawing.Point(636, 404);
            this.SignInButton.Name = "SignInButton";
            this.SignInButton.Size = new System.Drawing.Size(152, 35);
            this.SignInButton.TabIndex = 17;
            this.SignInButton.Text = "Back to sign in ->";
            this.SignInButton.UseVisualStyleBackColor = true;
            this.SignInButton.Click += new System.EventHandler(this.SignInButton_Click);
            // 
            // NoEmailButton
            // 
            this.NoEmailButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NoEmailButton.Location = new System.Drawing.Point(332, 404);
            this.NoEmailButton.Name = "NoEmailButton";
            this.NoEmailButton.Size = new System.Drawing.Size(172, 35);
            this.NoEmailButton.TabIndex = 18;
            this.NoEmailButton.Text = "Can\'t find the Email?";
            this.NoEmailButton.UseVisualStyleBackColor = true;
            this.NoEmailButton.Click += new System.EventHandler(this.NoEmailButton_Click);
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConfirmButton.Location = new System.Drawing.Point(629, 239);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(91, 37);
            this.ConfirmButton.TabIndex = 19;
            this.ConfirmButton.Text = "Let\'s go";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // ErrorMessageLabel
            // 
            this.ErrorMessageLabel.AutoSize = true;
            this.ErrorMessageLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorMessageLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorMessageLabel.Location = new System.Drawing.Point(193, 240);
            this.ErrorMessageLabel.Name = "ErrorMessageLabel";
            this.ErrorMessageLabel.Size = new System.Drawing.Size(68, 30);
            this.ErrorMessageLabel.TabIndex = 20;
            this.ErrorMessageLabel.Text = "label1";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // PasswordRecovery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ErrorMessageLabel);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.NoEmailButton);
            this.Controls.Add(this.SignInButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ConditionsLabel);
            this.Controls.Add(this.ConfirmPassTextbox);
            this.Controls.Add(this.NewPassTextbox);
            this.Controls.Add(this.ResetCodeTextbox);
            this.Controls.Add(this.PassConfirmLabel);
            this.Controls.Add(this.NewPassLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "PasswordRecovery";
            this.Text = "PasswordRecovery";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label NewPassLabel;
        private System.Windows.Forms.Label PassConfirmLabel;
        private System.Windows.Forms.TextBox ResetCodeTextbox;
        private System.Windows.Forms.TextBox NewPassTextbox;
        private System.Windows.Forms.TextBox ConfirmPassTextbox;
        private System.Windows.Forms.Label ConditionsLabel;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button SignInButton;
        private System.Windows.Forms.Button NoEmailButton;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Label ErrorMessageLabel;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}