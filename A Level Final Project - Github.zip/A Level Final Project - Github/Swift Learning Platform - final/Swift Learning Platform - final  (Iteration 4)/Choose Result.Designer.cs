﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Choose_Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwfitLabel = new System.Windows.Forms.Label();
            this.LogoLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.AssigmentsComboBox = new System.Windows.Forms.ComboBox();
            this.ResultsButton = new System.Windows.Forms.Button();
            this.MainPageButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwfitLabel
            // 
            this.SwfitLabel.AutoSize = true;
            this.SwfitLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwfitLabel.Location = new System.Drawing.Point(12, 9);
            this.SwfitLabel.Name = "SwfitLabel";
            this.SwfitLabel.Size = new System.Drawing.Size(58, 30);
            this.SwfitLabel.TabIndex = 3;
            this.SwfitLabel.Text = "Swift";
            // 
            // LogoLabel
            // 
            this.LogoLabel.AutoSize = true;
            this.LogoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LogoLabel.Location = new System.Drawing.Point(644, 9);
            this.LogoLabel.Name = "LogoLabel";
            this.LogoLabel.Size = new System.Drawing.Size(0, 30);
            this.LogoLabel.TabIndex = 4;
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(202, 65);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(397, 30);
            this.InfoLabel.TabIndex = 5;
            this.InfoLabel.Text = "Choose an assignment to view the results";
            // 
            // AssigmentsComboBox
            // 
            this.AssigmentsComboBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AssigmentsComboBox.FormattingEnabled = true;
            this.AssigmentsComboBox.Location = new System.Drawing.Point(202, 98);
            this.AssigmentsComboBox.Name = "AssigmentsComboBox";
            this.AssigmentsComboBox.Size = new System.Drawing.Size(403, 38);
            this.AssigmentsComboBox.TabIndex = 6;
            // 
            // ResultsButton
            // 
            this.ResultsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ResultsButton.Location = new System.Drawing.Point(611, 99);
            this.ResultsButton.Name = "ResultsButton";
            this.ResultsButton.Size = new System.Drawing.Size(93, 38);
            this.ResultsButton.TabIndex = 7;
            this.ResultsButton.Text = "Let\'s go";
            this.ResultsButton.UseVisualStyleBackColor = true;
            this.ResultsButton.Click += new System.EventHandler(this.ResultsButton_Click);
            // 
            // MainPageButton
            // 
            this.MainPageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainPageButton.Location = new System.Drawing.Point(12, 401);
            this.MainPageButton.Name = "MainPageButton";
            this.MainPageButton.Size = new System.Drawing.Size(136, 37);
            this.MainPageButton.TabIndex = 8;
            this.MainPageButton.Text = "<- Main Page";
            this.MainPageButton.UseVisualStyleBackColor = true;
            this.MainPageButton.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 44;
            this.LogoPictureBox.TabStop = false;
            // 
            // Choose_Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.MainPageButton);
            this.Controls.Add(this.ResultsButton);
            this.Controls.Add(this.AssigmentsComboBox);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.LogoLabel);
            this.Controls.Add(this.SwfitLabel);
            this.Name = "Choose_Result";
            this.Text = "Choose Assignment";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwfitLabel;
        private System.Windows.Forms.Label LogoLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.ComboBox AssigmentsComboBox;
        private System.Windows.Forms.Button ResultsButton;
        private System.Windows.Forms.Button MainPageButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}