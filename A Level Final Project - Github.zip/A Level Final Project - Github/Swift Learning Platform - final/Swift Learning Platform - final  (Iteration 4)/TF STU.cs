﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class TF_STU : Form
    {
        //global variables
        string globalstudentID = "";
        int globalCount;
        string globalWorkID = "";
        int globalQuestionCount;
        string trueFalseIndicator = "";
        string correctAnswer = "";
        public TF_STU(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            //values passed from previous forms are stored in global variables
            globalstudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database

            //query to Select Questions and Correct Answers linked to WorkID from Questions table
            string getQuestion = ("Select [Question], [Correct Answer] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(getQuestion, con); //puts data in format we can use


            DataSet ds = new DataSet(); //data returned from query
            DataTable dt = new DataTable(); //where data will be stored

            da.Fill(ds, "Question"); //data put in useable format
            dt = ds.Tables["Question"]; //data table is filled with data

            //Text at index corresponding to questionCOunt in the first row is placed in textbox
            QuestionTextBox.Text = dt.Rows[questionCount][0].ToString();
            //Text at index correspongin to questionCount in second row is stored in variable
            correctAnswer = dt.Rows[questionCount][1].ToString(); 

        }

        private void TrueButton_Click(object sender, EventArgs e)
        {
            //disables true button
            TrueButton.Enabled = false; 
            //enables false button
            FalseButton.Enabled = true;
            //trueFalseIndicator value is made true, stores the users answer
            trueFalseIndicator = "True";

        }

        private void FalseButton_Click(object sender, EventArgs e)
        {
            //disables false button
            FalseButton.Enabled = false;
            //enables true button
            TrueButton.Enabled = true;
            //trueFalseIndicator value is made false, stores the users answer
            trueFalseIndicator = "False";
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database


            if (trueFalseIndicator == "") //if user hasn't chosen an answer
            {
                //output error message
                ErrorLabel.Text = "Please select an answer. You may as well guess";
            }
            else //if user has selected answer
            {
                //query to fetch next question from Questions table
                string fetchQuestion = ("Select [Question Type] from Questions where WorkID='" + globalWorkID + "'");
                OleDbDataAdapter fetchDA = new OleDbDataAdapter(fetchQuestion, con); //puts data in useable format

                DataSet fetchDS = new DataSet(); //data returned
                DataTable fetchDT = new DataTable(); //where data will be stored

                fetchDA.Fill(fetchDS, "QuestionType"); //data is formatted
                fetchDT = fetchDS.Tables["QuestionType"]; //data is put into datatable
            
            if (trueFalseIndicator == correctAnswer) //if the users answer matches the correct answer
                {
                    MessageBox.Show("Correct", "Well done"); //outputs confirmation message
                    globalCount++; //add one to the user score
                    globalQuestionCount++; //add one to the question count
                }
                else //if the users answer doesn't match the correct answer
                {
                    MessageBox.Show("Incorrect. The correct answer was: " + correctAnswer, "Better luck next time!"); //outputs incorrect message
                    globalQuestionCount++; //adds one to question count
                }
                //case and switch statment, loads correct from using value from the first index of the datatable
                switch (fetchDT.Rows[globalQuestionCount][0])
                {
                    case "TF":
                        //loads True or False form
                        TF_STU tfTemplate = new TF_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        tfTemplate.Show();
                        break;
                    case "MC":
                        //loads Multiple Choice form
                        MC_STU mcTemplate = new MC_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        mcTemplate.Show();
                        break;
                    case "FC":
                        //loads Flashcard form
                        FC_Question_STU fcTemplate = new FC_Question_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fcTemplate.Show();
                        break;
                    case "OW":
                        //Loads One Word form
                        OW_STU owTemplate = new OW_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        owTemplate.Show();
                        break;
                    case "FB":
                        //Loads Fill in the blank form
                        FB_STU fbTemplate = new FB_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fbTemplate.Show();
                        break;
                    case "Stop":
                        //Loads View Assignments form as last question has been completed
                        View_Assignments completeAssigments = new View_Assignments(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        completeAssigments.Show();
                        break;
                }

                fetchDA.Dispose(); //diposes data adapter
                fetchDS.Dispose(); //diposes data set
                fetchDT.Dispose(); //diposes data table
                con.Close(); //closes connection to database

            }

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide();
            viewAssignments.Show();
        }
    }
}
