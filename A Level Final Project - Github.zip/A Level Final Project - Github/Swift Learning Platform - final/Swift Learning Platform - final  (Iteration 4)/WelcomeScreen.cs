﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class WelcomeScreen : Form
    {
        public WelcomeScreen()
        {
            InitializeComponent();
        }

        private void Student_Click(object sender, EventArgs e)
        { 
            //loads the student's login form, hides this form
            this.Hide();
            StudentLogin students = new StudentLogin();
            students.Show();
        }

        private void Teacher_Click(object sender, EventArgs e)
        {
            //loads teacher's login form, hides this form
            this.Hide();
            TeacherLogin teachers = new TeacherLogin();
            teachers.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //hides this form, exits program. 
            this.Hide();
        }

        private void CreateAccountButton_Click(object sender, EventArgs e)
        {
            //Loads Create an Account form
            AccountCreate accountCreate = new AccountCreate();
            this.Hide();
            accountCreate.Show();
        }
    }
}
