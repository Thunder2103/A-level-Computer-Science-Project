﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class WelcomeScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwiftLabel = new System.Windows.Forms.Label();
            this.Welcome = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.Label();
            this.Student = new System.Windows.Forms.Button();
            this.Teacher = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CreateAccountButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwiftLabel
            // 
            this.SwiftLabel.AutoSize = true;
            this.SwiftLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwiftLabel.Location = new System.Drawing.Point(12, 9);
            this.SwiftLabel.Name = "SwiftLabel";
            this.SwiftLabel.Size = new System.Drawing.Size(58, 30);
            this.SwiftLabel.TabIndex = 1;
            this.SwiftLabel.Text = "Swift";
            // 
            // Welcome
            // 
            this.Welcome.AutoSize = true;
            this.Welcome.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Welcome.Location = new System.Drawing.Point(288, 51);
            this.Welcome.Name = "Welcome";
            this.Welcome.Size = new System.Drawing.Size(190, 30);
            this.Welcome.TabIndex = 3;
            this.Welcome.Text = "Welcome to Swift...";
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Info.Location = new System.Drawing.Point(233, 81);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(290, 30);
            this.Info.TabIndex = 4;
            this.Info.Text = "Are you a Student or Teacher?";
            // 
            // Student
            // 
            this.Student.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Student.Location = new System.Drawing.Point(165, 166);
            this.Student.Name = "Student";
            this.Student.Size = new System.Drawing.Size(200, 77);
            this.Student.TabIndex = 5;
            this.Student.Text = "Student";
            this.Student.UseVisualStyleBackColor = true;
            this.Student.Click += new System.EventHandler(this.Student_Click);
            // 
            // Teacher
            // 
            this.Teacher.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Teacher.Location = new System.Drawing.Point(428, 166);
            this.Teacher.Name = "Teacher";
            this.Teacher.Size = new System.Drawing.Size(200, 78);
            this.Teacher.TabIndex = 6;
            this.Teacher.Text = "Teacher";
            this.Teacher.UseVisualStyleBackColor = true;
            this.Teacher.Click += new System.EventHandler(this.Teacher_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(12, 388);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(85, 50);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "<- Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(165, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 30);
            this.label1.TabIndex = 8;
            this.label1.Text = "Don\'t have an account?:";
            // 
            // CreateAccountButton
            // 
            this.CreateAccountButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateAccountButton.Location = new System.Drawing.Point(406, 289);
            this.CreateAccountButton.Name = "CreateAccountButton";
            this.CreateAccountButton.Size = new System.Drawing.Size(117, 36);
            this.CreateAccountButton.TabIndex = 9;
            this.CreateAccountButton.Text = "Create one";
            this.CreateAccountButton.UseVisualStyleBackColor = true;
            this.CreateAccountButton.Click += new System.EventHandler(this.CreateAccountButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // WelcomeScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.CreateAccountButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.Teacher);
            this.Controls.Add(this.Student);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.Welcome);
            this.Controls.Add(this.SwiftLabel);
            this.Name = "WelcomeScreen";
            this.Text = "Welcome Screen";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwiftLabel;
        private System.Windows.Forms.Label Welcome;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Button Student;
        private System.Windows.Forms.Button Teacher;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CreateAccountButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}