﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class FC_TEA : Form
    {
        //global variables
        string globalTeacherId;
        string globalClasses;
        string globalWorkID;
        public FC_TEA(string teacherId, string classes, string workID)
        {
            InitializeComponent();
            MessageBox.Show(workID); 
            //values passed from previous forms are stored in global variables
            globalTeacherId = teacherId;
            globalClasses = classes;
            globalWorkID = workID;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads the Setting Assignments form
            Setting_Assignments setAssignements = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
            this.Hide();
            setAssignements.Show();

        }

        private void SetQuestionButton_Click(object sender, EventArgs e)
        {
            //if either of the textboxes are empty
            if (QuestionTextBox.Text == string.Empty || AnswerTextBox.Text == string.Empty)
            { 
                //error message outputted 
                ErrorLabel.Text = "Please fill in all the boxes";
            }
            else //if both the boxes have been filled in 
            {
                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to the database 
                //query to insert question and answer into the databases's question table
                OleDbCommand insertQuestion = new OleDbCommand("Insert Into Questions([WorkID],[Question Type],[Question]," +
                    "[Correct Answer]) Values(@workID,'FC',@question, @correctAns)", con);
                //query parameters
                insertQuestion.Parameters.AddRange(new OleDbParameter[]
                {
                        new OleDbParameter("@workID", globalWorkID), //WorkID parameter
                        new OleDbParameter("@question", QuestionTextBox.Text), //Question parameter
                        new OleDbParameter("@correctAns", AnswerTextBox.Text), //Correct answer parameter

                });

                insertQuestion.ExecuteNonQuery(); //execute query
                insertQuestion.Dispose(); //dispose query 
                con.Close(); //closes connection

                //loads Setting Assignment form. 
                Setting_Assignments chooseAssignement = new Setting_Assignments(globalTeacherId, globalClasses, globalWorkID);
                this.Hide();
                chooseAssignement.Show();
            }
        }
    }
}
