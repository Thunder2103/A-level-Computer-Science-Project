﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class MC_STU : Form
    {
        //global variables
        string globalStudentID;
        int globalCount;
        string globalWorkID;
        int globalQuestionCount;

        string globalCorrectAnswer = "";
        string globalStudentAnswer = "";
        public MC_STU(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            //values passed from previous form stored in global variables
            globalStudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;


            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database
            //Query to retrieve the question and all the answers from Questions table
            string getQuestion = ("Select [Question], [Correct Answer], [Answer 2], " +
                "[Answer 3], [Answer 4] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(getQuestion, con); //data adpater will put data in useable format
            DataSet ds = new DataSet(); //returned data
            DataTable dt = new DataTable(); //where data will be stored

            da.Fill(ds, "QuestionAnswer"); //data converted into useable format
            dt = ds.Tables["QuestionAnswer"]; //stores data in datatable

            //stores the text on row one at the index corresponding to the value of globalQuestionCount 
            globalCorrectAnswer = dt.Rows[globalQuestionCount][1].ToString(); 

            //declares a new List to store randomly generated numbers
            List<int> answerOrderList = new List<int>(); 
            //variables store the returned value from ShuffleAnswers() function
            int x = ShuffleAnswers(answerOrderList); //the function takes the list as a parameter
            int y = ShuffleAnswers(answerOrderList);
            int z = ShuffleAnswers(answerOrderList);
            int a = ShuffleAnswers(answerOrderList);

            //Inserts Text from row 0, index corresponding to globalQuestionCount into Question Textboxes
            QuestionTextBox.Text = dt.Rows[globalQuestionCount][0].ToString();
            //Possible answers are randomly inserted into Answer textboxes
            //Text is inserted from rows corresponding to values of x,y,z,a
            Answer1TextBox.Text = dt.Rows[globalQuestionCount][x].ToString();
            Answer2Textbox.Text = dt.Rows[globalQuestionCount][y].ToString();
            Answer3Textbox.Text = dt.Rows[globalQuestionCount][z].ToString();
            Answer4Textbox.Text = dt.Rows[globalQuestionCount][a].ToString();



        }

        private void BackButton_Click(object sender, EventArgs e)
        { 
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide(); 
            viewAssignments.Show();

        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to database

            if (globalStudentAnswer == "") //if user hasn't inputted and answer
            {
                MessageBox.Show("Please guess, it's better than nothing", "Guess!");  //outputs error message
            }
            else //if user has answered the question
            {
                //Query to select next Question Type from Questions table
                string fetchQuestion = ("Select [Question Type] from Questions where WorkID='" + globalWorkID + "'");
                OleDbDataAdapter fetchDA = new OleDbDataAdapter(fetchQuestion, con); //puts data in useable format

                DataSet fetchDS = new DataSet(); //data returned
                DataTable fetchDT = new DataTable(); //where data will be stored

                fetchDA.Fill(fetchDS, "QuestionType"); //converts data into useable format
                fetchDT = fetchDS.Tables["QuestionType"]; //fills datatable with data

                if (globalStudentAnswer == globalCorrectAnswer) //if the users answer is correct
                {
                    MessageBox.Show("Correct", "Well done!"); //outputs correct message
                    globalCount++; //adds one to score
                    globalQuestionCount++; //adds one to question count

                }
                else //if users answer is incorrect
                { 
                    MessageBox.Show("Incorrect. The correct answer is: " + globalCorrectAnswer, "Better luck next time!"); //outputs incorrect message 
                    globalQuestionCount++; //adds one to question count only
                }
                //case and switch statment, loads correct from using value from the first index of the datatable
                switch (fetchDT.Rows[globalQuestionCount][0])
                {
                    case "TF":
                        //loads True or False form
                        TF_STU tfTemplate = new TF_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        tfTemplate.Show();
                        break;
                    case "MC":
                        //loads Multiple Choice form
                        MC_STU mcTemplate = new MC_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        mcTemplate.Show();
                        break;
                    case "FC":
                        //loads Flashcard form
                        FC_Question_STU fcTemplate = new FC_Question_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fcTemplate.Show();
                        break;
                    case "OW":
                        //Loads One Word form
                        OW_STU owTemplate = new OW_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        owTemplate.Show();
                        break;
                    case "FB":
                        //Loads Fill in the blank form
                        FB_STU fbTemplate = new FB_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fbTemplate.Show();
                        break;
                    case "Stop":
                        //Loads View Assignments form as last question has been completed
                        View_Assignments completeAssigments = new View_Assignments(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        completeAssigments.Show();
                        break;
                }

                fetchDA.Dispose(); //diposes data adapter
                fetchDS.Dispose(); //diposes data set
                fetchDT.Dispose(); //diposes data table
                con.Close(); //closes connection to database
            }

        }

        private void Answer1Button_Click(object sender, EventArgs e)
        { 
            //disables button just pressed
            Answer1Button.Enabled = false;
            //enables all other answer buttons
            Answer2Button.Enabled = true;
            Answer3Button.Enabled = true;
            Answer4Button.Enabled = true;
            //stores text in globalStudentAnswer to keep record of users answer
            globalStudentAnswer = Answer1TextBox.Text;

        }

        private void Answer2Button_Click(object sender, EventArgs e)
        {
            //disables button just pressed
            Answer2Button.Enabled = false;
            //enables all other answer buttons
            Answer1Button.Enabled = true;
            Answer3Button.Enabled = true;
            Answer4Button.Enabled = true;
            //stores text in globalStudentAnswer to keep record of users answer
            globalStudentAnswer = Answer3Textbox.Text;

        }

        private void Answer3Button_Click(object sender, EventArgs e)
        {
            //disables button just pressed
            Answer3Button.Enabled = false;
            //enables all other answer buttons
            Answer1Button.Enabled = true;
            Answer2Button.Enabled = true;
            Answer4Button.Enabled = true;
            //stores text in globalStudentAnswer to keep record of users answer
            globalStudentAnswer = Answer3Textbox.Text;

        }

        private void Answer4Button_Click(object sender, EventArgs e)
        {
            //disables button just pressed
            Answer4Button.Enabled = false;
            //enables all other answer buttons
            Answer1Button.Enabled = true;
            Answer2Button.Enabled = true;
            Answer3Button.Enabled = true;
            //stores text in globalStudentAnswer to keep record of users answer
            globalStudentAnswer = Answer4Textbox.Text;
        }

        //function to place the answers in a random text
        private int ShuffleAnswers(List<int> answerOrderList) //paramters
        {
            Random rnd = new Random(); //declared Random() function
            int n = rnd.Next(1, 5); //generated random number between 1 and 4
            if (answerOrderList.Contains(n)) //if the answerOrderList already has the generated number in it
            {
                return ShuffleAnswers(answerOrderList); //the function is recalled
            }
            else //if the number is not in the list
            {
                answerOrderList.Add(n); //we add it to the list
                return n; //we return the generated number
            }

        }
    }
}
