﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class Create_a_Class : Form
    { 
        //global variables
        string globalTeacherId;
        public Create_a_Class(string teacherID)
        {
            InitializeComponent();
            globalTeacherId = teacherID; 

        }

        private void CreateClassButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource; 
            con.Open(); //establish connection to database
            
            //query to insert new record into the Classes table, the TeacherID is inserted and 0,
            //as the number of students in the class is 0
            OleDbCommand cmdInsert = new OleDbCommand("INSERT INTO Classes(TeacherID, NumStudents) VALUES ('" + globalTeacherId + 
                "','0')", con);
            OleDbDataReader reader = cmdInsert.ExecuteReader(); //executes query
            reader.Close(); //closes reader 
            cmdInsert.Dispose(); //disposes commmand
            
            ClassCreatedLabel.Text = "Class created..."; //output confirmation class is created
            con.Close(); //closes connection
            con.Open(); //opens new connection 
            
            //query to select ClassID's with users TeacherID
            string cmdClassCode = ("Select ClassID from Classes where TeacherID = '" + globalTeacherId + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(cmdClassCode, con); //dataapdater returns data in format we can use
            DataSet ds = new DataSet(); //dataset which is the data returned
            DataTable dt = new DataTable(); //the datatable is where the returned data is stored 
            da.Fill(ds, "ClassCodes"); //turns data in datset into format we can use
            dt = ds.Tables["ClassCodes"]; //fills datatable with data
            
            int rowcount = (dt.Rows.Count) - 1; //variable to store number of rows in datatable
            //outputs first index in datatable which is the ClassID of the class just made
            ClassCodeLabel.Text = "Your new class code: " + dt.Rows[rowcount][0].ToString(); 

            da.Dispose(); //disposes data adpater
            ds.Dispose(); //disposes data set
            dt.Dispose(); //disposes data table 
            con.Close(); //closes connection

        }

        private void MainPageButton_Click(object sender, EventArgs e)
        {
            //loads teachers homepage form 
            Teacher_Homepage teacherHomepage = new Teacher_Homepage(globalTeacherId);
            this.Hide();
            teacherHomepage.Show(); 
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //exits program
            this.Hide();
        }

        private void ViewClassesButton_Click(object sender, EventArgs e)
        { 
            //loads view classes form
            ViewingClasses viewClasses = new ViewingClasses(globalTeacherId);
            this.Hide(); 
            viewClasses.Show();
        }

        private void CreateAssignmentButton_Click(object sender, EventArgs e)
        { 
            //loads create assignment form
            string workID = ""; 
            CreateAssignment createAssignment = new CreateAssignment(globalTeacherId, workID);
            this.Hide(); 
            createAssignment.Show();
        }
    }
}
