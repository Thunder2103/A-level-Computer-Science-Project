﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class View_Assignments : Form
    {
        //global variables
        string globalStudentID = "";
        int globalCount = 0;
        string globalWorkID = "";
        int globalQuestionCount = -1;
        public View_Assignments(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            //Values passed from previous forms stored in global variables
            globalStudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;


            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database
            
            DataSet ds = new DataSet(); //data that is returned
            DataTable dt = new DataTable(); //where data will be stored

            //query to select all ClassID's connected to the users StudentID from ClassStu table
            OleDbCommand getClassID = new OleDbCommand("Select ClassID from ClassStudent where StudentID = @studentID", con);
            //query parameters
            getClassID.Parameters.Add("@studentID", globalStudentID); //StudentID parameter
            OleDbDataAdapter da = new OleDbDataAdapter(getClassID); //puts data into a format we can use

            da.Fill(ds, "ClassIDFilter"); //returned data formatted
            dt = ds.Tables["ClassIDFilter"]; //datatable filled woth data
            int rowCount = (dt.Rows.Count) - 1; //stores number of rows the datatable has

            //for loop iterates through rows in datatable
            for (int i = 0; i <= rowCount; i++)
            {
                //Query to select WorkID from Classwork table using the ClassID's (returned from last query)
                //the ClassID is the the value from each index of the datatable
                OleDbCommand getWorkID = new OleDbCommand("Select WorkID from Classwork where ClassID=" + dt.Rows[i][0], con);
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(getWorkID); //new data adapter

                DataSet dataSet = new DataSet(); //new data set
                DataTable dataTable = new DataTable(); //new data table

                dataAdapter.Fill(dataSet, "WorkIDFilter");
                dataTable = dataSet.Tables["WorkIDFilter"]; //fills datatable with returned
                int tableRowCount = (dataTable.Rows.Count) - 1; //varaible stores number of rows in datatable
                 
                //for loop iterates through rows of datatable
                for (int k = 0; k <= tableRowCount; k++)
                {
                    //displays data at each index of database into combo box
                    SelectAssignmentDropBox.Items.Add("Assignment ID: " + dataTable.Rows[k][0].ToString());


                }
                dataAdapter.Dispose(); //diposes data adapter
                dataSet.Dispose(); //diposes data set
                dataTable.Dispose();  //diposes data table

            }
            da.Dispose(); //dispose data adpater
            ds.Dispose(); //diposes data set
            dt.Dispose(); //diposes data table
            con.Close(); //closes connection

        }

        private void MainScreenButton_Click(object sender, EventArgs e)
        {
            //if the question count is greater than zero
            if (globalQuestionCount > 0)
            {
                //Outputs warning message
                //if the user presses "Yes". They won't save their work.
                if (MessageBox.Show("You have not saved your work. Continue anyway?",  
                    "No assignment selected!", MessageBoxButtons.YesNo) == DialogResult.Yes) 
                {
                    //loads Student Homepage Form
                    Student_Homepage studentHomepage = new Student_Homepage(globalStudentID);
                    this.Hide();
                    studentHomepage.Show();

                }
            }
            else //if the user has no work to save 
            {
                //loads Student Homepage Form
                Student_Homepage studentHomepage = new Student_Homepage(globalStudentID);
                this.Hide();
                studentHomepage.Show();
            }
           
        }

        private void GetWorkButton_Click(object sender, EventArgs e)
        {
            //value selected in combo box stored in globalWorkID variable
            globalWorkID = SelectAssignmentDropBox.Text; 
            //if user has not selected any work
            if (globalWorkID == "")
            {
                //output error message
                MessageBox.Show("You have not selected any work to do", "No assignment selected!");
            }
            else //if the user has selected work.
            {
                //excess text is removed leaving only the WorkID
                globalWorkID = globalWorkID.Remove(0, 15);
                OleDbConnection con = new OleDbConnection();
                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to database

                //WorkID is the option the user chose from the combo box
              
                //Query to check if user has already completed the Work
                OleDbCommand checkFinishedWork = new OleDbCommand("Select * from Results where StudentID='" + globalStudentID + "" +
                    "'and WorkID='" + globalWorkID + "'", con);
                OleDbDataReader checkReader = checkFinishedWork.ExecuteReader(); //readers ecexutes query
                if (checkReader.HasRows) //if reader has returned data
                {
                    //Output error message
                    MessageBox.Show("You have already finished this assignment", "Assignment already completed");
                    checkReader.Close(); //close reader
                    checkFinishedWork.Dispose(); //dipose command
                }
                else //if user has not completed work
                {
                    checkReader.Close(); //close reader
                    checkFinishedWork.Dispose(); //dipose command
                    
                    //set Question count and score to 0 by default
                    globalCount = 0;
                    globalQuestionCount = 0;

                    //Query to select Question Types linked to WorkID from Questions table
                    string fetchQuestion = ("Select [Question Type] from Questions where WorkID='" + globalWorkID + "'");
                    OleDbDataAdapter fetchDA = new OleDbDataAdapter(fetchQuestion, con); //adapter puts data in format we can use

                    DataSet fetchDS = new DataSet(); //data returned
                    DataTable fetchDT = new DataTable(); //where data will be stored

                    fetchDA.Fill(fetchDS, "QuestionType"); //converts data into useable format
                    fetchDT = fetchDS.Tables["QuestionType"]; //places data in datatable

                    //case and switch statment, loads correct from using value from the first index of the datatable
                    switch (fetchDT.Rows[globalQuestionCount][0])
                    {
                        case "TF":
                            //loads True or False form
                            TF_STU tfTemplate = new TF_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                            this.Hide();
                            tfTemplate.Show();
                            break;
                        case "MC":
                            //loads Multiple Choice form
                            MC_STU mcTemplate = new MC_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                            this.Hide();
                            mcTemplate.Show();
                            break;
                        case "FC":
                            //loads Flashcard form
                            FC_Question_STU fcTemplate = new FC_Question_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                            this.Hide();
                            fcTemplate.Show();
                            break;
                        case "OW":
                            //Loads One Word form
                            OW_STU owTemplate = new OW_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                            this.Hide();
                            owTemplate.Show();
                            break;
                        case "FB":
                            //Loads Fill in the blank form
                            FB_STU fbTemplate = new FB_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                            this.Hide();
                            fbTemplate.Show();
                            break;
                    }

                    fetchDA.Dispose(); //diposes data adapter
                    fetchDS.Dispose(); //diposes data set
                    fetchDT.Dispose(); //diposes data table
                    con.Close(); //closes connection to database

                }
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database


            DataSet dSet = new DataSet(); //data returned from query
            DataTable dTable = new DataTable(); //where data will be stored
            //query to select all scores linked to the users StudentID
            OleDbCommand getResults = new OleDbCommand("Select * from [Results] where StudentID='" + globalStudentID + "'", con);
            OleDbDataAdapter da = new OleDbDataAdapter(getResults); //data adpater puts data in a format we can use

            da.Fill(dSet, "ResultsFilter"); //data is put in format we can use
            dTable = dSet.Tables["ResultsFilter"]; //data table is filled with data

            int resultRowCount = (dTable.Rows.Count) - 1; //stores number of rows in datatable
            //for loop iterates through data table
            for (int i = 0; i <= resultRowCount; i++)
            {
                //The Students scores at each index are displayed in the DisplayFinishedAssignments richtextbox
                DisplayFinishedAssignments.Text += Environment.NewLine + "Work Number: " + dTable.Rows[i][2].ToString() + " " +
                    "Score: " + dTable.Rows[i][3].ToString();
                i++;

            }
        }

        private void FinishWorkButton_Click(object sender, EventArgs e)
        {
            if (globalQuestionCount <= -1) //if the user has not completed any work
            {
                //Error message outputted
                MessageBox.Show("You have not completed any assignments to save", "No assignment completed");
            }
            else //if the user has work to save
            {

                OleDbConnection con = new OleDbConnection();

                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


                con.ConnectionString = dbProvider + dbSource;
                con.Open(); //establish connection to the database
                //query to Insert the users scores and their username into the Results table
                OleDbCommand insertScore = new OleDbCommand("Insert Into [Results]([StudentID],[WorkID],[Score]) " +
                    "Values(@studentID, @workID, @score)", con);
                //query parameters
                insertScore.Parameters.AddRange(new OleDbParameter[]
                {
                    new OleDbParameter("@studentID", globalStudentID), //StudentID parameter
                    new OleDbParameter("@workID", globalWorkID), //WorkID parameter
                    new OleDbParameter("@score", globalCount) //Score parameter
                });
                OleDbDataReader scoreReader = insertScore.ExecuteReader(); //reader executes query
                insertScore.Dispose(); //diposes command
                scoreReader.Close(); //closes reader
                con.Close(); //closes connection

                //loads Student Homepage form
                Student_Homepage studentMainScreen = new Student_Homepage(globalStudentID);
                this.Hide();
                studentMainScreen.Show();
            }

        }
    }
}
