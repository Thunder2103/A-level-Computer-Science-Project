﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class View_Results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwfitLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.AssignmentLabel = new System.Windows.Forms.Label();
            this.ActiveAssignmentsRichTB = new System.Windows.Forms.RichTextBox();
            this.RefreshButton = new System.Windows.Forms.Button();
            this.MainPageButton = new System.Windows.Forms.Button();
            this.WorkResultsButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwfitLabel
            // 
            this.SwfitLabel.AutoSize = true;
            this.SwfitLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwfitLabel.Location = new System.Drawing.Point(12, 9);
            this.SwfitLabel.Name = "SwfitLabel";
            this.SwfitLabel.Size = new System.Drawing.Size(58, 30);
            this.SwfitLabel.TabIndex = 2;
            this.SwfitLabel.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(269, 53);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(267, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Viewing active assignments";
            // 
            // AssignmentLabel
            // 
            this.AssignmentLabel.AutoSize = true;
            this.AssignmentLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AssignmentLabel.Location = new System.Drawing.Point(234, 83);
            this.AssignmentLabel.Name = "AssignmentLabel";
            this.AssignmentLabel.Size = new System.Drawing.Size(320, 30);
            this.AssignmentLabel.TabIndex = 5;
            this.AssignmentLabel.Text = "Here are your active assignments";
            // 
            // ActiveAssignmentsRichTB
            // 
            this.ActiveAssignmentsRichTB.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ActiveAssignmentsRichTB.Location = new System.Drawing.Point(212, 116);
            this.ActiveAssignmentsRichTB.Name = "ActiveAssignmentsRichTB";
            this.ActiveAssignmentsRichTB.Size = new System.Drawing.Size(359, 207);
            this.ActiveAssignmentsRichTB.TabIndex = 6;
            this.ActiveAssignmentsRichTB.Text = "Student Results:";
            // 
            // RefreshButton
            // 
            this.RefreshButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RefreshButton.Location = new System.Drawing.Point(586, 280);
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(100, 43);
            this.RefreshButton.TabIndex = 9;
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.UseVisualStyleBackColor = true;
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // MainPageButton
            // 
            this.MainPageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainPageButton.Location = new System.Drawing.Point(12, 401);
            this.MainPageButton.Name = "MainPageButton";
            this.MainPageButton.Size = new System.Drawing.Size(125, 37);
            this.MainPageButton.TabIndex = 10;
            this.MainPageButton.Text = "<- Main Page";
            this.MainPageButton.UseVisualStyleBackColor = true;
            this.MainPageButton.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // WorkResultsButton
            // 
            this.WorkResultsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WorkResultsButton.Location = new System.Drawing.Point(546, 401);
            this.WorkResultsButton.Name = "WorkResultsButton";
            this.WorkResultsButton.Size = new System.Drawing.Size(242, 37);
            this.WorkResultsButton.TabIndex = 11;
            this.WorkResultsButton.Text = "Choose Another Assignment ->";
            this.WorkResultsButton.UseVisualStyleBackColor = true;
            this.WorkResultsButton.Click += new System.EventHandler(this.WorkResultsButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // View_Results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.WorkResultsButton);
            this.Controls.Add(this.MainPageButton);
            this.Controls.Add(this.RefreshButton);
            this.Controls.Add(this.ActiveAssignmentsRichTB);
            this.Controls.Add(this.AssignmentLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.SwfitLabel);
            this.Name = "View_Results";
            this.Text = "View_Results";
            this.Load += new System.EventHandler(this.View_Results_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwfitLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label AssignmentLabel;
        private System.Windows.Forms.RichTextBox ActiveAssignmentsRichTB;
        private System.Windows.Forms.Button RefreshButton;
        private System.Windows.Forms.Button MainPageButton;
        private System.Windows.Forms.Button WorkResultsButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}