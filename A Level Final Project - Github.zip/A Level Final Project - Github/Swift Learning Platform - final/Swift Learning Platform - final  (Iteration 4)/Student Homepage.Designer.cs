﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Student_Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.ViewAssignmentsButton = new System.Windows.Forms.Button();
            this.JoinClassesButton = new System.Windows.Forms.Button();
            this.ViewClassesButton = new System.Windows.Forms.Button();
            this.SignOutButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 1;
            this.NameLogo.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(232, 61);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(319, 30);
            this.InfoLabel.TabIndex = 3;
            this.InfoLabel.Text = "Welcome student, time to learn...";
            // 
            // ViewAssignmentsButton
            // 
            this.ViewAssignmentsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ViewAssignmentsButton.Location = new System.Drawing.Point(300, 94);
            this.ViewAssignmentsButton.Name = "ViewAssignmentsButton";
            this.ViewAssignmentsButton.Size = new System.Drawing.Size(178, 48);
            this.ViewAssignmentsButton.TabIndex = 4;
            this.ViewAssignmentsButton.Text = "View Assignments";
            this.ViewAssignmentsButton.UseVisualStyleBackColor = true;
            this.ViewAssignmentsButton.Click += new System.EventHandler(this.ViewAssignmentsButton_Click);
            // 
            // JoinClassesButton
            // 
            this.JoinClassesButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.JoinClassesButton.Location = new System.Drawing.Point(232, 180);
            this.JoinClassesButton.Name = "JoinClassesButton";
            this.JoinClassesButton.Size = new System.Drawing.Size(135, 47);
            this.JoinClassesButton.TabIndex = 6;
            this.JoinClassesButton.Text = "Join A Class";
            this.JoinClassesButton.UseVisualStyleBackColor = true;
            this.JoinClassesButton.Click += new System.EventHandler(this.JoinClassesButton_Click);
            // 
            // ViewClassesButton
            // 
            this.ViewClassesButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ViewClassesButton.Location = new System.Drawing.Point(417, 180);
            this.ViewClassesButton.Name = "ViewClassesButton";
            this.ViewClassesButton.Size = new System.Drawing.Size(134, 47);
            this.ViewClassesButton.TabIndex = 7;
            this.ViewClassesButton.Text = "View Classes ";
            this.ViewClassesButton.UseVisualStyleBackColor = true;
            this.ViewClassesButton.Click += new System.EventHandler(this.ViewClassesButton_Click);
            // 
            // SignOutButton
            // 
            this.SignOutButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SignOutButton.Location = new System.Drawing.Point(12, 395);
            this.SignOutButton.Name = "SignOutButton";
            this.SignOutButton.Size = new System.Drawing.Size(123, 43);
            this.SignOutButton.TabIndex = 8;
            this.SignOutButton.Text = "<- Sign Out";
            this.SignOutButton.UseVisualStyleBackColor = true;
            this.SignOutButton.Click += new System.EventHandler(this.SignOutButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(700, 397);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(88, 41);
            this.ExitButton.TabIndex = 9;
            this.ExitButton.Text = "Exit ->";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // Student_Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SignOutButton);
            this.Controls.Add(this.ViewClassesButton);
            this.Controls.Add(this.JoinClassesButton);
            this.Controls.Add(this.ViewAssignmentsButton);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "Student_Homepage";
            this.Text = "Student Homepage";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Button ViewAssignmentsButton;
        private System.Windows.Forms.Button JoinClassesButton;
        private System.Windows.Forms.Button ViewClassesButton;
        private System.Windows.Forms.Button SignOutButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}