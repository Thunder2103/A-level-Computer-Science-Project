﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class OW_STU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.OneWordLabel = new System.Windows.Forms.Label();
            this.QuestionTextbox = new System.Windows.Forms.TextBox();
            this.AnswerTextbox = new System.Windows.Forms.TextBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ContinueButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 7;
            this.NameLogo.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(298, 55);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(190, 30);
            this.InfoLabel.TabIndex = 16;
            this.InfoLabel.Text = "One word answer...";
            // 
            // OneWordLabel
            // 
            this.OneWordLabel.AutoSize = true;
            this.OneWordLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.OneWordLabel.Location = new System.Drawing.Point(298, 85);
            this.OneWordLabel.Name = "OneWordLabel";
            this.OneWordLabel.Size = new System.Drawing.Size(201, 30);
            this.OneWordLabel.TabIndex = 17;
            this.OneWordLabel.Text = "Type in the answer...";
            // 
            // QuestionTextbox
            // 
            this.QuestionTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextbox.Location = new System.Drawing.Point(62, 148);
            this.QuestionTextbox.Name = "QuestionTextbox";
            this.QuestionTextbox.ReadOnly = true;
            this.QuestionTextbox.Size = new System.Drawing.Size(695, 35);
            this.QuestionTextbox.TabIndex = 18;
            this.QuestionTextbox.Text = "Question Here";
            // 
            // AnswerTextbox
            // 
            this.AnswerTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AnswerTextbox.Location = new System.Drawing.Point(62, 206);
            this.AnswerTextbox.Name = "AnswerTextbox";
            this.AnswerTextbox.Size = new System.Drawing.Size(695, 35);
            this.AnswerTextbox.TabIndex = 19;
            this.AnswerTextbox.Text = "Type Your Answer Here";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 398);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(160, 40);
            this.BackButton.TabIndex = 20;
            this.BackButton.Text = "<- Stop Assignment";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ContinueButton
            // 
            this.ContinueButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButton.Location = new System.Drawing.Point(628, 398);
            this.ContinueButton.Name = "ContinueButton";
            this.ContinueButton.Size = new System.Drawing.Size(160, 40);
            this.ContinueButton.TabIndex = 21;
            this.ContinueButton.Text = "Continue ->";
            this.ContinueButton.UseVisualStyleBackColor = true;
            this.ContinueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // OW_STU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ContinueButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.AnswerTextbox);
            this.Controls.Add(this.QuestionTextbox);
            this.Controls.Add(this.OneWordLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "OW_STU";
            this.Text = "One Word";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label OneWordLabel;
        private System.Windows.Forms.TextBox QuestionTextbox;
        private System.Windows.Forms.TextBox AnswerTextbox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ContinueButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}