﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class ViewingClasses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.DisplayClassesTextbox = new System.Windows.Forms.RichTextBox();
            this.CreateClassButton = new System.Windows.Forms.Button();
            this.WorkResultsButton = new System.Windows.Forms.Button();
            this.HomepageButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(257, 77);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(283, 30);
            this.InfoLabel.TabIndex = 3;
            this.InfoLabel.Text = "Here is a list of your classes...";
            // 
            // DisplayClassesTextbox
            // 
            this.DisplayClassesTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DisplayClassesTextbox.Location = new System.Drawing.Point(221, 110);
            this.DisplayClassesTextbox.Name = "DisplayClassesTextbox";
            this.DisplayClassesTextbox.Size = new System.Drawing.Size(358, 177);
            this.DisplayClassesTextbox.TabIndex = 6;
            this.DisplayClassesTextbox.Text = "";
            // 
            // CreateClassButton
            // 
            this.CreateClassButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateClassButton.Location = new System.Drawing.Point(158, 306);
            this.CreateClassButton.Name = "CreateClassButton";
            this.CreateClassButton.Size = new System.Drawing.Size(123, 40);
            this.CreateClassButton.TabIndex = 7;
            this.CreateClassButton.Text = "Create Class";
            this.CreateClassButton.UseVisualStyleBackColor = true;
            this.CreateClassButton.Click += new System.EventHandler(this.CreateClassButton_Click);
            // 
            // WorkResultsButton
            // 
            this.WorkResultsButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WorkResultsButton.Location = new System.Drawing.Point(515, 306);
            this.WorkResultsButton.Name = "WorkResultsButton";
            this.WorkResultsButton.Size = new System.Drawing.Size(123, 40);
            this.WorkResultsButton.TabIndex = 8;
            this.WorkResultsButton.Text = "Work Results";
            this.WorkResultsButton.UseVisualStyleBackColor = true;
            this.WorkResultsButton.Click += new System.EventHandler(this.WorkResultsButton_Click);
            // 
            // HomepageButton
            // 
            this.HomepageButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HomepageButton.Location = new System.Drawing.Point(12, 395);
            this.HomepageButton.Name = "HomepageButton";
            this.HomepageButton.Size = new System.Drawing.Size(117, 43);
            this.HomepageButton.TabIndex = 9;
            this.HomepageButton.Text = "<- Main page";
            this.HomepageButton.UseVisualStyleBackColor = true;
            this.HomepageButton.Click += new System.EventHandler(this.HomepageButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 12);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // ViewingClasses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.HomepageButton);
            this.Controls.Add(this.WorkResultsButton);
            this.Controls.Add(this.CreateClassButton);
            this.Controls.Add(this.DisplayClassesTextbox);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "ViewingClasses";
            this.Text = "ViewingClasses";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.RichTextBox DisplayClassesTextbox;
        private System.Windows.Forms.Button CreateClassButton;
        private System.Windows.Forms.Button WorkResultsButton;
        private System.Windows.Forms.Button HomepageButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}