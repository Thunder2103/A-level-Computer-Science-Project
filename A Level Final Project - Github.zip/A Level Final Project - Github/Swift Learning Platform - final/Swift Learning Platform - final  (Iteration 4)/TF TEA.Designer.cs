﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class TF_TEA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.QuestionLabel = new System.Windows.Forms.Label();
            this.QuestionTextbox = new System.Windows.Forms.TextBox();
            this.ErrorMessageLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TruthCorrectButton = new System.Windows.Forms.Button();
            this.FalseCorrectButton = new System.Windows.Forms.Button();
            this.DifferentTemplateButton = new System.Windows.Forms.Button();
            this.SetQuestionButton = new System.Windows.Forms.Button();
            this.CorrectAnsErrorLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Swift";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(269, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "True and false template...";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(288, 74);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(199, 30);
            this.InfoLabel.TabIndex = 5;
            this.InfoLabel.Text = "Fill in all the boxes...";
            // 
            // QuestionLabel
            // 
            this.QuestionLabel.AutoSize = true;
            this.QuestionLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionLabel.Location = new System.Drawing.Point(12, 144);
            this.QuestionLabel.Name = "QuestionLabel";
            this.QuestionLabel.Size = new System.Drawing.Size(102, 30);
            this.QuestionLabel.TabIndex = 6;
            this.QuestionLabel.Text = "Question:";
            // 
            // QuestionTextbox
            // 
            this.QuestionTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextbox.Location = new System.Drawing.Point(120, 144);
            this.QuestionTextbox.Name = "QuestionTextbox";
            this.QuestionTextbox.Size = new System.Drawing.Size(668, 35);
            this.QuestionTextbox.TabIndex = 7;
            // 
            // ErrorMessageLabel
            // 
            this.ErrorMessageLabel.AutoSize = true;
            this.ErrorMessageLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorMessageLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorMessageLabel.Location = new System.Drawing.Point(120, 182);
            this.ErrorMessageLabel.Name = "ErrorMessageLabel";
            this.ErrorMessageLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorMessageLabel.TabIndex = 16;
            this.ErrorMessageLabel.Text = "Filler Text";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(225, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(440, 30);
            this.label2.TabIndex = 17;
            this.label2.Text = "Press a button to confirm the correct answer...";
            // 
            // TruthCorrectButton
            // 
            this.TruthCorrectButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TruthCorrectButton.Location = new System.Drawing.Point(225, 241);
            this.TruthCorrectButton.Name = "TruthCorrectButton";
            this.TruthCorrectButton.Size = new System.Drawing.Size(150, 45);
            this.TruthCorrectButton.TabIndex = 18;
            this.TruthCorrectButton.Text = "True is correct";
            this.TruthCorrectButton.UseVisualStyleBackColor = true;
            this.TruthCorrectButton.Click += new System.EventHandler(this.TruthCorrectButton_Click);
            // 
            // FalseCorrectButton
            // 
            this.FalseCorrectButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FalseCorrectButton.Location = new System.Drawing.Point(515, 241);
            this.FalseCorrectButton.Name = "FalseCorrectButton";
            this.FalseCorrectButton.Size = new System.Drawing.Size(150, 45);
            this.FalseCorrectButton.TabIndex = 19;
            this.FalseCorrectButton.Text = "False is correct";
            this.FalseCorrectButton.UseVisualStyleBackColor = true;
            this.FalseCorrectButton.Click += new System.EventHandler(this.FalseCorrectButton_Click);
            // 
            // DifferentTemplateButton
            // 
            this.DifferentTemplateButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DifferentTemplateButton.Location = new System.Drawing.Point(12, 399);
            this.DifferentTemplateButton.Name = "DifferentTemplateButton";
            this.DifferentTemplateButton.Size = new System.Drawing.Size(240, 39);
            this.DifferentTemplateButton.TabIndex = 20;
            this.DifferentTemplateButton.Text = "<- Choose a different template";
            this.DifferentTemplateButton.UseVisualStyleBackColor = true;
            this.DifferentTemplateButton.Click += new System.EventHandler(this.DifferentTemplateButton_Click);
            // 
            // SetQuestionButton
            // 
            this.SetQuestionButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetQuestionButton.Location = new System.Drawing.Point(651, 399);
            this.SetQuestionButton.Name = "SetQuestionButton";
            this.SetQuestionButton.Size = new System.Drawing.Size(137, 40);
            this.SetQuestionButton.TabIndex = 21;
            this.SetQuestionButton.Text = "Set Question ->";
            this.SetQuestionButton.UseVisualStyleBackColor = true;
            this.SetQuestionButton.Click += new System.EventHandler(this.SetQuestionButton_Click);
            // 
            // CorrectAnsErrorLabel
            // 
            this.CorrectAnsErrorLabel.AutoSize = true;
            this.CorrectAnsErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CorrectAnsErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.CorrectAnsErrorLabel.Location = new System.Drawing.Point(225, 289);
            this.CorrectAnsErrorLabel.Name = "CorrectAnsErrorLabel";
            this.CorrectAnsErrorLabel.Size = new System.Drawing.Size(99, 30);
            this.CorrectAnsErrorLabel.TabIndex = 22;
            this.CorrectAnsErrorLabel.Text = "Filler Text";
            this.CorrectAnsErrorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // TF_TEA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.CorrectAnsErrorLabel);
            this.Controls.Add(this.SetQuestionButton);
            this.Controls.Add(this.DifferentTemplateButton);
            this.Controls.Add(this.FalseCorrectButton);
            this.Controls.Add(this.TruthCorrectButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ErrorMessageLabel);
            this.Controls.Add(this.QuestionTextbox);
            this.Controls.Add(this.QuestionLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NameLabel);
            this.Name = "TF_TEA";
            this.Text = "True and False";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label QuestionLabel;
        private System.Windows.Forms.TextBox QuestionTextbox;
        private System.Windows.Forms.Label ErrorMessageLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button TruthCorrectButton;
        private System.Windows.Forms.Button FalseCorrectButton;
        private System.Windows.Forms.Button DifferentTemplateButton;
        private System.Windows.Forms.Button SetQuestionButton;
        private System.Windows.Forms.Label CorrectAnsErrorLabel;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}