﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class FB_STU : Form
    {
        //global variables
        string globalstudentID = "";
        int globalCount;
        string globalWorkID = "";
        int globalQuestionCount;
        string correctAnswer = "";
        public FB_STU(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            AnswerTextbox.Clear(); //clears answer textbox

            //values passed from previous form are stored in global variables 
            globalstudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //esatblish connection to the database 
            //Query to fetch question and answer from Questions table
            string getQuestion = ("Select [Question], [Correct Answer] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(getQuestion, con); //data adapter
            DataSet ds = new DataSet(); //data returned
            DataTable dt = new DataTable(); //where data will be stored

            da.Fill(ds, "QuestionAnswer"); //data put in useable format
            dt = ds.Tables["QuestionAnswer"]; //data stored in datatable

            //text at row 0 and index corresponding to questionCount placed in question textbox
            QuestionTextBox.Text = dt.Rows[questionCount][0].ToString();
            //text at row 1 and index corresponding to questionCount stored in correctAnswer variable
            correctAnswer = dt.Rows[questionCount][1].ToString();

            da.Dispose(); //disposes adapter
            ds.Dispose(); //diposes data set
            dt.Dispose(); //diposes data table 
            con.Close(); //closes connection


        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            //stores text from answer textbox  in studentAnswer variable
            string studentAnswer = AnswerTextbox.Text.ToLower(); //answer is converted to lower case

            OleDbConnection con = new OleDbConnection();
            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database 

            if (studentAnswer == "") //if user has not typed an answer out
            {
                MessageBox.Show("Please guess, it might be right", "Guess!"); //output error message
            }
            else //if user has answered question
            {
                //Query to select next quesiton type from Quesitons table
                string fetchQuestion = ("Select [Question Type] from Questions where WorkID='" + globalWorkID + "'");
                OleDbDataAdapter fetchDA = new OleDbDataAdapter(fetchQuestion, con); //data adapter
                DataSet fetchDS = new DataSet(); //returned data
                DataTable fetchDT = new DataTable(); //fills datatable with data

                fetchDA.Fill(fetchDS, "QuestionType"); //data put in useable format
                fetchDT = fetchDS.Tables["QuestionType"]; //datatable filled with data

                if (studentAnswer == correctAnswer) //if users answers matched answer from database
                {
                    MessageBox.Show("Correct", "Well done!"); //ouputs correct message
                    globalCount++; //adds one to score
                    globalQuestionCount++; //adds one to question count
                }
                else
                {
                    MessageBox.Show("Incorrect. The correct answer was: " + correctAnswer, "Better luck next time");
                    globalQuestionCount++;
                }
                //case and switch statment, loads correct from using value from the first index of the datatable
                switch (fetchDT.Rows[globalQuestionCount][0])
                {
                    case "TF":
                        //loads True or False form
                        TF_STU tfTemplate = new TF_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        tfTemplate.Show();
                        break;
                    case "MC":
                        //loads Multiple Choice form
                        MC_STU mcTemplate = new MC_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        mcTemplate.Show();
                        break;
                    case "FC":
                        //loads Flashcard form
                        FC_Question_STU fcTemplate = new FC_Question_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fcTemplate.Show();
                        break;
                    case "OW":
                        //Loads One Word form
                        OW_STU owTemplate = new OW_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        owTemplate.Show();
                        break;
                    case "FB":
                        //Loads Fill in the blank form
                        FB_STU fbTemplate = new FB_STU(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        fbTemplate.Show();
                        break;
                    case "Stop":
                        //Loads View Assignments form as last question has been completed
                        View_Assignments completeAssigments = new View_Assignments(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
                        this.Hide();
                        completeAssigments.Show();
                        break;
                }

                fetchDA.Dispose(); //diposes data adapter
                fetchDS.Dispose(); //diposes data set
                fetchDT.Dispose(); //diposes data table
                con.Close(); //closes connection to database
            }

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalstudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide();
            viewAssignments.Show();

        }

      
    }
}
