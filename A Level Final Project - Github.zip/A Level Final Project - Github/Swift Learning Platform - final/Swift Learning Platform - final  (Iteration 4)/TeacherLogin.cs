﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class TeacherLogin : Form
    { 
      
        public TeacherLogin()
        {
            InitializeComponent(); 
         

            //hiding and disabling the account recovery buttons. 
            AccountRecoverButton.Enabled = false;
            AccountRecoverButton.Visible = false;
        }

        private void Login_Click(object sender, EventArgs e)
        {
            //check to make sure the user has put text into the Username textbox and Password textbox
            if (TeaUsernameTextBox.Text == string.Empty && PasswordText.Text == string.Empty)
            {

                //puts text in Error label so user knows thye need to enter both a username or password
                ErrorMessageLabel.Text = "Please enter a username or password";
            }
            else
            {
                OleDbConnection con = new OleDbConnection();
                //declare dbprovider and dbsource
                string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                con.ConnectionString = dbProvider + dbSource; //connection string allows use to access and query the database
                con.Open();  //connects to the database



                //create and SQL query to pass to the database - All records are selected from students that meet the condition - the username and password. 
                OleDbCommand cmd = new OleDbCommand("Select * from Teachers where TeacherID = '" + TeaUsernameTextBox.Text + "' and Password = '" + PasswordText.Text + "'", con);
                OleDbDataReader reader = cmd.ExecuteReader(); //all the records that are returned are placed in a reader
                if (reader.HasRows)
                {
                    //if reader has rows, it means data has been returned and the inputted username and password match entries in the database
                    //Teacher Homepage form is loaded, the TeacherID is passed to the next form.
                    string teacherID = TeaUsernameTextBox.Text.ToString(); //stores username inputted
                    Teacher_Homepage teaHome = new Teacher_Homepage(teacherID); 
                    this.Hide();
                    teaHome.Show();
                }
                else
                {
                    //if the username or password is incorrect...
                    TeaUsernameTextBox.Text = String.Empty; //we empty both textboxes
                    PasswordText.Text = String.Empty;
                    AccountRecoverButton.Enabled = true; //showe and enable the account recovery button
                    AccountRecoverButton.Visible = true;
                    ErrorMessageLabel.Text = "Incorrect Username or Password"; //display an error message in thr error label 

                }
                reader.Close();
                cmd.Dispose();
                con.Close();

            }

        }

        private void AccountRecoverButton_Click(object sender, EventArgs e)
        {
            //stuTeaIndicator is delcared and passed to Account Recovery form
            string stuTeaIndicator = "TEA"; //the value of the variable is used to decide what table will
                                            //be queried in the Account Recovery form
            //loads account revovery form
            Account_Recovery accountRecovery = new Account_Recovery(stuTeaIndicator);
            accountRecovery.Show();
            this.Hide();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            //exits program
            this.Hide();
        }

        private void AccountCreateButton_Click(object sender, EventArgs e)
        {
            //loads account creaiton form, hides this form
            AccountCreate accountCreate = new AccountCreate();
            this.Hide();
            accountCreate.Show();
        }

        private void HomepageButton_Click(object sender, EventArgs e)
        {
            //loads welcome screen. hides this form
            WelcomeScreen homepage = new WelcomeScreen();
            this.Hide();
            homepage.Show();
        }
    }
}
