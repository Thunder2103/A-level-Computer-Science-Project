﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Teacher_Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwfitLabel = new System.Windows.Forms.Label();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.TextLabel = new System.Windows.Forms.Label();
            this.NotificationButton = new System.Windows.Forms.Button();
            this.ViewClassesButton = new System.Windows.Forms.Button();
            this.CreateClassButton = new System.Windows.Forms.Button();
            this.ResultsButton = new System.Windows.Forms.Button();
            this.SetAssignButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SignOutBUtton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwfitLabel
            // 
            this.SwfitLabel.AutoSize = true;
            this.SwfitLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwfitLabel.Location = new System.Drawing.Point(12, 9);
            this.SwfitLabel.Name = "SwfitLabel";
            this.SwfitLabel.Size = new System.Drawing.Size(58, 30);
            this.SwfitLabel.TabIndex = 1;
            this.SwfitLabel.Text = "Swift";
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WelcomeLabel.Location = new System.Drawing.Point(281, 52);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(238, 30);
            this.WelcomeLabel.TabIndex = 3;
            this.WelcomeLabel.Text = "Welcome back teacher...";
            // 
            // TextLabel
            // 
            this.TextLabel.AutoSize = true;
            this.TextLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TextLabel.Location = new System.Drawing.Point(281, 82);
            this.TextLabel.Name = "TextLabel";
            this.TextLabel.Size = new System.Drawing.Size(236, 30);
            this.TextLabel.TabIndex = 5;
            this.TextLabel.Text = "What will you do today?";
            // 
            // NotificationButton
            // 
            this.NotificationButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NotificationButton.Location = new System.Drawing.Point(609, 70);
            this.NotificationButton.Name = "NotificationButton";
            this.NotificationButton.Size = new System.Drawing.Size(109, 42);
            this.NotificationButton.TabIndex = 12;
            this.NotificationButton.Text = "Notfications";
            this.NotificationButton.UseVisualStyleBackColor = true;
            // 
            // ViewClassesButton
            // 
            this.ViewClassesButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ViewClassesButton.Location = new System.Drawing.Point(236, 115);
            this.ViewClassesButton.Name = "ViewClassesButton";
            this.ViewClassesButton.Size = new System.Drawing.Size(129, 44);
            this.ViewClassesButton.TabIndex = 13;
            this.ViewClassesButton.Text = "View Classes";
            this.ViewClassesButton.UseVisualStyleBackColor = true;
            this.ViewClassesButton.Click += new System.EventHandler(this.ViewClassesButton_Click);
            // 
            // CreateClassButton
            // 
            this.CreateClassButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CreateClassButton.Location = new System.Drawing.Point(425, 115);
            this.CreateClassButton.Name = "CreateClassButton";
            this.CreateClassButton.Size = new System.Drawing.Size(129, 44);
            this.CreateClassButton.TabIndex = 14;
            this.CreateClassButton.Text = "Create Class";
            this.CreateClassButton.UseVisualStyleBackColor = true;
            this.CreateClassButton.Click += new System.EventHandler(this.CreateClassButton_Click);
            // 
            // ResultsButton
            // 
            this.ResultsButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ResultsButton.Location = new System.Drawing.Point(218, 189);
            this.ResultsButton.Name = "ResultsButton";
            this.ResultsButton.Size = new System.Drawing.Size(147, 44);
            this.ResultsButton.TabIndex = 15;
            this.ResultsButton.Text = "Work results";
            this.ResultsButton.UseVisualStyleBackColor = true;
            this.ResultsButton.Click += new System.EventHandler(this.ResultsButton_Click);
            // 
            // SetAssignButton
            // 
            this.SetAssignButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetAssignButton.Location = new System.Drawing.Point(425, 189);
            this.SetAssignButton.Name = "SetAssignButton";
            this.SetAssignButton.Size = new System.Drawing.Size(147, 44);
            this.SetAssignButton.TabIndex = 16;
            this.SetAssignButton.Text = "Set Assignments";
            this.SetAssignButton.UseVisualStyleBackColor = true;
            this.SetAssignButton.Click += new System.EventHandler(this.SetAssignButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.ExitButton.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(12, 401);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(83, 37);
            this.ExitButton.TabIndex = 17;
            this.ExitButton.Text = "<- Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // SignOutBUtton
            // 
            this.SignOutBUtton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SignOutBUtton.Location = new System.Drawing.Point(652, 401);
            this.SignOutBUtton.Name = "SignOutBUtton";
            this.SignOutBUtton.Size = new System.Drawing.Size(136, 37);
            this.SignOutBUtton.TabIndex = 18;
            this.SignOutBUtton.Text = "Sign Out ->";
            this.SignOutBUtton.UseVisualStyleBackColor = true;
            this.SignOutBUtton.Click += new System.EventHandler(this.SignOutBUtton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 7);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // Teacher_Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.SignOutBUtton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SetAssignButton);
            this.Controls.Add(this.ResultsButton);
            this.Controls.Add(this.CreateClassButton);
            this.Controls.Add(this.ViewClassesButton);
            this.Controls.Add(this.NotificationButton);
            this.Controls.Add(this.TextLabel);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.SwfitLabel);
            this.Name = "Teacher_Homepage";
            this.Text = "Teacher_Homepage";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwfitLabel;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Label TextLabel;
        private System.Windows.Forms.Button NotificationButton;
        private System.Windows.Forms.Button ViewClassesButton;
        private System.Windows.Forms.Button CreateClassButton;
        private System.Windows.Forms.Button ResultsButton;
        private System.Windows.Forms.Button SetAssignButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button SignOutBUtton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}