﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using System.Data.OleDb;
using System.Text.RegularExpressions;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class PasswordRecovery : Form
    {
        //global variables
        string resetCodeGlobal = "";
        string usernameGlobal = "";
        public PasswordRecovery(string resetCode, string username)
        {
            InitializeComponent();
            resetCodeGlobal = resetCode; //store passed parameters in global variables so they can be used everywhere in program
            usernameGlobal = username;
        }

        private void SignInButton_Click(object sender, EventArgs e)
        {
            //loads WelcomeScreen form
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            this.Hide();
            welcomeScreen.Show();
        }

        private void NoEmailButton_Click(object sender, EventArgs e)
        {
            //Outputs message to the user
            MessageBox.Show("please check your spam or junk folder"); 
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            //if any of the textboxes are empty
            if (ResetCodeTextbox.Text == string.Empty || NewPassTextbox.Text == string.Empty 
                || ConfirmPassTextbox.Text == string.Empty)
            {
                ErrorMessageLabel.Text = "Please fill in all the boxes"; //error message displayed
            }
            //if inputted reset code doesn't match one sent by email
            else if (ResetCodeTextbox.Text != resetCodeGlobal) 
            {
                ErrorMessageLabel.Text = "Reset code does not match one sent"; //error message is displayed
            }
            else
            {
                //if the passwords in both textboxes don't match
                if (NewPassTextbox.Text != ConfirmPassTextbox.Text) 
                {
                    ErrorMessageLabel.Text = "Password boxes do not match"; //outputs error message 
                }
                else
                {
                    bool containsNum = NewPassTextbox.Text.Any(char.IsNumber); //we check if the password contains at least one number
                    bool containsUppercase = NewPassTextbox.Text.Any(char.IsUpper); //we check if the password as at least one upper case letter
                    Regex rgx = new Regex("[^A-Za-z0-9]"); //a regex expression is a character set. The charcter set contains special characters. 
                   
                    bool containsSpecial = rgx.IsMatch(NewPassTextbox.Text); //we check if the all characters in the password match the character set.
                    if (containsUppercase == false) //if there are no uppercase letters
                    {
                        ErrorMessageLabel.Text = "At least one capital is needed"; //output error message
                        NewPassTextbox.Clear(); //clear password textboxes
                        ConfirmPassTextbox.Clear();
                    }
                    else if (containsNum == false) //if password has no numbers
                    {
                        ErrorMessageLabel.Text = "At least one number is needed"; //output error message
                        NewPassTextbox.Clear(); //clears password textboxes
                        ConfirmPassTextbox.Clear();
                    }
                    else if (containsSpecial == false) //if there are no special charcters
                    {
                        ErrorMessageLabel.Text = "At least one special character needed"; //output error message 
                        NewPassTextbox.Clear(); //clear password textboxes
                        ConfirmPassTextbox.Clear();
                    }
                    else    //password meets all parameters  
                    {
                        //query to insert the password into the correct table...
                        string teaStuCheck = usernameGlobal.Substring(0, 3); //we get the first three characters from the username and store them in a variable
                        OleDbConnection con = new OleDbConnection();
                        string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
                        string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

                        con.ConnectionString = dbProvider + dbSource;

                        if (teaStuCheck == "STU") //if the first three characters of the username are STU
                        { 
                            //we use the student table. 
                            con.Open(); //connects to database

                            //query to check if the new password is the same as the old
                            OleDbCommand checkExistingPassStu = new OleDbCommand("Select * from Students Where Password = '" + NewPassTextbox + "'", con);
                            OleDbDataReader checkReaderStu = checkExistingPassStu.ExecuteReader();


                            if (checkReaderStu.HasRows) //if the new password is the same as the old
                            {
                                ErrorMessageLabel.Text = "New Password can't match the old"; //ouput error message 
                                checkReaderStu.Close();
                                con.Close();

                            }

                            else //if the new password is different
                            {
                                checkReaderStu.Close();

                                //query to update the users password. 
                                OleDbCommand updatePassStuCmd = new OleDbCommand("Update Students Set [Password] ='" + NewPassTextbox.Text + "' Where StudentID='" + usernameGlobal + "'", con); 

                                OleDbDataReader updatePassReader = updatePassStuCmd.ExecuteReader();
                                con.Close();
                                WelcomeScreen homepage = new WelcomeScreen(); //returns user to homescreen
                                this.Hide();
                                homepage.Show();
                            }


                        }
                        else //if the first three characters of the username are TEA
                        {
                            con.Open(); //establish connection to database 

                            //we use the Teachers table

                            //query to check if new password matched the old
                            OleDbCommand checkExistingPassTea = new OleDbCommand("Select * from Teachers Where TeacherID ='" + usernameGlobal + "' and Password = '" + NewPassTextbox.Text + "'", con);
                            OleDbDataReader checkReaderTea = checkExistingPassTea.ExecuteReader();


                            if (checkReaderTea.HasRows) //if new password matches the old
                            {
                                ErrorMessageLabel.Text = "New Password can't match the old"; //output error message
                                checkReaderTea.Close();
                                con.Close();

                            }

                            else //if the new password is different
                            {
                                checkReaderTea.Close(); 

                                //query to replace old users password with the new
                                OleDbCommand updatePassStuCmd = new OleDbCommand("UPDATE Teachers Set [Password] = '" + NewPassTextbox.Text + 
                                    "'WHERE TeacherID ='" + usernameGlobal + "'", con);

                                OleDbDataReader reader = updatePassStuCmd.ExecuteReader();
                                con.Close();
                                WelcomeScreen welcomeScreen = new WelcomeScreen(); //returns user to the welcome screen
                                this.Hide();
                                welcomeScreen.Show();
                            }

                        }







                    }
                }
            }
        }

    }
}
