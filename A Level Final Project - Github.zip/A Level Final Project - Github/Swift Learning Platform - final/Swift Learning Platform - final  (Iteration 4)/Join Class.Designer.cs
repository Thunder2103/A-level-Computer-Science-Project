﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Join_Class
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InfoLabel = new System.Windows.Forms.Label();
            this.JoinClassInfoLabel = new System.Windows.Forms.Label();
            this.ClassCodeTextBox = new System.Windows.Forms.TextBox();
            this.JoinClassButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.ConfirmationLabel = new System.Windows.Forms.Label();
            this.MainScreenButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.NameLogo = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(290, 53);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(205, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Joining a new class...";
            // 
            // JoinClassInfoLabel
            // 
            this.JoinClassInfoLabel.AutoSize = true;
            this.JoinClassInfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.JoinClassInfoLabel.Location = new System.Drawing.Point(159, 83);
            this.JoinClassInfoLabel.Name = "JoinClassInfoLabel";
            this.JoinClassInfoLabel.Size = new System.Drawing.Size(437, 30);
            this.JoinClassInfoLabel.TabIndex = 5;
            this.JoinClassInfoLabel.Text = "Type in the class code then press the button...";
            // 
            // ClassCodeTextBox
            // 
            this.ClassCodeTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClassCodeTextBox.Location = new System.Drawing.Point(159, 138);
            this.ClassCodeTextBox.Name = "ClassCodeTextBox";
            this.ClassCodeTextBox.Size = new System.Drawing.Size(313, 35);
            this.ClassCodeTextBox.TabIndex = 6;
            // 
            // JoinClassButton
            // 
            this.JoinClassButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.JoinClassButton.Location = new System.Drawing.Point(489, 138);
            this.JoinClassButton.Name = "JoinClassButton";
            this.JoinClassButton.Size = new System.Drawing.Size(107, 35);
            this.JoinClassButton.TabIndex = 7;
            this.JoinClassButton.Text = "Join Class";
            this.JoinClassButton.UseVisualStyleBackColor = true;
            this.JoinClassButton.Click += new System.EventHandler(this.JoinClassButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(159, 176);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorLabel.TabIndex = 9;
            this.ErrorLabel.Text = "Filler Text";
            // 
            // ConfirmationLabel
            // 
            this.ConfirmationLabel.AutoSize = true;
            this.ConfirmationLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ConfirmationLabel.Location = new System.Drawing.Point(159, 221);
            this.ConfirmationLabel.Name = "ConfirmationLabel";
            this.ConfirmationLabel.Size = new System.Drawing.Size(99, 30);
            this.ConfirmationLabel.TabIndex = 10;
            this.ConfirmationLabel.Text = "Filler Text";
            // 
            // MainScreenButton
            // 
            this.MainScreenButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainScreenButton.Location = new System.Drawing.Point(12, 396);
            this.MainScreenButton.Name = "MainScreenButton";
            this.MainScreenButton.Size = new System.Drawing.Size(165, 42);
            this.MainScreenButton.TabIndex = 11;
            this.MainScreenButton.Text = "<- Main Screen";
            this.MainScreenButton.UseVisualStyleBackColor = true;
            this.MainScreenButton.Click += new System.EventHandler(this.MainScreenButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(700, 396);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(88, 42);
            this.ExitButton.TabIndex = 12;
            this.ExitButton.Text = "Exit ->";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 2;
            this.NameLogo.Text = "Swift";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // Join_Class
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.MainScreenButton);
            this.Controls.Add(this.ConfirmationLabel);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.JoinClassButton);
            this.Controls.Add(this.ClassCodeTextBox);
            this.Controls.Add(this.JoinClassInfoLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "Join_Class";
            this.Text = "Join a Class";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label JoinClassInfoLabel;
        private System.Windows.Forms.TextBox ClassCodeTextBox;
        private System.Windows.Forms.Button JoinClassButton;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Label ConfirmationLabel;
        private System.Windows.Forms.Button MainScreenButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}