﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class ViewingClasses : Form
    {
        //global variables
        string globalTeacherID; 
        public ViewingClasses(string teacherID)
        {
            InitializeComponent();
            
            //stores teacherID passed from Teacher Homepage in global variables
            globalTeacherID = teacherID;

            //adds text to richtextbox and makes it read only 
            DisplayClassesTextbox.Text = "Your classes:";
            DisplayClassesTextbox.ReadOnly = true;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //established connection to the database


            DataSet ds = new DataSet(); //dataset is the data returned
            DataTable dt = new DataTable(); //datatable is where the data will be stored

            //query to select all ClassID's that have the TeacherID from Classes table
            string cmd = ("Select ClassID, NumStudents from Classes where TeacherID =  '" + teacherID + "'");


            OleDbDataAdapter da = new OleDbDataAdapter(cmd, con); //data adapter returnd data in format we can use


            da.Fill(ds, "ClassInfo"); //we fill the data adapter with the data returned in the dataset
            dt = ds.Tables["ClassInfo"]; //we fill the datatable with the newly formatted data
            int rowCount = (dt.Rows.Count) - 1; //variable to store number of rows in the datable 

            for (int i = 0; i <= rowCount; i++) //for loop iterates through the datatable until the end
            {
                int j = 0; 
                //places the data at ech index of the datatable into the richtextbox
                DisplayClassesTextbox.Text += Environment.NewLine + "Class Number: " + dt.Rows[i][j].ToString() + "." + " " +
                    "Number of students: " + dt.Rows[i][j + 1].ToString() + ".";

            }
            da.Dispose(); //disposes data adpater
            ds.Dispose(); //disposes data set
            dt.Dispose(); //disposes data table 
            con.Close(); //closes connection 



        }

        private void HomepageButton_Click(object sender, EventArgs e)
        {
            //loads teachers homepage form. 
            Teacher_Homepage homePage = new Teacher_Homepage(globalTeacherID);
            this.Hide();
            homePage.Show(); 
        }

        private void CreateClassButton_Click(object sender, EventArgs e)
        { 
            //loads create a class form
            Create_a_Class createClass = new Create_a_Class(globalTeacherID);
            this.Hide(); 
            createClass.Show(); 
        }

        private void WorkResultsButton_Click(object sender, EventArgs e)
        {
            //Load choose assignment result form
            Choose_Result workResults = new Choose_Result(globalTeacherID);
            this.Hide();
            workResults.Show();
        }
    }
}
