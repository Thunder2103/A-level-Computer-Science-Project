﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class StudentLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SwiftLabel = new System.Windows.Forms.Label();
            this.StudentWelcome = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.Label();
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.UsernameInput = new System.Windows.Forms.TextBox();
            this.StudentPasswordLabel = new System.Windows.Forms.Label();
            this.StudentPasswordInput = new System.Windows.Forms.TextBox();
            this.StudentLoginPress = new System.Windows.Forms.Button();
            this.AccountRecoverButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.HomepageButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.AccountCreateButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SwiftLabel
            // 
            this.SwiftLabel.AutoSize = true;
            this.SwiftLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SwiftLabel.Location = new System.Drawing.Point(12, 9);
            this.SwiftLabel.Name = "SwiftLabel";
            this.SwiftLabel.Size = new System.Drawing.Size(58, 30);
            this.SwiftLabel.TabIndex = 2;
            this.SwiftLabel.Text = "Swift";
            // 
            // StudentWelcome
            // 
            this.StudentWelcome.AutoSize = true;
            this.StudentWelcome.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StudentWelcome.Location = new System.Drawing.Point(294, 65);
            this.StudentWelcome.Name = "StudentWelcome";
            this.StudentWelcome.Size = new System.Drawing.Size(191, 30);
            this.StudentWelcome.TabIndex = 4;
            this.StudentWelcome.Text = "Welcome Student...";
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Info.Location = new System.Drawing.Point(167, 95);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(469, 30);
            this.Info.TabIndex = 5;
            this.Info.Text = "To sign in please enter a Username and Password";
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserNameLabel.Location = new System.Drawing.Point(167, 177);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(111, 30);
            this.UserNameLabel.TabIndex = 6;
            this.UserNameLabel.Text = "Username:";
            // 
            // UsernameInput
            // 
            this.UsernameInput.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameInput.Location = new System.Drawing.Point(284, 177);
            this.UsernameInput.Name = "UsernameInput";
            this.UsernameInput.Size = new System.Drawing.Size(352, 35);
            this.UsernameInput.TabIndex = 7;
            // 
            // StudentPasswordLabel
            // 
            this.StudentPasswordLabel.AutoSize = true;
            this.StudentPasswordLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StudentPasswordLabel.Location = new System.Drawing.Point(167, 236);
            this.StudentPasswordLabel.Name = "StudentPasswordLabel";
            this.StudentPasswordLabel.Size = new System.Drawing.Size(104, 30);
            this.StudentPasswordLabel.TabIndex = 8;
            this.StudentPasswordLabel.Text = "Password:";
            // 
            // StudentPasswordInput
            // 
            this.StudentPasswordInput.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StudentPasswordInput.Location = new System.Drawing.Point(284, 231);
            this.StudentPasswordInput.Name = "StudentPasswordInput";
            this.StudentPasswordInput.Size = new System.Drawing.Size(352, 35);
            this.StudentPasswordInput.TabIndex = 9;
            // 
            // StudentLoginPress
            // 
            this.StudentLoginPress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StudentLoginPress.Location = new System.Drawing.Point(284, 272);
            this.StudentLoginPress.Name = "StudentLoginPress";
            this.StudentLoginPress.Size = new System.Drawing.Size(138, 46);
            this.StudentLoginPress.TabIndex = 10;
            this.StudentLoginPress.Text = "Login";
            this.StudentLoginPress.UseVisualStyleBackColor = true;
            this.StudentLoginPress.Click += new System.EventHandler(this.StudentLoginPress_Click);
            // 
            // AccountRecoverButton
            // 
            this.AccountRecoverButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountRecoverButton.Location = new System.Drawing.Point(506, 272);
            this.AccountRecoverButton.Name = "AccountRecoverButton";
            this.AccountRecoverButton.Size = new System.Drawing.Size(130, 47);
            this.AccountRecoverButton.TabIndex = 11;
            this.AccountRecoverButton.Text = "Can\'t sign in?\r\n";
            this.AccountRecoverButton.UseVisualStyleBackColor = true;
            this.AccountRecoverButton.Click += new System.EventHandler(this.AccountRecoverButton_Click);
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit.Location = new System.Drawing.Point(12, 389);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(84, 49);
            this.Exit.TabIndex = 12;
            this.Exit.Text = "<- Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // HomepageButton
            // 
            this.HomepageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HomepageButton.Location = new System.Drawing.Point(649, 389);
            this.HomepageButton.Name = "HomepageButton";
            this.HomepageButton.Size = new System.Drawing.Size(139, 49);
            this.HomepageButton.TabIndex = 13;
            this.HomepageButton.Text = "Homepage ->";
            this.HomepageButton.UseVisualStyleBackColor = true;
            this.HomepageButton.Click += new System.EventHandler(this.HomepageButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(195, 397);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 30);
            this.label1.TabIndex = 14;
            this.label1.Text = "Don\'t have an account?:";
            // 
            // AccountCreateButton
            // 
            this.AccountCreateButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountCreateButton.Location = new System.Drawing.Point(438, 396);
            this.AccountCreateButton.Name = "AccountCreateButton";
            this.AccountCreateButton.Size = new System.Drawing.Size(131, 36);
            this.AccountCreateButton.TabIndex = 15;
            this.AccountCreateButton.Text = "Create One";
            this.AccountCreateButton.UseVisualStyleBackColor = true;
            this.AccountCreateButton.Click += new System.EventHandler(this.AccountCreateButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.BackColor = System.Drawing.Color.White;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(284, 330);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(106, 30);
            this.ErrorLabel.TabIndex = 16;
            this.ErrorLabel.Text = "ErrorLabel";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // StudentLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.AccountCreateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HomepageButton);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.AccountRecoverButton);
            this.Controls.Add(this.StudentLoginPress);
            this.Controls.Add(this.StudentPasswordInput);
            this.Controls.Add(this.StudentPasswordLabel);
            this.Controls.Add(this.UsernameInput);
            this.Controls.Add(this.UserNameLabel);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.StudentWelcome);
            this.Controls.Add(this.SwiftLabel);
            this.Name = "StudentLogin";
            this.Text = "StudentLogin";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SwiftLabel;
        private System.Windows.Forms.Label StudentWelcome;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.TextBox UsernameInput;
        private System.Windows.Forms.Label StudentPasswordLabel;
        private System.Windows.Forms.TextBox StudentPasswordInput;
        private System.Windows.Forms.Button StudentLoginPress;
        private System.Windows.Forms.Button AccountRecoverButton;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button HomepageButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button sad;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Button AccountCreateButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}