﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class View_Assignments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.SelectInfoLabel = new System.Windows.Forms.Label();
            this.SelectAssignmentDropBox = new System.Windows.Forms.ComboBox();
            this.DisplayFinishedAssignments = new System.Windows.Forms.RichTextBox();
            this.GetWorkButton = new System.Windows.Forms.Button();
            this.RefreshButton = new System.Windows.Forms.Button();
            this.FinishWorkButton = new System.Windows.Forms.Button();
            this.MainScreenButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 2;
            this.NameLogo.Text = "Swift";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(231, 55);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(335, 30);
            this.InfoLabel.TabIndex = 4;
            this.InfoLabel.Text = "Here are your active assignments...";
            // 
            // SelectInfoLabel
            // 
            this.SelectInfoLabel.AutoSize = true;
            this.SelectInfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectInfoLabel.Location = new System.Drawing.Point(163, 85);
            this.SelectInfoLabel.Name = "SelectInfoLabel";
            this.SelectInfoLabel.Size = new System.Drawing.Size(455, 30);
            this.SelectInfoLabel.TabIndex = 8;
            this.SelectInfoLabel.Text = "Choose an assignment from the drop down box";
            // 
            // SelectAssignmentDropBox
            // 
            this.SelectAssignmentDropBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectAssignmentDropBox.FormattingEnabled = true;
            this.SelectAssignmentDropBox.Location = new System.Drawing.Point(231, 140);
            this.SelectAssignmentDropBox.Name = "SelectAssignmentDropBox";
            this.SelectAssignmentDropBox.Size = new System.Drawing.Size(335, 29);
            this.SelectAssignmentDropBox.TabIndex = 9;
            // 
            // DisplayFinishedAssignments
            // 
            this.DisplayFinishedAssignments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DisplayFinishedAssignments.Location = new System.Drawing.Point(231, 197);
            this.DisplayFinishedAssignments.Name = "DisplayFinishedAssignments";
            this.DisplayFinishedAssignments.Size = new System.Drawing.Size(335, 155);
            this.DisplayFinishedAssignments.TabIndex = 10;
            this.DisplayFinishedAssignments.Text = "Results:";
            // 
            // GetWorkButton
            // 
            this.GetWorkButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.GetWorkButton.Location = new System.Drawing.Point(572, 223);
            this.GetWorkButton.Name = "GetWorkButton";
            this.GetWorkButton.Size = new System.Drawing.Size(107, 44);
            this.GetWorkButton.TabIndex = 11;
            this.GetWorkButton.Text = "Lets\'s Go";
            this.GetWorkButton.UseVisualStyleBackColor = true;
            this.GetWorkButton.Click += new System.EventHandler(this.GetWorkButton_Click);
            // 
            // RefreshButton
            // 
            this.RefreshButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RefreshButton.Location = new System.Drawing.Point(572, 273);
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(107, 47);
            this.RefreshButton.TabIndex = 12;
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.UseVisualStyleBackColor = true;
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // FinishWorkButton
            // 
            this.FinishWorkButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FinishWorkButton.Location = new System.Drawing.Point(681, 391);
            this.FinishWorkButton.Name = "FinishWorkButton";
            this.FinishWorkButton.Size = new System.Drawing.Size(107, 47);
            this.FinishWorkButton.TabIndex = 13;
            this.FinishWorkButton.Text = "Finish Work";
            this.FinishWorkButton.UseVisualStyleBackColor = true;
            this.FinishWorkButton.Click += new System.EventHandler(this.FinishWorkButton_Click);
            // 
            // MainScreenButton
            // 
            this.MainScreenButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MainScreenButton.Location = new System.Drawing.Point(12, 397);
            this.MainScreenButton.Name = "MainScreenButton";
            this.MainScreenButton.Size = new System.Drawing.Size(138, 41);
            this.MainScreenButton.TabIndex = 14;
            this.MainScreenButton.Text = "<- Main Screen";
            this.MainScreenButton.UseVisualStyleBackColor = true;
            this.MainScreenButton.Click += new System.EventHandler(this.MainScreenButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // View_Assignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.MainScreenButton);
            this.Controls.Add(this.FinishWorkButton);
            this.Controls.Add(this.RefreshButton);
            this.Controls.Add(this.GetWorkButton);
            this.Controls.Add(this.DisplayFinishedAssignments);
            this.Controls.Add(this.SelectAssignmentDropBox);
            this.Controls.Add(this.SelectInfoLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "View_Assignments";
            this.Text = "View Assignments";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label SelectInfoLabel;
        private System.Windows.Forms.ComboBox SelectAssignmentDropBox;
        private System.Windows.Forms.RichTextBox DisplayFinishedAssignments;
        private System.Windows.Forms.Button GetWorkButton;
        private System.Windows.Forms.Button RefreshButton;
        private System.Windows.Forms.Button FinishWorkButton;
        private System.Windows.Forms.Button MainScreenButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}