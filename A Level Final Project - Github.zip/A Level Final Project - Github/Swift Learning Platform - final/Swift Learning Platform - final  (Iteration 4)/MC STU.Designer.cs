﻿namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class MC_STU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLogo = new System.Windows.Forms.Label();
            this.MultChoiceLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.QuestionTextBox = new System.Windows.Forms.TextBox();
            this.Answer1TextBox = new System.Windows.Forms.TextBox();
            this.Answer1Button = new System.Windows.Forms.Button();
            this.Answer2Textbox = new System.Windows.Forms.TextBox();
            this.Answer2Button = new System.Windows.Forms.Button();
            this.Answer3Textbox = new System.Windows.Forms.TextBox();
            this.Answer3Button = new System.Windows.Forms.Button();
            this.Answer4Textbox = new System.Windows.Forms.TextBox();
            this.Answer4Button = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.ContinueButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLogo
            // 
            this.NameLogo.AutoSize = true;
            this.NameLogo.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLogo.Location = new System.Drawing.Point(12, 9);
            this.NameLogo.Name = "NameLogo";
            this.NameLogo.Size = new System.Drawing.Size(58, 30);
            this.NameLogo.TabIndex = 4;
            this.NameLogo.Text = "Swift";
            // 
            // MultChoiceLabel
            // 
            this.MultChoiceLabel.AutoSize = true;
            this.MultChoiceLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MultChoiceLabel.Location = new System.Drawing.Point(292, 55);
            this.MultChoiceLabel.Name = "MultChoiceLabel";
            this.MultChoiceLabel.Size = new System.Drawing.Size(173, 30);
            this.MultChoiceLabel.TabIndex = 6;
            this.MultChoiceLabel.Text = "Multiple Choice...";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(229, 85);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(278, 30);
            this.InfoLabel.TabIndex = 7;
            this.InfoLabel.Text = "Click on the correct answer...";
            // 
            // QuestionTextBox
            // 
            this.QuestionTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextBox.Location = new System.Drawing.Point(54, 118);
            this.QuestionTextBox.Name = "QuestionTextBox";
            this.QuestionTextBox.ReadOnly = true;
            this.QuestionTextBox.Size = new System.Drawing.Size(702, 35);
            this.QuestionTextBox.TabIndex = 8;
            this.QuestionTextBox.Text = "Question Will Be Here...";
            // 
            // Answer1TextBox
            // 
            this.Answer1TextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer1TextBox.Location = new System.Drawing.Point(54, 159);
            this.Answer1TextBox.Name = "Answer1TextBox";
            this.Answer1TextBox.ReadOnly = true;
            this.Answer1TextBox.Size = new System.Drawing.Size(624, 29);
            this.Answer1TextBox.TabIndex = 13;
            this.Answer1TextBox.Text = "Answer Here";
            // 
            // Answer1Button
            // 
            this.Answer1Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer1Button.Location = new System.Drawing.Point(694, 159);
            this.Answer1Button.Name = "Answer1Button";
            this.Answer1Button.Size = new System.Drawing.Size(62, 29);
            this.Answer1Button.TabIndex = 17;
            this.Answer1Button.Text = "1.";
            this.Answer1Button.UseVisualStyleBackColor = true;
            this.Answer1Button.Click += new System.EventHandler(this.Answer1Button_Click);
            // 
            // Answer2Textbox
            // 
            this.Answer2Textbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer2Textbox.Location = new System.Drawing.Point(54, 194);
            this.Answer2Textbox.Name = "Answer2Textbox";
            this.Answer2Textbox.ReadOnly = true;
            this.Answer2Textbox.Size = new System.Drawing.Size(624, 29);
            this.Answer2Textbox.TabIndex = 18;
            this.Answer2Textbox.Text = "Answer Here";
            // 
            // Answer2Button
            // 
            this.Answer2Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer2Button.Location = new System.Drawing.Point(694, 194);
            this.Answer2Button.Name = "Answer2Button";
            this.Answer2Button.Size = new System.Drawing.Size(62, 29);
            this.Answer2Button.TabIndex = 19;
            this.Answer2Button.Text = "2.";
            this.Answer2Button.UseVisualStyleBackColor = true;
            this.Answer2Button.Click += new System.EventHandler(this.Answer2Button_Click);
            // 
            // Answer3Textbox
            // 
            this.Answer3Textbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer3Textbox.Location = new System.Drawing.Point(54, 229);
            this.Answer3Textbox.Name = "Answer3Textbox";
            this.Answer3Textbox.ReadOnly = true;
            this.Answer3Textbox.Size = new System.Drawing.Size(624, 29);
            this.Answer3Textbox.TabIndex = 20;
            this.Answer3Textbox.Text = "Answer Here";
            // 
            // Answer3Button
            // 
            this.Answer3Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer3Button.Location = new System.Drawing.Point(694, 228);
            this.Answer3Button.Name = "Answer3Button";
            this.Answer3Button.Size = new System.Drawing.Size(62, 29);
            this.Answer3Button.TabIndex = 21;
            this.Answer3Button.Text = "3.";
            this.Answer3Button.UseVisualStyleBackColor = true;
            this.Answer3Button.Click += new System.EventHandler(this.Answer3Button_Click);
            // 
            // Answer4Textbox
            // 
            this.Answer4Textbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer4Textbox.Location = new System.Drawing.Point(54, 264);
            this.Answer4Textbox.Name = "Answer4Textbox";
            this.Answer4Textbox.ReadOnly = true;
            this.Answer4Textbox.Size = new System.Drawing.Size(624, 29);
            this.Answer4Textbox.TabIndex = 22;
            this.Answer4Textbox.Text = "Answer Here";
            // 
            // Answer4Button
            // 
            this.Answer4Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer4Button.Location = new System.Drawing.Point(694, 264);
            this.Answer4Button.Name = "Answer4Button";
            this.Answer4Button.Size = new System.Drawing.Size(62, 29);
            this.Answer4Button.TabIndex = 23;
            this.Answer4Button.Text = "4.";
            this.Answer4Button.UseVisualStyleBackColor = true;
            this.Answer4Button.Click += new System.EventHandler(this.Answer4Button_Click);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 398);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(160, 40);
            this.BackButton.TabIndex = 24;
            this.BackButton.Text = "<- Stop Assignment";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ContinueButton
            // 
            this.ContinueButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButton.Location = new System.Drawing.Point(628, 398);
            this.ContinueButton.Name = "ContinueButton";
            this.ContinueButton.Size = new System.Drawing.Size(160, 40);
            this.ContinueButton.TabIndex = 25;
            this.ContinueButton.Text = "Continue ->";
            this.ContinueButton.UseVisualStyleBackColor = true;
            this.ContinueButton.Click += new System.EventHandler(this.ContinueButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // MC_STU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.ContinueButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.Answer4Button);
            this.Controls.Add(this.Answer4Textbox);
            this.Controls.Add(this.Answer3Button);
            this.Controls.Add(this.Answer3Textbox);
            this.Controls.Add(this.Answer2Button);
            this.Controls.Add(this.Answer2Textbox);
            this.Controls.Add(this.Answer1Button);
            this.Controls.Add(this.Answer1TextBox);
            this.Controls.Add(this.QuestionTextBox);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.MultChoiceLabel);
            this.Controls.Add(this.NameLogo);
            this.Name = "MC_STU";
            this.Text = "Multiple Choice";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLogo;
        private System.Windows.Forms.Label MultChoiceLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.TextBox QuestionTextBox;
        private System.Windows.Forms.TextBox Answer1TextBox;
        private System.Windows.Forms.Button Answer1Button;
        private System.Windows.Forms.TextBox Answer2Textbox;
        private System.Windows.Forms.Button Answer2Button;
        private System.Windows.Forms.TextBox Answer3Textbox;
        private System.Windows.Forms.Button Answer3Button;
        private System.Windows.Forms.TextBox Answer4Textbox;
        private System.Windows.Forms.Button Answer4Button;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ContinueButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}