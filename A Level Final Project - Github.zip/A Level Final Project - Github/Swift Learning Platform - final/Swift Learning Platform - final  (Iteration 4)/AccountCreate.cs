﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.Net;
using System.Net.Mail;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class AccountCreate : Form
    { 
        //global variables
        string teaStuIndicator = "";
        string emailaddress = "";
        public AccountCreate()
        {
            InitializeComponent(); 

            //hiding password buttons and the create account button
            PasswordLabel.Visible = false;
            CreatePassTextBox.Visible = false;
            ConfirmPassLabel.Visible = false;
            ConfirmPassTextbox.Visible = false;
            CreateAccountButton.Visible = false;
            PassInfoLabel.Visible = false;
        }

        private void StudentButton_Click(object sender, EventArgs e)
        {
            teaStuIndicator = "STU"; //STU stored in teaStuIndicator variable
      
            TeacherButton.Enabled = true; //disables student button
            StudentButton.Enabled = false; //enables teacher button

        }

        private void TeacherButton_Click(object sender, EventArgs e)
        {
            teaStuIndicator = "TEA"; //TEA stored in teaStuIndicator variable

            TeacherButton.Enabled = false; //disables teacher button
            StudentButton.Enabled = true; //enables student button
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            if (teaStuIndicator == "") //if the user hasn't specified if they are a teacher or student
            {
                ErrorLabel.Text = "Are you a student or teacher"; //error message is outputted 
            }
            else if (EmailInputTextbox.Text == "") //if the user has not entered an email
            {
                ErrorLabel.Text = "Please enter an email address"; //an error message is outputted
            }
            else
            { 
                //hide button the uswe just pressed
                ContinueButton.Visible = false; 
                //the email the user typed in is stored in the emailaddress variable
                emailaddress = EmailInputTextbox.Text; 
                //shows password buttons, labels and textboxes
                PasswordLabel.Visible = true;
                CreatePassTextBox.Visible = true;
                ConfirmPassLabel.Visible = true;
                ConfirmPassTextbox.Visible = true;
                CreateAccountButton.Visible = true; 
                //label that contains what the passworsd must contain
                PassInfoLabel.Visible = true;
              

            }
        }

        private void CreateAccountButton_Click(object sender, EventArgs e)
        {
            bool hasNumber = CreatePassTextBox.Text.Any(char.IsNumber); //checks if the password has at least one number
            bool hasCapital = CreatePassTextBox.Text.Any(char.IsUpper); //checks if password has at least one capital
            Regex rgx = new Regex("[^A-Za-z0-9]"); //a regex expression is a character set. The charcter set contains special characters. 
            bool containsSpecial = rgx.IsMatch(CreatePassTextBox.Text); //we check if the all characters in the password match the character set.
            if (CreatePassTextBox.Text == "" || ConfirmPassTextbox.Text == "") //if one or both of the password textboxes are empty
            {
                PassErrorMessageLabel.Text = "Please fill in both sections"; //diplays an error message
            }
            else if (CreatePassTextBox.Text != ConfirmPassTextbox.Text) //if the text in the password textboxes don't match
            {
                PassErrorMessageLabel.Text = "The sections don't match"; //displays an error message
                CreatePassTextBox.Clear(); //clears text from both textboxes
                ConfirmPassTextbox.Clear();
            }
            else if (hasNumber == false) //if the password doesn't have a number
            {
                PassErrorMessageLabel.Text = "Password doesn't have a number..."; //displays error message
            }
            else if (hasCapital == false) //if the password has no capitals
            {
                PassErrorMessageLabel.Text = "Password doesn't have a capital..."; //displays error message
            }
            else if (containsSpecial == false) //if the password has no special characters
            {
                PassErrorMessageLabel.Text = "Password doesn't have a special character..."; //diplsays error message
            }
            else
            {
                string password = ConfirmPassTextbox.Text; //stores password in varaible called password
                WelcomeScreen welcomeScreen = new WelcomeScreen(); //defined instance of WelcomeScreen form
                var createAccount = this; //stores details of current form in createAccount varaible 
                dataBaseUserNameCheck(teaStuIndicator, emailaddress, PassErrorMessageLabel, password, welcomeScreen, createAccount); //calls dataBaseUserNameCheck function and passes parameters
            }
        }



       
        static void dataBaseUserNameCheck(string teaStuIndicator, string emailAddress, 
            Label PassErrorMessageLabel, string password, Form welcomeScreen, Form createAccount)
        {
            Random rnd = new Random(); //declares the random function
            //generates random number, fills number with zeros until number if five digits long
            String userNameNumber = rnd.Next(0, 99999).ToString("D5");
            //combines value on teaStuIndicator with randomly generated number to  make a username. 

            string userName = teaStuIndicator + userNameNumber;

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            OleDbConnection con = new OleDbConnection(); //establosh connection to database
            con.ConnectionString = dbProvider + dbSource;
            con.Open();

            //we use the value of stuTeaIndicator to make sure we query the correct table. 
            if (teaStuIndicator == "STU") 
            {
                //checks in the students table if the email is already part of an account
                OleDbCommand studentEmailCmd = new OleDbCommand("Select * from Students where Email = '" 
                    + emailAddress + "'", con);
                OleDbDataReader emailReader = studentEmailCmd.ExecuteReader();
                if (emailReader.HasRows) //if the email is already signed up with an account
                {
                    //error message is shown 
                    PassErrorMessageLabel.Text = "The email typed in is already signed up with an account";
                    emailReader.Close(); //closes reader
                    studentEmailCmd.Dispose(); //disposes command. 

                }

                else //if the email is not part of an account
                {
                    //query to check if the username generated already exists
                    OleDbCommand checkUserNameCmd = new OleDbCommand("Select * from Students where StudentID = '" + userName + "'", con);
                    OleDbDataReader checkUserNamereader = checkUserNameCmd.ExecuteReader();
                    if (checkUserNamereader.HasRows) //if the username already exists 
                    {
                        //we rerun the function to generate a new username. 
                        dataBaseUserNameCheck(teaStuIndicator, emailAddress, PassErrorMessageLabel, password, welcomeScreen, createAccount); 
                        checkUserNamereader.Close(); //closes reader
                        checkUserNameCmd.Dispose(); //disposes command. 
                    }
                    else //if the username does not exist
                    { 
                        //attempt to send an email to the user with their account details
                        bool emailSend = CreateAccountEmail(emailAddress, PassErrorMessageLabel, userName, password); //runs CreateAccountEmail funciton
                        //query to insert new user, email and password into students table
                        if (emailSend == true) //if the email was sent, the user can be registered in the database
                        {
                            OleDbCommand insertAccountDataCmd = new OleDbCommand("INSERT INTO Students([StudentID], [Password], [Email]) " +
                            "VALUES (@stuUserName, @stuPassword, @stuEmail)", con);
                            insertAccountDataCmd.Parameters.AddRange(new OleDbParameter[]
                            {
                            //parameters for the query
                            new OleDbParameter("@stuUserName", userName), //parameter for the username
                            new OleDbParameter("@stuPassword", password), //parameter for the password
                            new OleDbParameter("@stuEmail", emailAddress), //parameter for the email
                            });
                            insertAccountDataCmd.ExecuteNonQuery(); //executes query
                            insertAccountDataCmd.Dispose(); //disposes command
                            con.Close(); //closes connection
                            MessageBox.Show("Your account has now been created. You can sign in", "Account created!"); //message to confirm the account was created. 
                            createAccount.Hide(); //hides this form
                            welcomeScreen.Show(); //loads welcomescreen

                        }
                        else  //if the email is not sent the user isn't registered
                        {
                            //output error message
                            MessageBox.Show("Your account couldn't be created at this time", "Account not created!"); 
                        }
                    }
                }
            }
            else //if value of stuTeaIndicator is TEA
                 //we query the teacher table
            { 
                //query to check if the email is already part of an account
                OleDbCommand teacherEmailCmd = new OleDbCommand("Select * from Teachers where Email = '" 
                    + emailAddress + "'", con);
                OleDbDataReader teacherEmailReader = teacherEmailCmd.ExecuteReader();
                if (teacherEmailReader.HasRows) //if the email is found in the table
                {
                    //error message is displayed
                    PassErrorMessageLabel.Text = "The email typed in is already signed up with an account"; 
                    teacherEmailReader.Close(); //closes reader
                    teacherEmailCmd.Dispose(); //disposes command

                }
                else //if the email is not already part of an account
                { 
                    //query to check if the username generated already exists
                    OleDbCommand teaUserNameCmd = new OleDbCommand("Select * from Teachers where TeacherID = '" + userName + "'", con);
                    OleDbDataReader teaCheckUserReader = teaUserNameCmd.ExecuteReader();
                    if (teaCheckUserReader.HasRows) //if the username already exists
                    {
                        //function is rerun to generate new username
                        dataBaseUserNameCheck(teaStuIndicator, emailAddress, PassErrorMessageLabel, password, welcomeScreen, createAccount); 
                        teaCheckUserReader.Close(); //closes reader
                        teaCheckUserReader.Close(); //disposes command
                    }
                    else //if the username does not exist
                    { 
                        //attempt to send an email to the user with their details
                        bool emailSend = CreateAccountEmail(emailAddress, PassErrorMessageLabel, userName, password); //runs CreateAccountEmail function
                        if (emailSend == true)  //if the email has been send we can register the user into the database
                        {
                            //query to insert username, password and email into the teacher table
                            OleDbCommand insertDataCmd = new OleDbCommand("INSERT INTO Teachers([TeacherID], [Password], [Email]) VALUES " +
                                "(@teaUserName, " + "@teaPassword, @teaEmail)", con);
                            insertDataCmd.Parameters.AddRange(new OleDbParameter[]
                            { 
                            //parameters for the query
                            new OleDbParameter("@teaUserName", userName), //username parameter
                            new OleDbParameter("@teaPassword", password), //password parameter
                            new OleDbParameter("@teaEmail", emailAddress), //email paramter
                            });
                            insertDataCmd.ExecuteNonQuery(); //executes query
                            insertDataCmd.Dispose(); //disposes command
                            con.Close(); //closes connection
                            MessageBox.Show("Your account has now been created. You can sign in", "Account created!"); //diplays confirmation message
                            createAccount.Hide(); //hides current form
                            welcomeScreen.Show(); //loads welcome screen form

                        }
                        else //if the email is not sent for any reason the users account is not created
                        {
                            //output error message 
                            MessageBox.Show("Your account couldn't be created at this time", "Account not created!");
                        }

                    }

                }

            }



        }
        
        //CreateAccountEmail will return a boolean value - True or False
        static bool CreateAccountEmail(string emailAddress, Label PassErrorMessageLabel, string username, string password)
        {

            SmtpClient client = new SmtpClient() //creates a new instance of the SmtpClient
            {
                Host = "smtp.gmail.com", //provider being used to send the email
                Port = 587, //port the emai is being sent througj
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network, //how the email is being delivered
                UseDefaultCredentials = false, //credentials are the email address and it's password
                Credentials = new NetworkCredential()
                {
                    UserName = "swiftlearningplatform@gmail.com", //email address
                    Password = "SyntaxOptimisation06!" //password
                }

            };
            MailAddress fromEmail = new MailAddress("swiftlearningplatform@gmail.com"); //senders email
            //try statement attempts to add a recipient and sender to the email
            try
            {
                MailAddress recipient = new MailAddress(emailAddress); //recipients email 
                MailMessage message = new MailMessage() //contents of the email
                {
                    From = fromEmail, //who is sending the email
                    Subject = "Welcome to swift...", //the emails subject
                    Body = "Here are your new account details:" + Environment.NewLine + //the body of the email is the main text
               "Username: " + username + Environment.NewLine + //Environment.NewLine makes the text start of a new line
               "Password: " + password +                         
               Environment.NewLine + "Do not share these details with anyone." +
               Environment.NewLine + "Delete this email when you are familiar with the details"


                };
                message.To.Add(recipient); //adds who the email is being sent to 
                try
                {
                    client.Send(message); //trys to send the message 
                    return true; 
                }

                catch (Exception ex) //catches error error if email can't be sent
                {
                    PassErrorMessageLabel.Text = "Couldn't sent email. Try again or re-enter email"; //outputs error message.
                    return false; 
                }
            }
            catch (Exception error) //catches error if sender and recipient can't be added to the email address
            {
                PassErrorMessageLabel.Text = "Please enter a valid email";
                return false; 
            } 
        }

        private void SignInButton_Click(object sender, EventArgs e)
        { 
            //loads welcome screen form
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            this.Hide(); 
            welcomeScreen.Show();
        }

       
    }
}
