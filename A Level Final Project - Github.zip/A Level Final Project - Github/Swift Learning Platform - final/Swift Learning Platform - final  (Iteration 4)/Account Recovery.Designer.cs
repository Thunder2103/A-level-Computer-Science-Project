﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class Account_Recovery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InfoLabel = new System.Windows.Forms.Label();
            this.UserRevoverButton = new System.Windows.Forms.Button();
            this.PassRecover = new System.Windows.Forms.Button();
            this.Infomation = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.EmailTextbox = new System.Windows.Forms.TextBox();
            this.UserRecoverButton = new System.Windows.Forms.Button();
            this.UsernameTextbox = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.Label();
            this.PassRecoverButton = new System.Windows.Forms.Button();
            this.AccountCreateLabel = new System.Windows.Forms.Label();
            this.AccountCreateButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.HomePageButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(271, 38);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(255, 30);
            this.InfoLabel.TabIndex = 1;
            this.InfoLabel.Text = "Have you forgotten your...";
            // 
            // UserRevoverButton
            // 
            this.UserRevoverButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserRevoverButton.Location = new System.Drawing.Point(247, 71);
            this.UserRevoverButton.Name = "UserRevoverButton";
            this.UserRevoverButton.Size = new System.Drawing.Size(127, 48);
            this.UserRevoverButton.TabIndex = 2;
            this.UserRevoverButton.Text = "Username?";
            this.UserRevoverButton.UseVisualStyleBackColor = true;
            this.UserRevoverButton.Click += new System.EventHandler(this.UserRevoverButton_Click);
            // 
            // PassRecover
            // 
            this.PassRecover.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PassRecover.Location = new System.Drawing.Point(421, 71);
            this.PassRecover.Name = "PassRecover";
            this.PassRecover.Size = new System.Drawing.Size(127, 48);
            this.PassRecover.TabIndex = 3;
            this.PassRecover.Text = "Password?";
            this.PassRecover.UseVisualStyleBackColor = true;
            this.PassRecover.Click += new System.EventHandler(this.PassRecover_Click);
            // 
            // Infomation
            // 
            this.Infomation.AutoSize = true;
            this.Infomation.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Infomation.Location = new System.Drawing.Point(302, 133);
            this.Infomation.Name = "Infomation";
            this.Infomation.Size = new System.Drawing.Size(188, 30);
            this.Infomation.TabIndex = 4;
            this.Infomation.Text = "Please enter your...";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Email.Location = new System.Drawing.Point(150, 169);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(68, 30);
            this.Email.TabIndex = 5;
            this.Email.Text = "Email:";
            // 
            // EmailTextbox
            // 
            this.EmailTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailTextbox.Location = new System.Drawing.Point(224, 166);
            this.EmailTextbox.Name = "EmailTextbox";
            this.EmailTextbox.Size = new System.Drawing.Size(384, 35);
            this.EmailTextbox.TabIndex = 6;
            // 
            // UserRecoverButton
            // 
            this.UserRecoverButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserRecoverButton.Location = new System.Drawing.Point(614, 166);
            this.UserRecoverButton.Name = "UserRecoverButton";
            this.UserRecoverButton.Size = new System.Drawing.Size(112, 35);
            this.UserRecoverButton.TabIndex = 9;
            this.UserRecoverButton.Text = "Let\'s go";
            this.UserRecoverButton.UseVisualStyleBackColor = true;
            this.UserRecoverButton.Click += new System.EventHandler(this.UserRecoverButton_Click);
            // 
            // UsernameTextbox
            // 
            this.UsernameTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameTextbox.Location = new System.Drawing.Point(224, 218);
            this.UsernameTextbox.Name = "UsernameTextbox";
            this.UsernameTextbox.Size = new System.Drawing.Size(384, 35);
            this.UsernameTextbox.TabIndex = 10;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Username.Location = new System.Drawing.Point(107, 218);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(111, 30);
            this.Username.TabIndex = 11;
            this.Username.Text = "Username:";
            // 
            // PassRecoverButton
            // 
            this.PassRecoverButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PassRecoverButton.Location = new System.Drawing.Point(614, 219);
            this.PassRecoverButton.Name = "PassRecoverButton";
            this.PassRecoverButton.Size = new System.Drawing.Size(112, 33);
            this.PassRecoverButton.TabIndex = 12;
            this.PassRecoverButton.Text = "Let\'s go";
            this.PassRecoverButton.UseVisualStyleBackColor = true;
            this.PassRecoverButton.Click += new System.EventHandler(this.PassRecoverButton_Click);
            // 
            // AccountCreateLabel
            // 
            this.AccountCreateLabel.AutoSize = true;
            this.AccountCreateLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountCreateLabel.Location = new System.Drawing.Point(224, 310);
            this.AccountCreateLabel.Name = "AccountCreateLabel";
            this.AccountCreateLabel.Size = new System.Drawing.Size(247, 30);
            this.AccountCreateLabel.TabIndex = 16;
            this.AccountCreateLabel.Text = "Don\'t have an acccount?:";
            // 
            // AccountCreateButton
            // 
            this.AccountCreateButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccountCreateButton.Location = new System.Drawing.Point(477, 304);
            this.AccountCreateButton.Name = "AccountCreateButton";
            this.AccountCreateButton.Size = new System.Drawing.Size(143, 46);
            this.AccountCreateButton.TabIndex = 17;
            this.AccountCreateButton.Text = "Create an account";
            this.AccountCreateButton.UseVisualStyleBackColor = true;
            this.AccountCreateButton.Click += new System.EventHandler(this.AccountCreateButton_Click);
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Exit.Location = new System.Drawing.Point(12, 398);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(73, 40);
            this.Exit.TabIndex = 18;
            this.Exit.Text = "<- Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // HomePageButton
            // 
            this.HomePageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HomePageButton.Location = new System.Drawing.Point(645, 398);
            this.HomePageButton.Name = "HomePageButton";
            this.HomePageButton.Size = new System.Drawing.Size(143, 41);
            this.HomePageButton.TabIndex = 19;
            this.HomePageButton.Text = "Back to sign in ->";
            this.HomePageButton.UseVisualStyleBackColor = true;
            this.HomePageButton.Click += new System.EventHandler(this.HomePageButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(224, 266);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(68, 30);
            this.ErrorLabel.TabIndex = 20;
            this.ErrorLabel.Text = "label1";
            // 
            // Account_Recovery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.HomePageButton);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.AccountCreateButton);
            this.Controls.Add(this.AccountCreateLabel);
            this.Controls.Add(this.PassRecoverButton);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.UsernameTextbox);
            this.Controls.Add(this.UserRecoverButton);
            this.Controls.Add(this.EmailTextbox);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Infomation);
            this.Controls.Add(this.PassRecover);
            this.Controls.Add(this.UserRevoverButton);
            this.Controls.Add(this.InfoLabel);
            this.Name = "Account_Recovery";
            this.Text = "Account_Recovery";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Button UserRevoverButton;
        private System.Windows.Forms.Button PassRecover;
        private System.Windows.Forms.Label Infomation;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox EmailTextbox;
        private System.Windows.Forms.Button UserRecoverButton;
        private System.Windows.Forms.TextBox UsernameTextbox;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Button PassRecoverButton;
        private System.Windows.Forms.Label AccountCreateLabel;
        private System.Windows.Forms.Button AccountCreateButton;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button HomePageButton;
        private System.Windows.Forms.Label ErrorLabel;
    }
}