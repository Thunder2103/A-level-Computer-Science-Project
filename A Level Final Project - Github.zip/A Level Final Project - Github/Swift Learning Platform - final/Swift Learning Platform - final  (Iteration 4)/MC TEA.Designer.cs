﻿
namespace Swift_Learning_Platform___final___Iteration_4_
{
    partial class MC_TEA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.MultChoiceLabel = new System.Windows.Forms.Label();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.QuestionLabel = new System.Windows.Forms.Label();
            this.QuestionTextBox = new System.Windows.Forms.TextBox();
            this.Answer1Label = new System.Windows.Forms.Label();
            this.CorrectAnsTextbox = new System.Windows.Forms.TextBox();
            this.Answer2Label = new System.Windows.Forms.Label();
            this.AnsTwoTextBox = new System.Windows.Forms.TextBox();
            this.Answer3Label = new System.Windows.Forms.Label();
            this.AnsThreeTextBox = new System.Windows.Forms.TextBox();
            this.Answer4Label = new System.Windows.Forms.Label();
            this.AnsFourTextBox = new System.Windows.Forms.TextBox();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SetQuestionButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(58, 30);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Swift";
            // 
            // MultChoiceLabel
            // 
            this.MultChoiceLabel.AutoSize = true;
            this.MultChoiceLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MultChoiceLabel.Location = new System.Drawing.Point(262, 37);
            this.MultChoiceLabel.Name = "MultChoiceLabel";
            this.MultChoiceLabel.Size = new System.Drawing.Size(262, 30);
            this.MultChoiceLabel.TabIndex = 4;
            this.MultChoiceLabel.Text = "Multiple Choice Templates:";
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InfoLabel.Location = new System.Drawing.Point(314, 67);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(162, 30);
            this.InfoLabel.TabIndex = 5;
            this.InfoLabel.Text = "Fill in the boxes:";
            // 
            // QuestionLabel
            // 
            this.QuestionLabel.AutoSize = true;
            this.QuestionLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionLabel.Location = new System.Drawing.Point(13, 117);
            this.QuestionLabel.Name = "QuestionLabel";
            this.QuestionLabel.Size = new System.Drawing.Size(102, 30);
            this.QuestionLabel.TabIndex = 6;
            this.QuestionLabel.Text = "Question:";
            // 
            // QuestionTextBox
            // 
            this.QuestionTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QuestionTextBox.Location = new System.Drawing.Point(115, 114);
            this.QuestionTextBox.Name = "QuestionTextBox";
            this.QuestionTextBox.Size = new System.Drawing.Size(682, 35);
            this.QuestionTextBox.TabIndex = 11;
            // 
            // Answer1Label
            // 
            this.Answer1Label.AutoSize = true;
            this.Answer1Label.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer1Label.Location = new System.Drawing.Point(29, 163);
            this.Answer1Label.Name = "Answer1Label";
            this.Answer1Label.Size = new System.Drawing.Size(86, 60);
            this.Answer1Label.TabIndex = 12;
            this.Answer1Label.Text = "Correct \r\nAnswer:";
            // 
            // CorrectAnsTextbox
            // 
            this.CorrectAnsTextbox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CorrectAnsTextbox.Location = new System.Drawing.Point(115, 167);
            this.CorrectAnsTextbox.Name = "CorrectAnsTextbox";
            this.CorrectAnsTextbox.Size = new System.Drawing.Size(682, 35);
            this.CorrectAnsTextbox.TabIndex = 13;
            // 
            // Answer2Label
            // 
            this.Answer2Label.AutoSize = true;
            this.Answer2Label.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer2Label.Location = new System.Drawing.Point(12, 229);
            this.Answer2Label.Name = "Answer2Label";
            this.Answer2Label.Size = new System.Drawing.Size(103, 30);
            this.Answer2Label.TabIndex = 14;
            this.Answer2Label.Text = "Answer 2:";
            // 
            // AnsTwoTextBox
            // 
            this.AnsTwoTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AnsTwoTextBox.Location = new System.Drawing.Point(115, 226);
            this.AnsTwoTextBox.Name = "AnsTwoTextBox";
            this.AnsTwoTextBox.Size = new System.Drawing.Size(682, 35);
            this.AnsTwoTextBox.TabIndex = 17;
            // 
            // Answer3Label
            // 
            this.Answer3Label.AutoSize = true;
            this.Answer3Label.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer3Label.Location = new System.Drawing.Point(12, 276);
            this.Answer3Label.Name = "Answer3Label";
            this.Answer3Label.Size = new System.Drawing.Size(103, 30);
            this.Answer3Label.TabIndex = 18;
            this.Answer3Label.Text = "Answer 3:";
            // 
            // AnsThreeTextBox
            // 
            this.AnsThreeTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AnsThreeTextBox.Location = new System.Drawing.Point(115, 273);
            this.AnsThreeTextBox.Name = "AnsThreeTextBox";
            this.AnsThreeTextBox.Size = new System.Drawing.Size(682, 35);
            this.AnsThreeTextBox.TabIndex = 19;
            // 
            // Answer4Label
            // 
            this.Answer4Label.AutoSize = true;
            this.Answer4Label.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer4Label.Location = new System.Drawing.Point(12, 320);
            this.Answer4Label.Name = "Answer4Label";
            this.Answer4Label.Size = new System.Drawing.Size(103, 30);
            this.Answer4Label.TabIndex = 20;
            this.Answer4Label.Text = "Answer 4:";
            // 
            // AnsFourTextBox
            // 
            this.AnsFourTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AnsFourTextBox.Location = new System.Drawing.Point(115, 320);
            this.AnsFourTextBox.Name = "AnsFourTextBox";
            this.AnsFourTextBox.Size = new System.Drawing.Size(682, 35);
            this.AnsFourTextBox.TabIndex = 21;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(88, 367);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(99, 30);
            this.ErrorLabel.TabIndex = 26;
            this.ErrorLabel.Text = "Filler Text";
            // 
            // SetQuestionButton
            // 
            this.SetQuestionButton.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetQuestionButton.Location = new System.Drawing.Point(665, 400);
            this.SetQuestionButton.Name = "SetQuestionButton";
            this.SetQuestionButton.Size = new System.Drawing.Size(123, 38);
            this.SetQuestionButton.TabIndex = 31;
            this.SetQuestionButton.Text = "Set Question ->";
            this.SetQuestionButton.UseVisualStyleBackColor = true;
            this.SetQuestionButton.Click += new System.EventHandler(this.SetQuestionButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackButton.Location = new System.Drawing.Point(12, 400);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(232, 39);
            this.BackButton.TabIndex = 32;
            this.BackButton.Text = "<- Choose a different Template";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Swift_Learning_Platform___final___Iteration_4_.Properties.Resources.Swift_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(722, 9);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(66, 57);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 45;
            this.LogoPictureBox.TabStop = false;
            // 
            // MC_TEA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SetQuestionButton);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.AnsFourTextBox);
            this.Controls.Add(this.Answer4Label);
            this.Controls.Add(this.AnsThreeTextBox);
            this.Controls.Add(this.Answer3Label);
            this.Controls.Add(this.AnsTwoTextBox);
            this.Controls.Add(this.Answer2Label);
            this.Controls.Add(this.CorrectAnsTextbox);
            this.Controls.Add(this.Answer1Label);
            this.Controls.Add(this.QuestionTextBox);
            this.Controls.Add(this.QuestionLabel);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.MultChoiceLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "MC_TEA";
            this.Text = "Multiple Choice";
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label MultChoiceLabel;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.Label QuestionLabel;
        private System.Windows.Forms.TextBox QuestionTextBox;
        private System.Windows.Forms.Label Answer1Label;
        private System.Windows.Forms.TextBox CorrectAnsTextbox;
        private System.Windows.Forms.Label Answer2Label;
        private System.Windows.Forms.TextBox AnsTwoTextBox;
        private System.Windows.Forms.Label Answer3Label;
        private System.Windows.Forms.TextBox AnsThreeTextBox;
        private System.Windows.Forms.Label Answer4Label;
        private System.Windows.Forms.TextBox AnsFourTextBox;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Button SetQuestionButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
    }
}