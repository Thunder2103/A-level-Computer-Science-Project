﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Swift_Learning_Platform___final___Iteration_4_
{
    public partial class FC_Answer_STU : Form
    {
        //global variables
        string globalStudentID = "";
        int globalCount;
        string globalWorkID = "";
        int globalQuestionCount;
        public FC_Answer_STU(string studentID, int count, string workID, int questionCount)
        {
            InitializeComponent();
            //values passed from previous forms stored in global variables
            globalStudentID = studentID;
            globalCount = count;
            globalWorkID = workID;
            globalQuestionCount = questionCount;

            OleDbConnection con = new OleDbConnection();

            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 

            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database
            //query to select Flashcard answer from Questions table
            string getQuestion = ("Select [Correct Answer] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter da = new OleDbDataAdapter(getQuestion, con); //data adapter
            DataSet ds = new DataSet(); //returned data
            DataTable dt = new DataTable(); //where data will be stored

            da.Fill(ds, "QuestionAnswer"); //data converted into useable format
            dt = ds.Tables["QuestionAnswer"]; //data is stored in datatable

            //text at row 0 and index corresponding to value of questionCount is displayed in textbox
            FlashCardAnsTextBox.Text = dt.Rows[questionCount][0].ToString();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            //loads View Assignments form
            View_Assignments viewAssignments = new View_Assignments(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
            this.Hide();
            viewAssignments.Show();
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            globalCount++; //add one to the score
            globalQuestionCount++; //add one to the Question count

            OleDbConnection con = new OleDbConnection();


            string dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"; //engine that queries the database
            string dbSource = "Data Source=[Database path]"; //this is where the database is stored. 


            con.ConnectionString = dbProvider + dbSource;
            con.Open(); //establish connection to the database
            //query the fetch Question Type of next question from Questions table
            string fetchQuestion = ("Select [Question Type] from Questions where WorkID='" + globalWorkID + "'");
            OleDbDataAdapter fetchDA = new OleDbDataAdapter(fetchQuestion, con); //data adapter 

            DataSet fetchDS = new DataSet(); //returned data
            DataTable fetchDT = new DataTable(); //where data will be stored

            fetchDA.Fill(fetchDS, "QuestionType"); //data put into useable format
            fetchDT = fetchDS.Tables["QuestionType"]; //data placed into datatable 

            //case and switch statment, loads correct from using value from the first index of the datatable
            switch (fetchDT.Rows[globalQuestionCount][0])
            {
                case "TF":
                    //loads True or False form
                    TF_STU tfTemplate = new TF_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    tfTemplate.Show();
                    break;
                case "MC":
                    //loads Multiple Choice form
                    MC_STU mcTemplate = new MC_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    mcTemplate.Show();
                    break;
                case "FC":
                    //loads Flashcard form
                    FC_Question_STU fcTemplate = new FC_Question_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    fcTemplate.Show();
                    break;
                case "OW":
                    //Loads One Word form
                    OW_STU owTemplate = new OW_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    owTemplate.Show();
                    break;
                case "FB":
                    //Loads Fill in the blank form
                    FB_STU fbTemplate = new FB_STU(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    fbTemplate.Show();
                    break;
                case "Stop":
                    //Loads View Assignments form as last question has been completed
                    View_Assignments completeAssigments = new View_Assignments(globalStudentID, globalCount, globalWorkID, globalQuestionCount);
                    this.Hide();
                    completeAssigments.Show();
                    break;
            }

            fetchDA.Dispose(); //diposes data adapter
            fetchDS.Dispose(); //diposes data set
            fetchDT.Dispose(); //diposes data table
            con.Close(); //closes connection to database

        }
    }
}
